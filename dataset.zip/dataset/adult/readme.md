Adult Dataset
---
* Download the following files from [https://archive.ics.uci.edu/ml/machine-learning-databases/adult/](https://archive.ics.uci.edu/ml/machine-learning-databases/adult/) to this directory.
	* `adult.data`.
	* `adult.test`.

* Preprocess the data.
	* Run `python3 continuous.py`.

This creates a `continuous/train.npy` and `continuous/test.npy`.
