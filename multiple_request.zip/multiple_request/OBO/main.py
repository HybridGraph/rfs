# cython: cdivision=True
# cython: boundscheck=False
# cython: wraparound=False
"""
Data remover.
"""
from cpython cimport Py_INCREF
from cpython.ref cimport PyObject

cimport cython

from libc.stdlib cimport free
from libc.stdlib cimport malloc
from libc.stdlib cimport realloc
from libc.stdio cimport printf

from libc.math cimport exp
from libc.time cimport time
from libc.time cimport clock

import numpy as np
cimport numpy as np
import time as cur_time
np.import_array()
from numpy.math cimport INFINITY

from ._tree cimport Feature
from ._tree cimport Threshold
from ._splitter cimport get_candidate_thresholds

from ._utils cimport rand_int
from ._utils cimport rand_uniform
from ._utils cimport compute_split_score
from ._utils cimport split_samples

from ._utils cimport create_feature
from ._utils cimport copy_feature
from ._utils cimport free_feature
from ._utils cimport free_features

from ._utils cimport copy_threshold
from ._utils cimport create_threshold
from ._utils cimport free_thresholds

from ._utils cimport create_intlist
from ._utils cimport copy_intlist
from ._utils cimport free_intlist

from ._utils cimport copy_indices
from ._utils cimport convert_int_ndarray
from ._utils cimport copy_int_array

from libc.math cimport fabs

from ._utils cimport dealloc
from ._utils cimport dealloc1
from ._argsort cimport sort

# constants
cdef INT32_t UNDEF = -1
cdef DTYPE_t UNDEF_LEAF_VAL = 0.5
cdef DTYPE_t FEATURE_THRESHOLD = 0.0000001
cdef INT32_t N_DELETE = 30
cdef SIZE_t  CLOCKS_PER_SEC = 1000

# =====================================
# Remover
# =====================================

cdef class _Remover:
    """
    Removes data from a learned tree.
    """

    # removal metrics
    property remove_types:
        def __get__(self):
            return self.get_int_ndarray(self.remove_types, self.remove_count)

    property remove_depths:
        def __get__(self):
            return self.get_int_ndarray(self.remove_depths, self.remove_count)

    property remove_costs:
        def __get__(self):
            return self.get_int_ndarray(self.remove_costs, self.remove_count)

    def __cinit__(self,
                  _DataManager manager,
                  _TreeBuilder tree_builder,
                  _Config      config):
        """
        Constructor.
        """
        self.manager = manager
        self.tree_builder = tree_builder
        self.config = config

        # initialize metric properties
        self.capacity = 10
        self.remove_count = 0
        self.remove_types = <INT32_t *>malloc(self.capacity * sizeof(INT32_t))
        self.remove_depths = <INT32_t *>malloc(self.capacity * sizeof(INT32_t))
        self.remove_costs = <INT32_t *>malloc(self.capacity * sizeof(INT32_t))

    def __dealloc__(self):
        """
        Destructor.
        """
        # free removal types
        if self.remove_types:
            free(self.remove_types)

        # free removal depths
        if self.remove_depths:
            free(self.remove_depths)

# =======================周期删除循环====================================
    cpdef void window_remove(self, _Tree tree, int[:]  remove_indices):
        """
        delete 1000samples with "window_remove" method
        """
        cdef SIZE_t  i
        cdef SIZE_t  k
        cdef SIZE_t  remove_sample
        cdef SIZE_t  n_samples = remove_indices.shape[0]
        cdef Node*   node = tree.root

        cdef DTYPE_t**  X = NULL
        cdef INT32_t*   y = NULL
        self.manager.get_data(&X, &y)

        for i in range(0, N_DELETE):
            remove_sample = remove_indices[i]
            self.remove(node, remove_sample)
        remove_sample = remove_indices[0]
        if node.in_table[remove_sample] != 0:
           self._emer(&tree.root, remove_sample, X, y)

        for i in range(N_DELETE, n_samples):
            if (i+1) % N_DELETE == 0:
               for k in range(i-N_DELETE+1, i):
                   remove_sample = remove_indices[k]
                   if node.in_table[remove_sample] == 1:
                      self.clear_later(&tree.root, remove_sample, X)
                   self.remove(node, remove_sample)
               remove_sample = remove_indices[i]
               self.remove(node, remove_sample)
               remove_sample = remove_indices[i-N_DELETE+1]
               if node.in_table[remove_sample] != 0:
                  self._emer(&tree.root, remove_sample, X, y)
            else:
                remove_sample = remove_indices[i]
                self.later_remove(node, remove_sample)
                remove_sample = remove_indices[i - N_DELETE + 1]
                if node.in_table[remove_sample] != 0:
                   self._emer(&tree.root, remove_sample, X, y)

        # the last 29------------------------------------------能不能更简单,wsm有这段更快
        for i in range(n_samples, n_samples+N_DELETE-1):
            if (i+1) % N_DELETE == 0:
               for k in range(n_samples-n_samples%N_DELETE, n_samples):
                   remove_sample = remove_indices[k]
                   if node.in_table[remove_sample] == 1:
                      self.clear_later(&tree.root, remove_sample, X)
                   self.remove(node, remove_sample)
               remove_sample = remove_indices[i-N_DELETE+1]
               if node.in_table[remove_sample] != 0:
                  self._emer(&tree.root, remove_sample, X, y)
            else:
               remove_sample = remove_indices[i-N_DELETE+1]
               if node.in_table[remove_sample] != 0:
                  self._emer(&tree.root, remove_sample, X, y)


# ============放入■==================

    cdef void remove(self,
                    Node* node,
                    SIZE_t remove_sample)nogil:
        """
        set the instance at the root's [delete_samples list]
        """

        # 检查一下retrain，根节点提前开好这部分空间，不再判断
        if node.delete_samples == NULL:
           node.delete_samples = create_intlist(N_DELETE,0)
        # ======================
        node.delete_samples.arr[node.delete_samples.n] = remove_sample
        node.delete_samples.n += 1
        node.bad_label = True

# ============放入▲==================

    cdef void later_remove(self,
                            Node* node,
                            SIZE_t remove_sample)nogil:
        """
        set the instance at the root's [later_samples list]
        """

        if node.later_samples == NULL:
           node.later_samples = create_intlist(N_DELETE,0)
        node.later_samples.arr[node.later_samples.n] = remove_sample
        node.later_samples.n += 1
        node.later_label = True

# ==========================================🔺清除===============================================
    cdef void clear_later(self,
                    Node**    node_ptr,
                    SIZE_t  remove_sample,
                    DTYPE_t** X)nogil:
        """
         clean this path
        """
        cdef Node*      node = node_ptr[0]

        # start from root
        node.later_label = False
        node.later_samples.n = 0

        while not node.is_leaf:
              # go to descent node
              if X[remove_sample][node.chosen_feature.index] <= node.chosen_threshold.value:
                 node = node.left
              else:
                 node = node.right

              # meet bad node update
              if node.later_label:
                 node.later_label = False
                 node.later_samples.n = 0


# ==========================================更新路径===============================================
    cdef void _emer(self,
                    Node**    node_ptr,
                    SIZE_t  remove_sample,
                    DTYPE_t**  X,
                    INT32_t*   y)nogil:
        """
         clean this path
        """
        cdef SIZE_t     H_retrain = 0
        cdef Node*      node = node_ptr[0]
        cdef Node*      root = node_ptr[0]

        # root
        if node.bad_label:
           H_retrain = self._update(&root, &node, X, y)
        elif node.later_label:
           self.split_to_descent2(&node, X)

        if H_retrain == 0:
            # start from root's son
            while not node.is_leaf:
                  # go to descent node
                  if X[remove_sample][node.chosen_feature.index] <= node.chosen_threshold.value:
                     node = node.left
                  else:
                     node = node.right

                  # meet bad node update
                  if node.bad_label:
                     H_retrain = self._update(&root, &node, X, y)
                     # convert to leaf or retrain or adv clear break
                     if node.is_leaf or H_retrain == 1:
                        break

                  # not bad but has later samples
                  elif node.later_label:
                     if node.is_leaf==False:
                        self.split_to_descent2(&node, X)

# ==========================================更新■坏点==============================================
    cdef SIZE_t _update(self,
                      Node**    root_ptr,
                      Node**    node_ptr,
                      DTYPE_t** X,
                      INT32_t*  y) nogil:
        """
        Update and retrain this node if necessary, otherwise traverse
        to its children.
        """
        cdef SIZE_t     H_retrain = 0

        cdef Node*      root = root_ptr[0]
        cdef Node*      node = node_ptr[0]
        cdef SIZE_t     min_number = self.config.max_value
        cdef SIZE_t     start = node.start
        cdef SIZE_t     end = node.end

        # cur delete samples
        cdef SIZE_t   n_each_batch = self.manager.n_each_batch
        cdef SIZE_t   G_number
        cdef SIZE_t   n_batch = self.config.n_batch
        cdef IntList* cur_delete_samples
        cdef SIZE_t   n_pos_cur_delete_samples = 0
        cdef SIZE_t   i = 0
        cdef SIZE_t   j = 0

        # result containers
        cdef SIZE_t       result = 0
        cdef SIZE_t       n_usable_thresholds = 0

        # =================================清理五角星，标记为彻底删除================================
        cdef SIZE_t       clear_sample
        if node.adv_length > 0:
           # printf('delete:%d, adv:%d\n', node.delete_samples.n, node.adv_length)
           for i in range(node.adv_length):
               clear_sample = node.delete_samples.arr[i]
               root.in_table[clear_sample] = 0
           if node.delete_samples.n-node.adv_length > 0:
              samples = create_intlist(N_DELETE,0)
              for j in range(node.adv_length, node.delete_samples.n):
                  samples.arr[samples.n] = node.delete_samples.arr[j]
                  samples.n += 1
              free_intlist(node.delete_samples)
              node.delete_samples = samples
              node.bad_label = True

           else:
                node.delete_samples.n = 0
                node.bad_label = False
           node.adv_length = 0
           H_retrain = 1
        # ============================================================================
        else:
            # update node counts
            #printf('update node\n')
            self.update_node(node, y)
            #printf('update node ok\n')

            # leaf, check complete
            if node.is_leaf:
                #printf('[R] update leaf\n')
                self.update_leaf(node, &root)
                #printf('update leaf ok\n')

            # decision node, but samples in same class, convert to leaf, check complete
            elif (node.n_pos_samples == 0 or node.n_pos_samples == node.n_samples):
                #printf('[R]---------- convert to leaf\n')
                self.convert_to_leaf(node, &root)
                #printf('[R] convert to leaf ok\n')

            # decision node
            else:
                # // 这部分可以尝试在更新结点的时候获取
                cur_delete_samples = create_intlist(node.delete_samples.n, 0)

                for i in range(node.delete_samples.n):
                    G_number = node.delete_samples.arr[i]/n_each_batch
                    if G_number > n_batch -1:
                       G_number = n_batch -1
                    if (start<=G_number<=end) or (G_number>=start>end) or (G_number<=end<start):
                       cur_delete_samples.arr[cur_delete_samples.n] = node.delete_samples.arr[i]
                       cur_delete_samples.n += 1
                       n_pos_cur_delete_samples += y[node.delete_samples.arr[i]]

                if cur_delete_samples.n > 0:
                   node.n_cur_samples -= cur_delete_samples.n
                   node.n_pos_cur_samples -= n_pos_cur_delete_samples
                   if node.n_pos_cur_samples == 0 or node.n_cur_samples == node.n_pos_cur_samples:
                      #printf('[R] convert to leaf 2\n')
                      self.convert_to_leaf(node, &root)
                      #printf('[R] convert to leaf ok\n')

                   elif (node.n_cur_samples < min_number and node.n_cur_samples < node.n_samples):
                      # retrain from this node
                      # printf('node.depth: %d, [R] ----------------------retrain by not match min_number\n', node.depth)
                      if node.later_label:
                         if node.n_samples - node.later_samples.n == 0:
                            self.retrain1(node_ptr, X, y, &root)
                         else:
                            # printf('retrain 2?\n')
                            self.retrain2(node_ptr, X, y, &root)
                      else:
                         self.retrain1(node_ptr, X, y, &root)
                      H_retrain = 1
                      # printf('[R] retrain ok\n')

                   else:
                      # printf('[R] update_metadata\n')
                      n_usable_thresholds = self.update_metadata(node, X, y, cur_delete_samples)
                      # printf('[R] update_metadata ok\n')

                      if n_usable_thresholds == 0:
                         # printf('[R] n_usable_thresholds = 0\n')
                         self.convert_to_leaf(node, &root)
                      elif n_usable_thresholds == -1:
                         # printf('node.depth: %d, [R] ----------------------retrain by random node invalid\n', node.depth)
                         if node.later_label:
                             if node.n_samples - node.later_samples.n == 0:
                                self.retrain1(node_ptr, X, y, &root)
                             else:
                                self.retrain2(node_ptr, X, y, &root)
                         else:
                             self.retrain1(node_ptr, X, y, &root)
                         H_retrain = 1
                      else:
                         result = self.select_optimal_split(node)
                         if result == 1:
                            # retrain from descent node
                            if node.later_label:
                                if node.n_samples - node.later_samples.n == 0:
                                   self.retrain(node_ptr, X, y, &root)
                                else:
                                   self.retrain2(node_ptr, X, y, &root)
                            else:
                                self.retrain(&node, X, y, &root)
                            H_retrain = 1
                            # printf('[R] retrain ok\n')
                         else:
                            # not changed
                            # printf('go down\n')
                            self.split_to_descent(&node, X)
                            if node.later_label:
                               self.split_to_descent2(&node, X)

                # not in start-end
                else:
                   # printf('go down\n')
                   # 分流给子结点，子结点变坏点，本届点.n=0
                   self.split_to_descent(&node, X)
                   if node.later_label:
                      self.split_to_descent2(&node, X)
                free_intlist(cur_delete_samples)
        # if node.bad_label:
           # printf('node.delete.n:%d\n', node.delete_samples.n)
        return H_retrain
# ========================================▲分流====================================================♥更简约的方式（要不要在叶节点就清零，减少路径的探寻）
    # private
    cdef void split_to_descent2(self,
                               Node** node_ptr,
                               DTYPE_t** X)nogil:
         """
         split the later samples to next node and label the node
         """

         cdef Node*    node = node_ptr[0]
         cdef IntList* samples = node.later_samples
         cdef SIZE_t   i

         if node.left.later_samples == NULL:
            node.left.later_samples = create_intlist(N_DELETE, 0)
         if node.right.later_samples == NULL:
            node.right.later_samples = create_intlist(N_DELETE, 0)

         for i in range(samples.n):
             if X[samples.arr[i]][node.chosen_feature.index] <= node.chosen_threshold.value:
                node.left.later_samples.arr[node.left.later_samples.n] = samples.arr[i]
                node.left.later_samples.n += 1
             else:
                node.right.later_samples.arr[node.right.later_samples.n] = samples.arr[i]
                node.right.later_samples.n += 1

         if node.left.later_samples.n >0:
            node.left.later_label = True
         if node.right.later_samples.n >0:
            node.right.later_label = True

         node.later_label = False
         node.later_samples.n = 0

# ==================================================================================================

    # private
    cdef void split_to_descent(self,
                               Node** node_ptr,
                               DTYPE_t** X)nogil:
         """
         split the delete samples to next node and label the node
         """

         cdef Node*    node = node_ptr[0]
         cdef IntList* samples = node.delete_samples
         cdef SIZE_t   i

         if node.left.delete_samples == NULL:
            node.left.delete_samples = create_intlist(N_DELETE, 0)
         if node.right.delete_samples == NULL:
            node.right.delete_samples = create_intlist(N_DELETE, 0)

         for i in range(samples.n):
             if X[samples.arr[i]][node.chosen_feature.index] <= node.chosen_threshold.value:
                node.left.delete_samples.arr[node.left.delete_samples.n] = samples.arr[i]
                node.left.delete_samples.n += 1
             else:
                node.right.delete_samples.arr[node.right.delete_samples.n] = samples.arr[i]
                node.right.delete_samples.n += 1

         if node.left.delete_samples.n >0:
            node.left.bad_label = True
         if node.right.delete_samples.n >0:
            node.right.bad_label = True

         node.bad_label = False
         node.delete_samples.n = 0


    cdef void update_node(self,
                          Node*     node,
                          INT32_t*  y) nogil:
        """
        Update node counts based on the `remove_samples` being deleted.
        """

        cdef IntList* remove_samples = node.delete_samples

        # compute number of positive samples being deleted
        cdef SIZE_t i
        cdef SIZE_t j
        cdef SIZE_t n_pos_remove_samples = 0

        cdef SIZE_t   n_each_batch = self.manager.n_each_batch
        cdef SIZE_t   n_batch = self.config.n_batch
        cdef SIZE_t   G_number

        cdef SIZE_t*  new_valid_batch
        cdef SIZE_t   n_new_valid_batch = 0
        cdef IntList* invalid_batch = create_intlist(node.n_valid_batch, 0)
        cdef bint     add_batch

        # ♥
        for i in range(remove_samples.n):
            n_pos_remove_samples += y[remove_samples.arr[i]]

            G_number = remove_samples.arr[i]/n_each_batch
            if G_number > n_batch -1:
               G_number = n_batch -1

            for j in range(G_number, n_batch):
                node.n_all[j] -= 1

            if ((G_number == 0 and node.n_all[G_number] == 0) or
                (G_number>0 and node.n_all[G_number] - node.n_all[G_number-1] == 0)):
               invalid_batch.arr[invalid_batch.n] = G_number
               invalid_batch.n += 1
        # ♥
        node.n_samples = node.n_samples - remove_samples.n
        node.n_pos_samples -= n_pos_remove_samples

        if invalid_batch.n > 0:
           node.n_valid_batch -= invalid_batch.n
           new_valid_batch =  <SIZE_t*>malloc(node.n_valid_batch*sizeof(SIZE_t))
           for i in range(node.n_valid_batch+invalid_batch.n):
               add_batch = True
               for j in range(invalid_batch.n):
                   if node.valid_batch[i] == invalid_batch.arr[j]:
                      add_batch = False
                      break
               if add_batch:
                  new_valid_batch[n_new_valid_batch] = node.valid_batch[i]
                  n_new_valid_batch += 1
           free(node.valid_batch)
           node.valid_batch = new_valid_batch
        free_intlist(invalid_batch)



    cdef void update_leaf(self,
                          Node*    node,
                          Node**    root_ptr) nogil:
        """
        Update leaf node properties: value and leaf_samples. Check complete.
        """
        cdef IntList*  remove_samples = node.delete_samples
        cdef SIZE_t    i
        cdef SIZE_t    j

        # label the remove_sample==================================
        cdef SIZE_t clear_sample
        cdef Node*  root = root_ptr[0]
        # ♥
        for i in range(remove_samples.n):
            clear_sample = remove_samples.arr[i]
            root.in_table[clear_sample] = 0
        # ==========================================================

        # update leaf value
        node.value = node.n_pos_samples / <double> node.n_samples

        # update leaf_samples
        cdef SIZE_t* new_samples = <SIZE_t*>malloc(node.n_samples*sizeof(SIZE_t))
        cdef SIZE_t  n_new_samples = 0
        # ♥
        for i in range(0, node.n_samples + remove_samples.n):
           add_sample = True
           for j in range(remove_samples.n):
               if node.leaf_samples[i] == remove_samples.arr[j]:
                  add_sample = False
                  break
           if add_sample:
              new_samples[n_new_samples] = node.leaf_samples[i]
              n_new_samples += 1
        free(node.leaf_samples)
        node.leaf_samples = new_samples

        # free remove samples
        node.delete_samples.n = 0
        node.bad_label = False


    cdef void convert_to_leaf(self,
                              Node*        node,
                              Node**   root_ptr) nogil:
        """
        Convert decision node to a leaf node. Check complete.
        """

        # get leaf samples and remove deleted samples
        cdef SIZE_t     i
        cdef SIZE_t     n_batch = self.config.n_batch
        cdef IntList*   remove_samples = node.delete_samples
        cdef SIZE_t*    leaf_samples = <SIZE_t*>malloc(node.n_samples*sizeof(SIZE_t))
        cdef SIZE_t*    n_leaf_samples = <SIZE_t*>malloc(n_batch*sizeof(SIZE_t))

        # label the remove_sample================================================
        cdef SIZE_t clear_sample
        cdef Node*  root = root_ptr[0]
        # ♥
        for i in range(remove_samples.n):
            clear_sample = remove_samples.arr[i]
            root.in_table[clear_sample] = 0
        # ==========================================================
        for i in range(n_batch):
            n_leaf_samples[i] = 0
        # ♥
        get_leaf_samples(node, remove_samples, node.adv_length, node.n_all, leaf_samples, n_leaf_samples, node.depth, &root)
        #cdef SIZE_t count = 0
        #for i in range(n_batch):
        #   count += n_leaf_samples[i]
        #if node.n_samples != count:
        #   printf('retrain node.depth:%d should get:%d  actually:%d remove.n:%d\n', node.depth, node.n_samples, count, remove_samples.n)


        free(n_leaf_samples)
        dealloc(node)
        node.delete_samples.n = 0
        node.bad_label = False

        #printf('node.valid_batch:%d\n', node.n_valid_batch)
        # set leaf properties
        node.is_leaf = True
        node.value = node.n_pos_samples / <DTYPE_t> node.n_samples
        node.leaf_samples = leaf_samples

        # reset decision node properties(actually this is not used can maintain but changed just for unlearn)
        node.n_cur_samples = 0
        node.n_pos_cur_samples = 0
        node.start = 0
        node.end = self.config.n_batch - 1


    cdef void retrain(self,
                      Node**    node_ptr,
                      DTYPE_t** X,
                      INT32_t*  y,
                      Node**   root_ptr) nogil:
        """
            - Retrain subtrees below this node.
        """
        cdef Node*    node = node_ptr[0]
        cdef SIZE_t    i
        cdef SIZE_t    j
        cdef SIZE_t   loc
        cdef SIZE_t   last_loc
        cdef SIZE_t   init_loc
        cdef SIZE_t   n_loc

        # node properties
        cdef IntList*   remove_samples = node.delete_samples
        cdef SIZE_t     depth = node.depth
        cdef SIZE_t     u_s
        cdef SIZE_t     n_batch = self.config.n_batch
        cdef SIZE_t     n_valid_batch = node.n_valid_batch
        cdef SIZE_t*    valid_batch = node.valid_batch
        cdef SIZE_t*    n_all = node.n_all

        # descent node properties
        cdef SIZE_t*     left_samples
        cdef SIZE_t*     right_samples
        cdef SIZE_t      N_left_samples = 0
        cdef SIZE_t      N_right_samples = 0
        cdef SIZE_t      n_left_valid_batch
        cdef SIZE_t      n_right_valid_batch
        cdef SIZE_t*     left_valid_batch
        cdef SIZE_t*     right_valid_batch
        cdef SIZE_t*     n_all_left
        cdef SIZE_t*     n_all_right
        cdef SIZE_t      new_start

        # updated array of leaf samples
        # printf('get leaf\n')
        cdef SIZE_t*    samples = <SIZE_t*>malloc(node.n_samples*sizeof(SIZE_t))
        cdef SIZE_t*    n_leaf_samples = <SIZE_t*>malloc(n_batch*sizeof(SIZE_t))


        u_s = node.n_samples   # retrain gain initial count=======================
        self.manager.count_samples(u_s)
        self.manager.count_data(1)

        # label the remove_sample================================================
        cdef SIZE_t clear_sample
        cdef Node*  root = root_ptr[0]
        for i in range(remove_samples.n):
            clear_sample = remove_samples.arr[i]
            root.in_table[clear_sample] = 0
        # ==========================================================
        for i in range(n_batch):
            n_leaf_samples[i] = 0
        get_leaf_samples(node, remove_samples, node.adv_length, node.n_all, samples, n_leaf_samples, node.depth, &root)
        # ========================================================================
        free(n_leaf_samples)

        # printf('dealloc\n')
        # free descendant nodes
        dealloc1(node.left)
        dealloc1(node.right)
        # printf('dealloc ok\n')
        free(node.left)
        free(node.right)
        node.bad_label = False
        node.delete_samples.n = 0
        # printf('free ok\n')

        # printf('[B] split samples\n')
        left_samples = <SIZE_t*>malloc( node.n_samples * sizeof(SIZE_t))
        right_samples = <SIZE_t*>malloc( node.n_samples * sizeof(SIZE_t))
        left_valid_batch = <SIZE_t*>malloc(n_batch*sizeof(SIZE_t))
        right_valid_batch = <SIZE_t*>malloc(n_batch*sizeof(SIZE_t))
        n_all_left = <SIZE_t*>malloc(n_batch*sizeof(SIZE_t))
        n_all_right = <SIZE_t*>malloc(n_batch*sizeof(SIZE_t))
        n_left_valid_batch = 0
        n_right_valid_batch = 0

        last_loc = -1
        for i in range(n_valid_batch):
            loc = valid_batch[i]

            if loc > 0:
               if last_loc == -1:
                  for j in range(0, loc):
                      n_all_left[j] = N_left_samples
                      n_all_right[j] = N_right_samples
               else:
                  for j in range(last_loc, loc):
                      n_all_left[j] = N_left_samples
                      n_all_right[j] = N_right_samples

            if loc == 0:
               init_loc = 0
               n_loc = n_all[loc]
            else:
               init_loc = node.n_all[loc-1]
               n_loc = n_all[loc] - n_all[loc-1]


            for j in range(n_loc):
                # add sample to the left branch
                if X[samples[init_loc+j]][node.chosen_feature.index] <= node.chosen_threshold.value:
                   left_samples[N_left_samples] = samples[init_loc+j]
                   N_left_samples += 1

                # add sample to the right branch
                else:
                   right_samples[N_right_samples] = samples[init_loc+j]
                   N_right_samples += 1

            if (N_left_samples>0 and last_loc==-1) or (last_loc>-1 and N_left_samples - n_all_left[last_loc] > 0) :
               left_valid_batch[n_left_valid_batch] = loc
               n_left_valid_batch += 1

            if (N_right_samples>0 and last_loc==-1) or (last_loc>-1 and N_right_samples - n_all_right[last_loc] > 0):
               right_valid_batch[n_right_valid_batch] = loc
               n_right_valid_batch += 1

            last_loc = loc
        for i in range(loc, self.config.n_batch):
            n_all_left[i] = N_left_samples
            n_all_right[i] = N_right_samples

        left_valid_batch = <SIZE_t*>realloc(left_valid_batch, n_left_valid_batch*sizeof(SIZE_t))
        right_valid_batch = <SIZE_t*>realloc(right_valid_batch, n_right_valid_batch*sizeof(SIZE_t))
        left_samples = <SIZE_t*>realloc(left_samples, N_left_samples*sizeof(SIZE_t))
        right_samples = <SIZE_t*>realloc(right_samples, N_right_samples*sizeof(SIZE_t))

        free(samples)

        # traverse to left and right branches
        if node.end >= n_batch-1:
           new_start = 0
        else:
           new_start = node.end + 1

        node.left = self.tree_builder._build(X, y, left_samples, depth + 1, 1, new_start,
                                      n_left_valid_batch,left_valid_batch, n_all_left, N_left_samples)

        node.right = self.tree_builder._build(X, y, right_samples, depth + 1, 0, new_start,
                                        n_right_valid_batch, right_valid_batch, n_all_right, N_right_samples)

    cdef void retrain1(self,
                      Node**    node_ptr,
                      DTYPE_t** X,
                      INT32_t*  y,
                      Node**   root_ptr) nogil:
        """
            - Retrain this node.
        """
        cdef Node*  node
        node = node_ptr[0]
        cdef SIZE_t i

        # node properties
        cdef SIZE_t  n_batch = self.config.n_batch
        cdef SIZE_t  n_samples = node.n_samples
        cdef SIZE_t  depth = node.depth
        cdef bint    is_left = node.is_left
        cdef SIZE_t  start = node.start
        cdef SIZE_t  n_valid_batch = node.n_valid_batch
        cdef SIZE_t* valid_batch = copy_indices(node.valid_batch, n_valid_batch)
        cdef SIZE_t* n_all = copy_indices(node.n_all, n_batch)

        cdef IntList* remove_samples = node.delete_samples
        cdef SIZE_t  u_s

        # updated array of leaf samples
        # printf('get leaf\n')
        cdef SIZE_t*    leaf_samples = <SIZE_t*>malloc(n_samples*sizeof(SIZE_t))
        cdef SIZE_t*    n_leaf_samples = <SIZE_t*>malloc(n_batch*sizeof(SIZE_t))

        u_s = node.n_samples   # 更新过了================================================
        self.manager.count_samples(u_s)
        self.manager.count_data(1)
        # cdef SIZE_t n_this_delete = node.delete_samples.n

        # label the remove_sample================================================
        cdef SIZE_t clear_sample
        cdef Node*  root = root_ptr[0]
        for i in range(remove_samples.n):
            clear_sample = remove_samples.arr[i]
            root.in_table[clear_sample] = 0
        # ==========================================================
        # printf('get samples\n')
        for i in range(n_batch):
            n_leaf_samples[i] = 0
        get_leaf_samples(node, remove_samples, node.adv_length, n_all, leaf_samples, n_leaf_samples, node.depth, &root)
        # =======================================================================

        free(n_leaf_samples)

        # free descendant nodes
        dealloc(node)
        free_intlist(node.delete_samples)

        self.tree_builder._build2(&node, X, y, leaf_samples)
# ==========================================伴随🔺的重训练============================================================
# 更新结点统计信息
# 增加delete——sample用于回收样本
# 三角形置换为五角星（现在肯定是空的）
# 齐活

    cdef void retrain2(self,
                      Node**    node_ptr,
                      DTYPE_t** X,
                      INT32_t*  y,
                      Node**   root_ptr) nogil:
        """
            - Retrain this node.
        """

        cdef Node*  node
        node = node_ptr[0]
        cdef SIZE_t i

        self.update_node2(node, y)
        # printf('[retrain2] node.depth:%d, node.n_samples:%d\n', node.depth,node.n_samples)
        # label the remove_sample================================================
        cdef SIZE_t clear_sample
        cdef Node*  root = root_ptr[0]
        for i in range(node.delete_samples.n):
            clear_sample = node.delete_samples.arr[i]
            root.in_table[clear_sample] = 0

        for i in range(node.later_samples.n):
           # delete增加later，进行一并重训练
           node.delete_samples.arr[node.delete_samples.n] = node.later_samples.arr[i]
           node.delete_samples.n += 1
           # change 成星星的设为2，节省三角清空的访问==================未实现
           clear_sample = node.later_samples.arr[i]
           root.in_table[clear_sample] = 2

        # node properties
        cdef SIZE_t  n_batch = self.config.n_batch
        cdef SIZE_t  n_samples = node.n_samples
        cdef SIZE_t  depth = node.depth
        cdef bint    is_left = node.is_left
        cdef SIZE_t  start = node.start
        cdef SIZE_t  n_valid_batch = node.n_valid_batch
        cdef SIZE_t* valid_batch = copy_indices(node.valid_batch, n_valid_batch)
        cdef SIZE_t* n_all = copy_indices(node.n_all, n_batch)

        cdef IntList* remove_samples = node.delete_samples
        cdef SIZE_t  u_s

        # updated array of leaf samples
        # printf('get leaf\n')
        cdef SIZE_t*    leaf_samples = <SIZE_t*>malloc(n_samples*sizeof(SIZE_t))
        cdef SIZE_t*    n_leaf_samples = <SIZE_t*>malloc(n_batch*sizeof(SIZE_t))

        # 更新过了================================================
        u_s = node.n_samples
        self.manager.count_samples(u_s)
        self.manager.count_data(1)

        # ==========================================================
        for i in range(n_batch):
            n_leaf_samples[i] = 0
        get_leaf_samples(node, remove_samples, node.adv_length, n_all, leaf_samples, n_leaf_samples, node.depth, &root)
        node.adv_length = node.later_samples.n
        free(n_leaf_samples)

        # free descendant nodes
        dealloc(node)  # node.adv_length 不变
        free_intlist(node.delete_samples)
        free_intlist(node.later_samples)

        self.tree_builder._build2(&node, X, y, leaf_samples)

# ============================================利用▲更新结点信息===============================================
# （n_valid_batch,valid_batch,n_all,n_samples） ♥initial_node2简化
# 更新 n_all,n_samples,valid_batch,n_valid_batch(node.start不变，重建会更新)
    cdef void update_node2(self,
                          Node*     node,
                          INT32_t*  y) nogil:
        """
        Update node counts based on the `remove_samples` being deleted.
        """

        cdef IntList* remove_samples = node.later_samples

        # compute number of positive samples being deleted
        cdef SIZE_t i
        cdef SIZE_t j
        cdef SIZE_t n_pos_remove_samples = 0

        cdef SIZE_t   n_each_batch = self.manager.n_each_batch
        cdef SIZE_t   n_batch = self.config.n_batch
        cdef SIZE_t   G_number

        cdef SIZE_t*  new_valid_batch
        cdef SIZE_t   n_new_valid_batch = 0
        cdef IntList* invalid_batch = create_intlist(node.n_valid_batch, 0)
        cdef bint     add_batch

        for i in range(remove_samples.n):
            n_pos_remove_samples += y[remove_samples.arr[i]]

            G_number = remove_samples.arr[i]/n_each_batch
            if G_number > n_batch -1:
               G_number = n_batch -1

            for j in range(G_number, n_batch):
                node.n_all[j] -= 1

            if ((G_number == 0 and node.n_all[G_number] == 0) or
                (G_number>0 and node.n_all[G_number] - node.n_all[G_number-1] == 0)):
               invalid_batch.arr[invalid_batch.n] = G_number
               invalid_batch.n += 1

        node.n_samples -= remove_samples.n
        node.n_pos_samples -= n_pos_remove_samples

        if invalid_batch.n > 0:
           node.n_valid_batch -= invalid_batch.n
           new_valid_batch =  <SIZE_t*>malloc(node.n_valid_batch*sizeof(SIZE_t))
           for i in range(node.n_valid_batch+invalid_batch.n):
               add_batch = True
               for j in range(invalid_batch.n):
                   if node.valid_batch[i] == invalid_batch.arr[j]:
                      add_batch = False
                      break
               if add_batch:
                  new_valid_batch[n_new_valid_batch] = node.valid_batch[i]
                  n_new_valid_batch += 1
           free(node.valid_batch)
           node.valid_batch = new_valid_batch
        free_intlist(invalid_batch)



    cdef INT32_t contains_valid_split(self,
                                      Node*     node,
                                      DTYPE_t** X,
                                      INT32_t*  y,
                                      IntList*  samples) nogil:
        """
        Checks to see if the chosen feature is still valid (not constant);
            - If valid, then it chooses a different threshold value.
            - If not valid, then 0 is returned.
        """

        # return 1 if valid, 0 otherwise
        cdef INT32_t result = 1
        cdef SIZE_t  feature_index = node.chosen_feature.index

        # incrementers
        cdef SIZE_t i = 0
        cdef SIZE_t    n_left_samples = 0
        cdef SIZE_t    n_right_samples = 0

        # min. max. indicators
        cdef DTYPE_t min_val = INFINITY
        cdef DTYPE_t max_val = -INFINITY
        cdef DTYPE_t cur_val = 0

        # threshold variables
        cdef UINT32_t* random_state = &self.config.rand_r_state
        cdef DTYPE_t   threshold_value = 0

        # find min. and max. values
        for i in range(samples.n):
            cur_val = X[samples.arr[i]][feature_index]

            if cur_val < min_val:
                min_val = cur_val

            elif cur_val > max_val:
                max_val = cur_val

        # invalid: constant feature
        if max_val <= min_val + FEATURE_THRESHOLD:
            result = 0

        # valid feature
        else:

            # keep sampling until a valid threshold is found
            threshold_value = <DTYPE_t>rand_uniform(min_val, max_val, random_state)
            while threshold_value >= max_val or threshold_value < min_val:
                threshold_value = <DTYPE_t>rand_uniform(min_val, max_val, random_state)

            # count left and right branches
            for i in range(samples.n):
                if X[samples.arr[i]][feature_index] <= threshold_value:
                    n_left_samples += 1
                else:
                    n_right_samples += 1

            # printf('n_left_samples: %lu, n_right_samples: %lu\n', n_left_samples, n_right_samples)

            # update node properties
            free_feature(node.chosen_feature)
            free(node.chosen_threshold)
            node.chosen_feature = create_feature(feature_index)
            node.chosen_threshold = create_threshold(threshold_value, n_left_samples, n_right_samples)

        return result


    cdef SIZE_t select_optimal_split(self,
                                     Node* node) nogil:
        """
        Select the optimal attribute-threshold pair.

        Return 1 if the selected optimal split has changed, 0 otherwise.
        """

        # parameters
        cdef bint    use_gini = self.config.use_gini
        cdef SIZE_t  topd = self.config.topd

        # keep track of the best feature / threshold
        cdef DTYPE_t best_score = 1000000
        cdef DTYPE_t split_score = -1

        # object pointers
        cdef Feature*   feature = NULL
        cdef Feature*   chosen_feature = NULL
        cdef Threshold* threshold = NULL
        cdef Threshold* chosen_threshold = NULL

        # counters
        cdef SIZE_t j = 0
        cdef SIZE_t k = 0

        # return variable
        cdef SIZE_t result = 0

        # greedy node, find the optimal attribute-threshold pair
        if node.depth >= topd:
            best_score = 1000000

            # get thresholds for each feature
            for j in range(node.n_features):
                feature = node.features[j]

                # compute split score for each threshold
                for k in range(feature.n_thresholds):
                    threshold = feature.thresholds[k]

                    # compute split score, entropy or Gini index
                    split_score = compute_split_score(use_gini,
                                                      node.n_cur_samples,
                                                      threshold.n_left_samples,
                                                      threshold.n_right_samples,
                                                      threshold.n_left_pos_samples,
                                                      threshold.n_right_pos_samples)

                    # save if its the best score
                    if split_score < best_score:
                        best_score = split_score
                        chosen_feature = feature
                        chosen_threshold = threshold

            # optimal split has changed
            if not (node.chosen_feature.index == chosen_feature.index and
                node.chosen_threshold.value == chosen_threshold.value):
                result = 1

                # replace chosen split node properties
                free_feature(node.chosen_feature)
                free(node.chosen_threshold)
                node.chosen_feature = copy_feature(chosen_feature)
                node.chosen_threshold = copy_threshold(chosen_threshold)

        return result


    cdef SIZE_t update_metadata(self,
                                Node*     node,
                                DTYPE_t** X,
                                INT32_t*  y,
                                IntList*  remove_samples) nogil:
        """
        Update each feature / threshold and return the number of usable thresholds.
        """

        # return variable
        cdef SIZE_t n_usable_thresholds = 0

        if node.depth >= self.config.topd:
           n_usable_thresholds = self.update_greedy_node_metadata(node, X, y, remove_samples)

        else:
           n_usable_thresholds = self.update_random_node_metadata(node, X, y, remove_samples)

        return n_usable_thresholds

    cdef SIZE_t update_greedy_node_metadata(self,
                                            Node*     node,
                                            DTYPE_t** X,
                                            INT32_t*  y,
                                            IntList*  remove_samples) nogil:
        """
        Update each threshold for all features at this node.
        """

        # class properties
        cdef SIZE_t   k_samples = self.config.k
        cdef SIZE_t   min_samples_leaf = self.config.min_samples_leaf
        cdef SIZE_t   n_total_features = self.manager.n_features

        # counters
        cdef SIZE_t i = 0
        cdef SIZE_t j = 0
        cdef SIZE_t k = 0

        # object pointers
        cdef Feature*    feature = NULL
        cdef Threshold*  threshold = NULL

        # variables to keep track of invalid thresholds
        cdef DTYPE_t v1_label_ratio = -1
        cdef DTYPE_t v2_label_ratio = -1
        cdef SIZE_t* threshold_validities = NULL
        cdef SIZE_t  n_invalid_thresholds = 0
        cdef SIZE_t  n_valid_thresholds = 0
        cdef SIZE_t  n_new_thresholds = 0

        # invalid features
        cdef IntList* invalid_features = create_intlist(node.n_features, 0)

        # return variables
        cdef SIZE_t n_usable_thresholds = 0

        # printf('[R - UM] node.n_features: %ld\n', node.n_features)

        # update statistics for each feature
        for j in range(node.n_features):
            feature = node.features[j]

            # array holding indices of invalid thresholds for this feature
            threshold_validities = <SIZE_t *>malloc(feature.n_thresholds * sizeof(SIZE_t))

            # initialize counters
            n_invalid_thresholds = 0
            n_valid_thresholds = 0

            # printf('[R - UM] feature.index: %ld, feature.n_thresholds: %ld\n',
            #        feature.index, feature.n_thresholds)

            # update statistics for each threshold in this feature
            for k in range(feature.n_thresholds):
                threshold = feature.thresholds[k]

                # loop through each deleted sample
                for i in range(remove_samples.n):

                    # decrement left branch of this threshold
                    if X[remove_samples.arr[i]][feature.index] <= threshold.value:
                        threshold.n_left_samples -= 1
                        threshold.n_left_pos_samples -= y[remove_samples.arr[i]]

                    # decrement right branch of this threshold
                    else:
                        threshold.n_right_samples -= 1
                        threshold.n_right_pos_samples -= y[remove_samples.arr[i]]

                    # decrement left value of this threshold
                    if X[remove_samples.arr[i]][feature.index] == threshold.v1:
                        threshold.n_v1_samples -= 1
                        threshold.n_v1_pos_samples -= y[remove_samples.arr[i]]

                    # decrement right value of this threshold
                    elif X[remove_samples.arr[i]][feature.index] == threshold.v2:
                        threshold.n_v2_samples -= 1
                        threshold.n_v2_pos_samples -= y[remove_samples.arr[i]]

                # compute label ratios for adjacent values of the threshold
                v1_label_ratio = threshold.n_v1_pos_samples / (1.0 * threshold.n_v1_samples)
                v2_label_ratio = threshold.n_v2_pos_samples / (1.0 * threshold.n_v2_samples)

                # check to see if threshold is still valid
                threshold_validities[k] = ((threshold.n_left_samples >= min_samples_leaf and
                                            threshold.n_right_samples >= min_samples_leaf) and
                                           (v1_label_ratio != v2_label_ratio or
                                           (v1_label_ratio > 0.0 and v2_label_ratio < 1.0)))

                # printf('[R - UGNM] threshold %.5f, n_left_samples: %ld, n_right_samples: %ld, valid: %ld\n',
                #        threshold.value, threshold.n_left_samples, threshold.n_right_samples, threshold_validities[k])

                # invalid threshold
                if not threshold_validities[k]:
                    n_invalid_thresholds += 1

                # valid threshold
                else:
                    n_valid_thresholds += 1
                    n_usable_thresholds += 1

            # invalid thresholds, sample new viable thresholds, if any
            if n_invalid_thresholds > 0:
                #printf('select new thresholds\n')
                # printf('[R - UGNM] n_invalid_thresholds: %ld, feature_loc:%d\n', n_invalid_thresholds, j)

                # no other candidate thresholds for this feature
                if feature.n_thresholds < k_samples:

                    # remove invalid thresholds from this feature
                    if n_invalid_thresholds < feature.n_thresholds:
                        #printf('[R - UGNM] no other candidates, remove invalid thresholds\n')
                        remove_invalid_thresholds(feature, n_valid_thresholds, threshold_validities)

                    # all thresholds invalid and no candidate thresholds, flag feature for replacement
                    else:
                        # printf('[R - UGNM] no other candidates, flag feature for replacement\n')
                        invalid_features.arr[invalid_features.n] = feature.index
                        invalid_features.n += 1

                # possibly other thresholds, sample new thresholds for this feature
                else:
                    #printf('[R - UGNM] possibly other thresholds, sample new thresholds\n')
                    n_new_thresholds = sample_new_thresholds(feature, n_valid_thresholds,
                                                             threshold_validities, node, X, y,
                                                             remove_samples, NULL, self.config)

                    #printf('n_new_threshold:%d\n', n_new_thresholds)
                    # all thresholds invalid, flag feature for replacement
                    if n_new_thresholds == 0 and n_valid_thresholds == 0:
                        # printf('[R - UGNM] all thresholds invalid, flag feature for replacement\n')
                        invalid_features.arr[invalid_features.n] = feature.index
                        invalid_features.n += 1

                    # 储存这个feature index和 new threshold 范围
                    # increment no. usable thresholds
                    n_usable_thresholds += n_new_thresholds

            # clean up
            free(threshold_validities)

        # replace invalid features
        # printf('[R - UGNM] invalid_features.n: %ld\n', invalid_features.n)
        if invalid_features.n > 0:
            #printf('select new feature\n')
            n_usable_thresholds += sample_new_features(&node.features, &node.constant_features,
                                                       invalid_features, n_total_features, node, X, y,
                                                       remove_samples, self.config)

            # printf('[R - UGNM] node.n_features: %ld\n', node.n_features)

            # no usable thresholds if there are no valid features
            if node.n_features == 0:
                n_usable_thresholds = 0

        # clean up
        free_intlist(invalid_features)

        return n_usable_thresholds

    cdef SIZE_t update_random_node_metadata(self,
                                            Node*     node,
                                            DTYPE_t** X,
                                            INT32_t*  y,
                                            IntList*  remove_samples) nogil:
        """
        Update the metadata for the chosen feature / threshold of the
        random node.
        """

        # configuration
        cdef SIZE_t min_samples_leaf = self.config.min_samples_leaf

        # return variable
        cdef SIZE_t n_usable_thresholds = 1

        # loop through samples to be removed
        for i in range(remove_samples.n):

            # decrement left branch sample count
            if X[remove_samples.arr[i]][node.chosen_feature.index] <= node.chosen_threshold.value:
                node.chosen_threshold.n_left_samples -= 1

            # decrement right branch sample count
            else:
                node.chosen_threshold.n_right_samples -= 1

        # not enough samples in both branches, invalid threshold
        if (node.chosen_threshold.n_left_samples < min_samples_leaf or
            node.chosen_threshold.n_right_samples < min_samples_leaf):

            # retrain
            n_usable_thresholds = -1

        return n_usable_thresholds

    cdef void add_metric(self,
                         INT32_t remove_type,
                         INT32_t remove_depth,
                         INT32_t remove_cost) nogil:
        """
        Add type and depth to the removal metrics.
        """
        if self.remove_types:
            if self.remove_count + 1 == self.capacity:
                self.capacity *= 2

            self.remove_types = <INT32_t *>realloc(self.remove_types, self.capacity * sizeof(INT32_t))
            self.remove_depths = <INT32_t *>realloc(self.remove_depths, self.capacity * sizeof(INT32_t))
            self.remove_costs = <INT32_t *>realloc(self.remove_costs, self.capacity * sizeof(INT32_t))

        else:
            self.capacity = 10
            self.remove_types = <INT32_t *>malloc(self.capacity * sizeof(INT32_t))
            self.remove_depths = <INT32_t *>malloc(self.capacity * sizeof(INT32_t))
            self.remove_costs = <INT32_t *>malloc(self.capacity * sizeof(INT32_t))

        self.remove_types[self.remove_count] = remove_type
        self.remove_depths[self.remove_count] = remove_depth
        self.remove_costs[self.remove_count] = remove_cost
        self.remove_count += 1

    cpdef void clear_metrics(self):
        """
        Resets deletion statistics.
        """
        free(self.remove_types)
        free(self.remove_depths)
        free(self.remove_costs)
        self.remove_count = 0
        self.remove_types = NULL
        self.remove_depths = NULL
        self.remove_costs = NULL

    cdef np.ndarray get_int_ndarray(self,
                                    INT32_t* data,
                                    SIZE_t   n_elem):
        """
        Wraps value as a 1-d NumPy array.
        The array keeps a reference to this Tree, which manages the underlying memory.
        """
        cdef SIZE_t shape[1]
        shape[0] = n_elem
        cdef np.ndarray arr = np.PyArray_SimpleNewFromData(1, shape, np.NPY_INT, data)
        Py_INCREF(self)
        arr.base = <PyObject*> self
        return arr


# helper methods
cdef void remove_invalid_thresholds(Feature* feature,
                                    SIZE_t   n_valid_thresholds,
                                    SIZE_t*  threshold_validities) nogil:
    """
    Removes the invalid thresholds from this feature.
    """

    # create final thresholds array
    cdef Threshold** new_thresholds = <Threshold **>malloc(n_valid_thresholds  * sizeof(Threshold *))
    cdef SIZE_t      n_new_thresholds = 0

    # counters
    cdef SIZE_t k = 0

    # filter out invalid thresholds and free original thresholds array
    for k in range(feature.n_thresholds):

        # add valid threshold to final thresholds
        if threshold_validities[k] == 1:
            new_thresholds[n_new_thresholds] = copy_threshold(feature.thresholds[k])
            n_new_thresholds += 1

    # free thresholds array
    free_thresholds(feature.thresholds, feature.n_thresholds)

    # save new thresholds array to the feature
    feature.thresholds = new_thresholds
    feature.n_thresholds = n_new_thresholds


cdef SIZE_t sample_new_thresholds(Feature*  feature,
                                  SIZE_t    n_valid_thresholds,
                                  SIZE_t*   threshold_validities,
                                  Node*     node,
                                  DTYPE_t** X,
                                  INT32_t*  y,
                                  IntList*  remove_samples,
                                  bint*     is_constant_feature_ptr,
                                  _Config   config) nogil:
    """
    Try to sample new thresholds for all invalid thresholds for this feature.
    """

    # configuration
    cdef SIZE_t    k_samples = config.k
    cdef SIZE_t    min_samples_leaf = config.min_samples_leaf
    cdef UINT32_t* random_state = &config.rand_r_state

    # iterators
    cdef SIZE_t  i = 0
    cdef SIZE_t  j = 0
    cdef SIZE_t  k = 0

    # samplers
    cdef INT32_t ndx = 0

    # candidate threshold variables
    cdef Threshold** candidate_thresholds = NULL
    cdef SIZE_t      n_candidate_thresholds = 0

    # unused candidate threshold array variables
    cdef Threshold** unused_thresholds = NULL
    cdef SIZE_t      n_unused_thresholds = 0
    cdef SIZE_t      n_unused_thresholds_to_sample = 0
    cdef SIZE_t      n_vacancies = 0

    # variables for tracking
    cdef IntList*    sampled_indices = NULL
    cdef bint        valid = True

    # result variables
    cdef Threshold** new_thresholds = NULL
    cdef SIZE_t      n_new_thresholds = 0

    # return variable
    cdef SIZE_t n_usable_thresholds = 0

    # get updated samples for this node
    cdef SIZE_t   start = node.start
    cdef SIZE_t   end = node.end
    cdef IntList* remove_samples1 = create_intlist(1000, 0)
    for i in range(remove_samples.n):
        remove_samples1.arr[remove_samples1.n] = remove_samples.arr[i]
        remove_samples1.n += 1
    # printf('get samples to select splits, start:%d, end:%d\n', start, end)
    cdef IntList* samples = create_intlist(node.n_cur_samples, 0)  # 不用区分顺序，用完即焚
    if end >= start:
       # find valid_batch : start<=loc<=end
       get_leaf_samples2(node, remove_samples1, samples, start, end, node.depth)
    else:
       # printf('get leafs 3\n')
       # find valid_batch : loc<=end or loc>=start
       get_leaf_samples3(node, remove_samples1, samples, start, end, node.depth)
    # printf('get samples ok \n')
    # printf('n_cur_samples:%d,   really samples.n:%d\n', node.n_cur_samples, samples.n)
    free_intlist(remove_samples1)

    # helper variables
    cdef DTYPE_t* values = <DTYPE_t *>malloc(samples.n * sizeof(DTYPE_t))
    cdef INT32_t* labels = <INT32_t *>malloc(samples.n * sizeof(INT32_t))
    cdef SIZE_t*  indices = <SIZE_t *>malloc(samples.n * sizeof(SIZE_t))
    cdef SIZE_t   n_pos_samples = 0

    # copy values and labels into new arrays, and count no. pos. labels
    for i in range(samples.n):
        values[i] = X[samples.arr[i]][feature.index]
        labels[i] = y[samples.arr[i]]
        indices[i] = i
        n_pos_samples += y[samples.arr[i]]

    # sort feature values, and their corresponding indices
    sort(values, indices, samples.n)

    # constant feature
    if values[samples.n - 1] <= values[0] + FEATURE_THRESHOLD:
        if is_constant_feature_ptr != NULL:
            is_constant_feature_ptr[0] = True

    # get candidate thresholds
    candidate_thresholds = <Threshold **>malloc(samples.n * sizeof(Threshold *))
    n_candidate_thresholds = get_candidate_thresholds(values, labels, indices,
                                                      samples.n, n_pos_samples,
                                                      min_samples_leaf, &candidate_thresholds)

    # array of candidate thresholds that are not being used
    unused_thresholds = <Threshold **>malloc(n_candidate_thresholds * sizeof(Threshold *))
    n_unused_thresholds = 0

    # filter out already used thresholds
    for i in range(n_candidate_thresholds):
        used = False

        # disregard threshold if it is already being used by the feature
        for k in range(feature.n_thresholds):
            if feature.thresholds[k].value == candidate_thresholds[i].value:
                used = True
                break

        # add candidate threshold to list of unused candidate thresholds
        if not used:
            unused_thresholds[n_unused_thresholds] = candidate_thresholds[i]
            n_unused_thresholds += 1

    # compute number of unused thresholds to sample
    n_vacancies = k_samples - n_valid_thresholds
    if n_unused_thresholds > n_vacancies:
        n_unused_thresholds_to_sample = n_vacancies
    else:
        n_unused_thresholds_to_sample = n_unused_thresholds

    # allocate memory for the new thresholds array
    n_new_thresholds = n_unused_thresholds_to_sample + n_valid_thresholds
    new_thresholds = <Threshold **>malloc(n_new_thresholds * sizeof(Threshold *))
    sampled_indices = create_intlist(n_unused_thresholds_to_sample, 0)

    # sample unused threshold indices uniformly at random
    i = 0
    while sampled_indices.n < n_unused_thresholds_to_sample:
        valid = True

        # sample an unused threshold index
        ndx = rand_int(0, n_unused_thresholds, random_state)

        # invalid: already sampled
        for k in range(sampled_indices.n):
            if ndx == sampled_indices.arr[k]:
                valid = False
                break

        # valid: copy threshold to new thresholds
        if valid:
            new_thresholds[sampled_indices.n] = copy_threshold(unused_thresholds[ndx])
            sampled_indices.arr[sampled_indices.n] = ndx
            sampled_indices.n += 1
            i += 1

    # add original thresholds to the new thresholds array
    for k in range(feature.n_thresholds):

        # original valid threshold
        if threshold_validities[k] == 1:
            new_thresholds[i] = copy_threshold(feature.thresholds[k])
            i += 1

    # free previous thresholds and candidate thresholds arrays
    free_thresholds(feature.thresholds, feature.n_thresholds)
    free_thresholds(candidate_thresholds, n_candidate_thresholds)

    # clean up
    free(values)
    free(labels)
    free(indices)
    free(unused_thresholds)
    free_intlist(samples)
    free_intlist(sampled_indices)

    # set new thresholds array for this feature
    feature.thresholds = new_thresholds
    feature.n_thresholds = n_new_thresholds

    return n_unused_thresholds_to_sample


cdef SIZE_t sample_new_features(Feature*** features_ptr,
                                IntList**  constant_features_ptr,
                                IntList*   invalid_features,
                                SIZE_t     n_total_features,
                                Node*      node,
                                DTYPE_t**  X,
                                INT32_t*   y,
                                IntList*   remove_samples,
                                _Config    config) nogil:
    """
    Sample new unused features to replace the invalid features.
    """

    # configuration
    cdef SIZE_t max_features = config.max_features
    cdef UINT32_t* random_state = &config.rand_r_state

    # indexers
    cdef SIZE_t feature_index = 0
    cdef SIZE_t invalid_feature_index = 0

    # counters
    cdef SIZE_t i = 0
    cdef SIZE_t j = 0
    cdef SIZE_t k = 0
    cdef SIZE_t n_used_invalid_features = 0

    # keeps track of invalid features
    cdef IntList* constant_features = copy_intlist(constant_features_ptr[0], n_total_features)
    cdef IntList* sampled_features = create_intlist(n_total_features, 0)
    cdef SIZE_t   n_features = node.n_features - invalid_features.n
    cdef bint     is_constant_feature = False
    cdef bint     valid = False

    # old and new features array
    cdef Feature** features = features_ptr[0]
    cdef Feature** new_features = NULL
    cdef SIZE_t    n_new_features = 0

    # return variable
    cdef SIZE_t   n_usable_thresholds = 0

    # printf('[R - SNF] node.n_features: %ld, invalid_features.n: %ld\n', node.n_features, invalid_features.n)

    # add valid and invalid features to the list of sampled features
    for j in range(node.n_features):
        sampled_features.arr[sampled_features.n] = node.features[j].index
        sampled_features.n += 1

    # sample features until the previous no. features is reached or there are no features left
    while n_features < node.n_features and (sampled_features.n + constant_features.n) < n_total_features:

        # sample feature index
        feature_index = rand_int(0, n_total_features, random_state)

        # already sampled feature
        valid = True
        for i in range(sampled_features.n):
            if sampled_features.arr[i] == feature_index:
                valid = False
                break
        if not valid:
            continue

        # known constant feature
        valid = True
        for i in range(constant_features.n):
            if constant_features.arr[i] == feature_index:
                valid = False
                break
        if not valid:
            continue

        # create a feature and sample thresholds
        feature = create_feature(feature_index)
        # printf('sample new thresholds\n')
        sample_new_thresholds(feature, 0, NULL, node, X, y, remove_samples, &is_constant_feature, config)
        # printf('sample ok\n')
        # printf('[R - SNF] is_constant_feature: %d\n', is_constant_feature)

        # constant feature
        if is_constant_feature:
            constant_features.arr[constant_features.n] = feature_index
            constant_features.n += 1
            free_feature(feature)
            continue

        # add to sampled features array
        sampled_features.arr[sampled_features.n] = feature_index
        sampled_features.n += 1

        # no valid thresholds, free feature and sample a new feature
        if feature.n_thresholds == 0:
            # printf('[R - SNF] no valid thresholds, free_feature\n')
            free_feature(feature)
            continue

        # printf('[R - SNF] feature.n_thresholds: %ld\n', feature.n_thresholds)

        # get invalid feature index
        invalid_feature_index = invalid_features.arr[n_used_invalid_features]
        n_used_invalid_features += 1

        # replace the invalid feature with a valid one
        for j in range(node.n_features):
            if features[j].index == invalid_feature_index:
                free_feature(features[j])
                features[j] = feature
                n_features += 1
                n_usable_thresholds += feature.n_thresholds
                break


    # could not replace all invalid features, remove remaining invalid features
    if n_features < node.n_features:

        #printf('[R - SNF] n_features: %ld, node.n_features: %ld\n', n_features, node.n_features)

        # new (smaller) features array
        new_features = <Feature **>malloc(n_features * sizeof(Feature *))
        n_new_features = 0

        # copy valid features to this new array
        for j in range(node.n_features):
            valid = True

            # invalid feature
            for k in range(invalid_features.n):
                if features[j].index == invalid_features.arr[k]:
                    valid = False
                    break

            # copy valid feature to new features array
            if valid:
                new_features[n_new_features] = copy_feature(features[j])
                n_new_features += 1


        # free previous features
        free_features(features, node.n_features)

        # set features to new features array
        features_ptr[0] = new_features

    # printf('[R - SNF] freeing constant_features\n')

    # free previous constant features array and set new constant features array
    free_intlist(constant_features_ptr[0])
    constant_features_ptr[0] = copy_intlist(constant_features, constant_features.n)

    # set no. features
    node.n_features = n_features

    # clean up
    free_intlist(sampled_features)
    free_intlist(constant_features)

    return n_usable_thresholds


cdef SIZE_t get_node_count(Node* node) nogil:
        """
        Count total no. of nodes in the tree.
        """
        if not node:
            return 0
        else:
            return 1 + get_node_count(node.left) + get_node_count(node.right)


# for all leaf_samples
cdef void get_leaf_samples(Node*        node,
                           IntList*     remove_samples,
                           SIZE_t       remove_start,
                           SIZE_t*      n_all,
                           SIZE_t*      leaf_samples,
                           SIZE_t*      n_leaf_samples,
                           SIZE_t       initial_depth,
                           Node**       root_ptr) nogil:
    """
    Recursively obtain the samples at the leaves and filter out
    deleted samples.
    """
    cdef bint   add_sample = True
    cdef SIZE_t i = 0
    cdef SIZE_t j = 0
    cdef SIZE_t k = 0
    cdef SIZE_t loc
    cdef SIZE_t init_loc       # loc_init（这个loc原始点对应的初始位置）
    cdef SIZE_t init_loc_this  # loc_init（这个loc对应的初始位置）
    cdef SIZE_t n_loc          # n（这个loc对应的样本数）
    cdef Node* root = root_ptr[0]
    cdef SIZE_t clear_sample

    # leaf
    if node.is_leaf:

        # loop through all samples at this leaf
        for i in range(node.n_valid_batch):
            loc = node.valid_batch[i]
            if loc == 0:
               init_loc = 0
               init_loc_this = 0
               n_loc = node.n_all[loc]
            else:
               init_loc = n_all[loc-1]
               init_loc_this = node.n_all[loc-1]
               n_loc = node.n_all[loc] - node.n_all[loc-1]
            for j in range(init_loc_this, init_loc_this+n_loc):
                add_sample = True
                # ♥
                for k in range(remove_samples.n):
                    if node.leaf_samples[j] == remove_samples.arr[k]:
                       add_sample = False
                       break
                if add_sample:
                   leaf_samples[init_loc+n_leaf_samples[loc]] = node.leaf_samples[j]
                   n_leaf_samples[loc] += 1
    # decision node
    else:

        # traverse left♥
        if node.left:
            get_leaf_samples(node.left, remove_samples, remove_start, n_all, leaf_samples, n_leaf_samples, initial_depth, &root)

        # traverse right
        if node.right:
            get_leaf_samples(node.right, remove_samples, remove_start,  n_all, leaf_samples, n_leaf_samples, initial_depth, &root)


cdef void get_leaf_samples2(Node*     node,
                           IntList*   remove_samples,
                           IntList*   samples,
                           SIZE_t     start,
                           SIZE_t     end,
                           SIZE_t     initial_depth) nogil:
    """
    Recursively obtain the samples at the leaves and filter out
    deleted samples. Returns array and a number, instead of an IntList.
    """
    cdef bint   add_sample = True
    cdef SIZE_t i = 0
    cdef SIZE_t j = 0
    cdef SIZE_t start_loc
    cdef SIZE_t end_loc

    # leaf
    if node.is_leaf:

        if start == 0:
           start_loc = 0
        else:
           start_loc = node.n_all[start-1]
        end_loc = node.n_all[end]

        # loop through all samples of G_number batch at this leaf
        for i in range(start_loc, end_loc):
            add_sample = True
            for j in range(remove_samples.n):
                if node.leaf_samples[i] == remove_samples.arr[j]:
                   add_sample = False
                   break
            if add_sample:
               samples.arr[samples.n] = node.leaf_samples[i]
               samples.n += 1

    # decision node
    else:

        # traverse left
        if node.left:
            get_leaf_samples2(node.left, remove_samples, samples, start, end, initial_depth)

        # traverse right
        if node.right:
            get_leaf_samples2(node.right, remove_samples, samples, start, end, initial_depth)


cdef void get_leaf_samples3(Node*     node,
                           IntList*   remove_samples,
                           IntList*   samples,
                           SIZE_t     start,
                           SIZE_t     end,
                           SIZE_t     initial_depth) nogil:
    """
    Recursively obtain the samples at the leaves and filter out
    deleted samples. Returns array and a number, instead of an IntList.
    """
    cdef bint   add_sample = True
    cdef SIZE_t i = 0
    cdef SIZE_t j = 0
    cdef SIZE_t start_loc
    cdef SIZE_t end_loc

    # leaf
    if node.is_leaf:

        start_loc = node.n_all[start-1]
        # loop through all samples of G_number batch at this leaf
        for i in range(start_loc, node.n_samples):
            add_sample = True
            for j in range(remove_samples.n):
                if node.leaf_samples[i] == remove_samples.arr[j]:
                   add_sample = False
                   break
            if add_sample:
               samples.arr[samples.n] = node.leaf_samples[i]
               samples.n += 1

        end_loc = node.n_all[end]
        # loop through all samples of G_number batch at this leaf
        for i in range(0, end_loc):
            add_sample = True
            for j in range(remove_samples.n):
                if node.leaf_samples[i] == remove_samples.arr[j]:
                   add_sample = False
                   break
            if add_sample:
               samples.arr[samples.n] = node.leaf_samples[i]
               samples.n += 1

    # decision node
    else:

        # traverse left
        if node.left:
            get_leaf_samples3(node.left, remove_samples, samples, start, end, initial_depth)

        # traverse right
        if node.right:
            get_leaf_samples3(node.right, remove_samples, samples, start, end, initial_depth)