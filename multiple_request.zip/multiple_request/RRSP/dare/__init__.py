"""
DARE module.
"""
from ._classes import Tree as Tree
from ._classes import Forest as Forest
