# =======================================
# 1 present all done shuffle same seed
# ========================================
import gc
import os
import random
import sys
import time
import argparse

import numpy as np
from sklearn.datasets import load_iris
from sklearn.datasets import load_boston
from sklearn.metrics import accuracy_score, average_precision_score
from sklearn.metrics import roc_auc_score
from sklearn.ensemble import RandomForestClassifier

here = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, here + '/../../')
sys.path.insert(0, here + '/../')
import dare

from utility import data_util


def load_data(dataset, data_dir):
    if dataset == 'iris':
        data = load_iris()
        X = data['data']
        y = data['target']

        # make into binary classification dataset
        indices = np.where(y != 2)[0]
        X = X[indices]
        y = y[indices]

        X_train, X_test, y_train, y_test = X, X, y, y

    elif dataset == 'boston':
        data = load_boston()
        X = data['data']
        y = data['target']

        # make into binary classification dataset
        y = np.where(y < np.mean(y), 0, 1)

        X_train, X_test, y_train, y_test = X, X, y, y

    else:
        X_train, X_test, y_train, y_test = data_util.get_data(dataset, data_dir)

        X_train = X_train[:, :]
        X_test = X_test[:, :]

    return X_train, X_test, y_train, y_test


def experiment(arg, X_train, y_train, X_test, y_test):
    # 参数设置♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥
    n_delete = 1000  # 随机删除1000samples取平均delete time
    seed = int(arg.seed)  # int(time.time())  # 1-5
    print('random seed: ', seed)
    # f = open('../'
    #          + arg.dataset + '/' + arg.dataset + arg.file_number + '.txt', 'r')

    max_depth = 20  # 最大深度（树层数为21）
    n_batch = 20
    min_number = 10

    if arg.dataset == 'adult':
        k = 5
        n_estimators = 50
        score = 'acc'
        topd = 15  # 16
    elif arg.dataset == 'census':
        k = 25
        n_estimators = 100
        score = 'auc'
        topd = 15  # 16
    elif arg.dataset == 'credit_card':
        k = 5
        n_estimators = 250
        score = 'ap'
        topd = 8  # 17
    elif arg.dataset == 'bank_marketing':
        k = 25
        n_estimators = 100
        score = 'auc'
        topd = 10  # 14
    elif arg.dataset == 'diabetes':
        k = 5
        n_estimators = 250
        score = 'acc'
        topd = 15  # 15
    elif arg.dataset == 'flight_delays':
        k = 25
        n_estimators = 250
        score = 'auc'
        topd = 5  # 10
    elif arg.dataset == 'no_show':
        k = 10
        n_estimators = 250  # 250
        score = 'auc'
        topd = 5  # 10
    elif arg.dataset == 'olympics':
        k = 5
        n_estimators = 250
        score = 'auc'
        topd = 0  # 7
    elif arg.dataset == 'surgical':
        k = 25
        n_estimators = 100
        score = 'acc'
        topd = 0  # 6
    elif arg.dataset == 'synthetic':
        k = 10
        n_estimators = 50
        score = 'acc'
        topd = 0  # 5
    elif arg.dataset == 'ctr':
        k = 50
        n_estimators = 100
        score = 'auc'
        topd = 5  # 6
        max_depth = 10
    else:
        k = 0
        n_estimators = 0
        score = 'auc'
        topd = 0

    # n_estimators = 1
    # train
    start = time.time()
    model = dare.Forest(topd=topd, k=k, n_estimators=n_estimators,
                        max_depth=max_depth, random_state=seed, criterion='gini', n_batch=n_batch, max_value=min_number)
    model = model.fit(X_train, y_train)
    train_time = time.time() - start
    print('train time: {:.3f}s'.format(train_time))
    print(model.get_node_statistics())

    # delete training data♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥
    if arg.delete:
        # delete_indices = np.zeros(n_delete)
        # for i in range(n_delete):
        #     line = f.readline()
        #     delete_indices[i] = int(line)
        # np.random.seed(seed)
        # np.random.shuffle(delete_indices)
        # delete_indices = np.array(delete_indices, dtype=np.int32)
        delete_indices = np.random.default_rng(seed=seed).choice(X_train.shape[0], size=n_delete, replace=False)

        start = time.time()
        model.onebyone_delete(delete_indices)
        total_time = time.time() - start

        print('total delete time: {:.10f}s'.format(total_time / len(delete_indices)))
        print('retrain samples:', model.manager_.retrain_samples)
        print('retrain times:', model.manager_.count)

        # predict
        y_proba = model.predict_proba(X_test)
        y_pred = np.argmax(y_proba, axis=1)
        if score == 'acc':
            gain = accuracy_score(y_test, y_pred)
        elif score == 'auc':
            gain = roc_auc_score(y_test, y_proba[:, 1])
        else:
            gain = average_precision_score(y_test, y_proba[:, 1])
        print('gain:   ', gain)
        print("end")


if __name__ == '__main__':
    dataset = input()
    file_number = input()
    seed = input()
    data_dir = r'G:\sourcecode-dataset_1\dataset'
    # get data
    X_train, X_test, y_train, y_test = load_data(dataset, data_dir)
    print(X_train.shape)

    # I/O settings
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_dir', type=str, default=data_dir, help='data directory.')
    parser.add_argument('--seed', type=str, default=seed, help='seed.')
    parser.add_argument('--dataset', type=str, default=dataset, help='dataset to use for the experiment.')
    parser.add_argument('--file_number', type=str, default=file_number, help='dataset to use for the experiment.')
    parser.add_argument('--model', type=str, default='dare', help='dare or sklearn')
    parser.add_argument('--delete', default=1, action='store_true', help='whether to deletion or not.')
    parser.add_argument('--test_idempotency', action='store_true', help='simulate deletion multiple times.')
    args = parser.parse_args()
    experiment(args, X_train, y_train, X_test, y_test)
    del args
