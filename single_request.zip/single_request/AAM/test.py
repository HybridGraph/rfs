from math import sqrt

print(round(sqrt(40)))