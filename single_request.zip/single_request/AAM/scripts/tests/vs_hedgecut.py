import os
import sys
import time
import argparse

import numpy as np
from sklearn.datasets import load_iris
from sklearn.datasets import load_boston
from sklearn.metrics import accuracy_score, average_precision_score
from sklearn.metrics import roc_auc_score
here = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, here + '/../../')
sys.path.insert(0, here + '/../')
import dare
from utility import data_util


def load_data(dataset, data_dir):
    if dataset == 'iris':
        data = load_iris()
        X = data['data']
        y = data['target']

        # make into binary classification dataset
        indices = np.where(y != 2)[0]
        X = X[indices]
        y = y[indices]

        X_train, X_test, y_train, y_test = X, X, y, y

    elif dataset == 'boston':
        data = load_boston()
        X = data['data']
        y = data['target']

        # make into binary classification dataset
        y = np.where(y < np.mean(y), 0, 1)

        X_train, X_test, y_train, y_test = X, X, y, y

    else:
        X_train, X_test, y_train, y_test = data_util.get_data(dataset, data_dir)

        X_train = X_train[:, :]
        X_test = X_test[:, :]

    return X_train, X_test, y_train, y_test


def experiment(args, X_train, X_test, y_train, y_test):
    np.set_printoptions(threshold=np.inf)
    # 参数设置♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥
    n_delete = int((X_train.shape[0]) / 1000)
    print(n_delete)
    seed = int(time.time())
    print(seed)

    max_depth = 50000  # 无限深度
    n_batch = 20
    min_number = 10

    if args.dataset == 'adult':
        k = 5
        topd = 15
    elif args.dataset == 'census':
        k = 25
        topd = 15
    elif args.dataset == 'credit_card':
        k = 5
        topd = 8
    elif args.dataset == 'bank_marketing':
        k = 25
        topd = 10
    elif args.dataset == 'diabetes':
        k = 5
        topd = 15
    elif args.dataset == 'flight_delays':
        k = 25
        topd = 5
    elif args.dataset == 'no_show':
        k = 10
        topd = 5
    elif args.dataset == 'olympics':
        k = 5
        topd = 0
    elif args.dataset == 'surgical':
        k = 25
        topd = 0
    elif args.dataset == 'synthetic':
        k = 10
        topd = 0
    elif args.dataset == 'ctr':
        k = 50
        topd = 5
    else:
        k = 0
        topd = 0

    n_estimators = 1
    k = 1
    # train
    start = time.time()
    model = dare.Forest(topd=topd, k=k, n_estimators=n_estimators,
                        max_depth=max_depth, random_state=seed, criterion='gini', n_batch=n_batch, max_value=min_number,
                        min_samples_split=50001)
    model = model.fit(X_train, y_train)
    train_time = time.time() - start
    print('train time: {:.3f}s'.format(train_time))
    print(model.get_node_statistics())

    # structure_memory = model.get_memory_usage()
    # structure_memory, decision_stats_memory, leaf_stats_memory = model.get_memory_usage()
    # # print(structure_memory)
    structure_memory, decision_stats_memory, leaf_stats_memory = model.get_memory_usage()
    # # print(structure_memory, decision_stats_memory, leaf_stats_memory)
    total_memory = structure_memory + decision_stats_memory + leaf_stats_memory
    print('memory: ', total_memory)

    # predict
    y_proba = model.predict_proba(X_test)
    y_pred = np.argmax(y_proba, axis=1)
    acc = accuracy_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_proba[:, 1])
    ap = average_precision_score(y_test, y_proba[:, 1])
    print('acc:   ', acc, 'auc:   ', auc, 'ap:   ', ap)

    # predict
    # y_proba = model.predict_proba(X_test)
    # y_pred = np.argmax(y_proba, axis=1)
    #
    # acc = accuracy_score(y_test, y_pred)
    # return_score = acc
    # print('acc:   ', return_score)

    # delete training data
    cum_delete_time = 0
    if args.delete:
        delete_indices = np.random.default_rng(seed=seed).choice(X_train.shape[0], size=n_delete, replace=False)

        # delete each sample
        for delete_ndx in delete_indices:
            start = time.time()
            model.delete(delete_ndx)
            delete_time = time.time() - start
            cum_delete_time += delete_time

        avg_delete_time = cum_delete_time / len(delete_indices)
        print('avg. delete time: {:.10f}s'.format(avg_delete_time))
        print('retrain samples:', model.manager_.retrain_samples)
        print('retrain times:', model.manager_.count)


# synthetic / credit  200/20000
if __name__ == '__main__':
    dataset = 'census'  # olympics credit_card
    print(dataset)
    data_dir = 'C:/Users/admin/PycharmProjects/DARE_new/data'
    # get data
    X_train, X_test, y_train, y_test = load_data(dataset, data_dir)

    print(X_train.shape)
    print(X_test.shape)

    # I/O settings
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_dir', type=str, default=data_dir, help='data directory.')
    parser.add_argument('--dataset', type=str, default=dataset, help='dataset to use for the experiment.')
    parser.add_argument('--model', type=str, default='dare', help='dare or sklearn')
    parser.add_argument('--delete', default=1, action='store_true', help='whether to deletion or not.')
    parser.add_argument('--test_idempotency', action='store_true', help='simulate deletion multiple times.')
    args = parser.parse_args()
    experiment(args, X_train, X_test, y_train, y_test)
    del args
