from sklearn.metrics import auc, average_precision_score

def calculate_auc(tp, tn, fp, fn):
    fpr = fp / (fp + tn)
    tpr = tp / (tp + fn)
    return auc(fpr, tpr)

def calculate_ap(tp, tn, fp, fn):
    # Since you don't have actual labels and prediction probabilities,
    # directly pass TP, TN, FP, and FN values to average_precision_score
    y_true = [1] * (tp + fn) + [0] * (fp + tn)
    y_scores = [1] * tp + [0] * fn + [1] * fp + [0] * tn
    return average_precision_score(y_true, y_scores)


# Example usage:
tp = 0
tn = 56868
fp = 0
fn = 94

#auc_value = calculate_auc(tp, tn, fp, fn)
ap_value = calculate_ap(tp, tn, fp, fn)

#print("AUC:", auc_value)
print("AP:", ap_value)