
import os
import sys
import time
import numpy as np

from sklearn.model_selection import KFold
from sklearn.metrics import accuracy_score
from sklearn.metrics import roc_auc_score
from sklearn.metrics import average_precision_score

here = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, here + '/../../')
sys.path.insert(0, here + '/../')
import dare
from utility import data_util


folds = KFold(n_splits=5, shuffle=True, random_state=1)
print(folds)
X_train, X_test, y_train, y_test = data_util.get_data('surgical', data_dir='C:/Users/admin/PycharmProjects/DARE_new/data')

n_estimators = 100
max_depth = 20
k = 25
seed = 1
criterion = 'gini'
topd = 0
scoring = 'auc'

scores = []
for fold_i, (train_index, test_index) in enumerate(folds.split(X_train)):
    print(fold_i)
    X_train_sub = X_train[train_index]
    y_train_sub = y_train[train_index]
    X_test_sub = X_train[test_index]
    y_test_sub = y_train[test_index]

    start = time.time()
    model = dare.Forest(topd=topd, k=k, n_estimators=n_estimators,
                        max_depth=max_depth, random_state=seed, criterion=criterion)

    model = model.fit(X_train_sub, y_train_sub)
    train_time = time.time() - start
    print('train time: {:.3f}s'.format(train_time))

    # predict
    y_proba = model.predict_proba(X_test_sub)
    y_pred = np.argmax(y_proba, axis=1)

    # evaluate
    acc = accuracy_score(y_test_sub, y_pred)
    auc = roc_auc_score(y_test_sub, y_proba[:, 1])
    ap = average_precision_score(y_test_sub, y_proba[:, 1])
    print('ACC: {:.3f}, AUC: {:.3f},AP: {:.3f}'.format(acc, auc,ap))
    print(model.get_node_statistics())

    if scoring == 'auc':
        scores.append(auc)

print(scores)
mean_score = 0
for score in scores:
    mean_score += score
mean_score /= len(scores)
print('scoring:   ', scoring, 'mean_score:  {:.3f}  '.format( mean_score))

