import gc
import os
import random
import sys
import time
import argparse

import numpy as np
from sklearn.metrics import accuracy_score, roc_auc_score, average_precision_score
from sklearn.ensemble import RandomForestClassifier

here = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, here + '/../../')
sys.path.insert(0, here + '/../')
import dare


def experiment(args, X_train, X_test, y_train, y_test):
    np.set_printoptions(threshold=np.inf)
    # 参数设置♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥
    n_delete = int((X_train.shape[0]) / 1000)  # 随机删除1000samples取平均delete time
    print(n_delete)
    seed = int(time.time())
    print(seed)

    max_depth = 10000  # 最大深度（无限）
    n_batch = 20
    min_number = 10

    if args.dataset == 'flight_delays':
        k = 25
        topd = 5  # 10
    elif args.dataset == 'olympics':
        k = 5
        topd = 0  # 3
    else:
        k = 0
        topd = 0
    k = 1
    n_estimators = 1
    # train
    start = time.time()
    model = dare.Forest(topd=topd, k=k, n_estimators=n_estimators,
                        max_depth=max_depth, random_state=seed, criterion='gini', n_batch=n_batch, max_value=min_number,
                        min_samples_split=3)  # 最小叶子2
    model = model.fit(X_train, y_train)
    train_time = time.time() - start
    print('train time: {:.3f}s'.format(train_time))
    print(model.get_node_statistics())
    structure_memory, decision_stats_memory, leaf_stats_memory = model.get_memory_usage()
    # print(structure_memory, decision_stats_memory, leaf_stats_memory)
    total_memory = structure_memory + decision_stats_memory + leaf_stats_memory
    print('memory: ', total_memory)

    # predict
    # y_proba = model.predict_proba(X_test)
    # y_pred = np.argmax(y_proba, axis=1)
    #
    # acc = accuracy_score(y_test, y_pred)
    # return_score = acc
    # print('acc:   ', return_score)

    # predict
    y_proba = model.predict_proba(X_test)
    y_pred = np.argmax(y_proba, axis=1)
    acc = accuracy_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_proba[:, 1])
    ap = average_precision_score(y_test, y_proba[:, 1])
    print('acc:   ', acc, 'auc:   ', auc, 'ap:   ', ap)

    # delete training data♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥
    cum_delete_time = 0
    if args.delete:
        delete_indices = np.random.default_rng(seed=seed).choice(X_train.shape[0], size=n_delete, replace=False)

        # delete each sample
        for delete_ndx in delete_indices:
            start = time.time()
            model.delete(delete_ndx)
            delete_time = time.time() - start
            cum_delete_time += delete_time

        avg_delete_time = cum_delete_time / len(delete_indices)
        print('avg. delete time: {:.10f}s'.format(avg_delete_time))
        print('retrain samples:', model.manager_.retrain_samples)
        print('retrain times:', model.manager_.count)
        # print(max_time)


if __name__ == '__main__':
    dataset = 'flight'
    print(dataset)
    # get data
    if dataset == 'flight_delays':
        data = 'flight'
        train = np.load('C:/users/admin/PycharmProjects/hedgecut/datasets/' + data + '-train.npy').astype(np.float32)
        test = np.load('C:/users/admin/PycharmProjects/hedgecut/datasets/' + data + '-test.npy').astype(np.float32)
    else:
        train = np.load('C:/users/admin/PycharmProjects/hedgecut/datasets/' + dataset + '-train.npy').astype(np.float32)
        test = np.load('C:/users/admin/PycharmProjects/hedgecut/datasets/' + dataset + '-test.npy').astype(np.float32)
    X_train = train[:, :-1]
    y_train = train[:, -1]
    X_test = test[:, :-1]
    y_test = test[:, -1]
    print(X_train.shape)

    # I/O settings
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataset', type=str, default=dataset, help='dataset to use for the experiment.')
    parser.add_argument('--model', type=str, default='dare', help='dare or sklearn')
    parser.add_argument('--delete', default=0, action='store_true', help='whether to deletion or not.')
    parser.add_argument('--test_idempotency', action='store_true', help='simulate deletion multiple times.')
    args = parser.parse_args()
    experiment(args, X_train, X_test, y_train, y_test)
    del args
