import gc
import os
import random
import sys
import time
import argparse

import numpy as np
from sklearn.datasets import load_iris
from sklearn.datasets import load_boston
from sklearn.metrics import accuracy_score, average_precision_score
from sklearn.metrics import roc_auc_score
from sklearn.ensemble import RandomForestClassifier

here = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, here + '/../../')
sys.path.insert(0, here + '/../')
import dare
from utility import data_util


def load_data(dataset, data_dir):
    if dataset == 'iris':
        data = load_iris()
        X = data['data']
        y = data['target']

        # make into binary classification dataset
        indices = np.where(y != 2)[0]
        X = X[indices]
        y = y[indices]

        X_train, X_test, y_train, y_test = X, X, y, y

    elif dataset == 'boston':
        data = load_boston()
        X = data['data']
        y = data['target']

        # make into binary classification dataset
        y = np.where(y < np.mean(y), 0, 1)

        X_train, X_test, y_train, y_test = X, X, y, y

    else:
        X_train, X_test, y_train, y_test = data_util.get_data(dataset, data_dir)

        X_train = X_train[:, :]
        X_test = X_test[:, :]

    return X_train, X_test, y_train, y_test


def experiment(arg, X_train, X_test, y_train, y_test):
    n_delete = 1000  # 随机删除1000samples
    seed = int(arg.seed)  # int(time.time())  # 1-5
    print(seed)
    f = open('C:/Users/admin/desktop/1_present/'
             + arg.dataset + '/' + arg.dataset + arg.file_number + '.txt', 'r')

    max_depth = 20  # 最大深度（树层数为21）
    n_batch = 20
    min_number = 10

    if arg.dataset == 'adult':
        k = 5
        n_estimators = 50
        score = 'acc'
        topd = 15  # 16
    elif arg.dataset == 'census':
        k = 25
        n_estimators = 100
        score = 'auc'
        topd = 15  # 16
    elif arg.dataset == 'credit_card':
        k = 5
        n_estimators = 250
        score = 'ap'
        topd = 8  # 17
    elif arg.dataset == 'bank_marketing':
        k = 25
        n_estimators = 100
        score = 'auc'
        topd = 10  # 14
    elif arg.dataset == 'diabetes':
        k = 5
        n_estimators = 250
        score = 'acc'
        topd = 15  # 15
    elif arg.dataset == 'flight_delays':
        k = 25
        n_estimators = 250
        score = 'auc'
        topd = 5  # 10
    elif arg.dataset == 'no_show':
        k = 10
        n_estimators = 250
        score = 'auc'
        topd = 5  # 10
    elif arg.dataset == 'olympics':
        k = 5
        n_estimators = 250
        score = 'auc'
        topd = 0  # 3
    elif arg.dataset == 'surgical':
        k = 25
        n_estimators = 100
        score = 'acc'
        topd = 0  # 4
    elif arg.dataset == 'synthetic':
        k = 10
        n_estimators = 50
        score = 'acc'
        topd = 0  # 5
    elif arg.dataset == 'ctr':
        k = 50
        n_estimators = 100
        score = 'auc'
        topd = 5  # 6
        max_depth = 10
    else:
        k = 0
        n_estimators = 0
        score = 'auc'
        topd = 0
        be_used = 0
        topk = 0

    # train
    start = time.time()
    model = dare.Forest(topd=topd, k=k, n_estimators=n_estimators,
                        max_depth=max_depth, random_state=seed, criterion='gini', n_batch=n_batch, max_value=min_number)
    model = model.fit(X_train, y_train)
    train_time = time.time() - start
    print('train time: {:.3f}s'.format(train_time))
    print(model.get_node_statistics())

    # state = np.random.get_state()
    # np.random.shuffle(X_test)
    # np.random.set_state(state)
    # np.random.shuffle(y_test)

    # 固定每次的随机状态为删除文件集的序号，进行shuffle
    np.random.seed(seed)  # 只能影响离它最近的那个对象
    np.random.shuffle(X_test)
    np.random.seed(seed)
    np.random.shuffle(y_test)

    X_ttest = X_test[0:n_delete, :]  # 随机选1000个看看效果
    y_ttest = y_test[0:n_delete]

    # delete training data♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥
    time1 = time.time()
    cum_delete_time = 0
    if arg.delete:
        delete_indices = np.zeros(n_delete)
        for i in range(n_delete):
            line = f.readline()
            delete_indices[i] = int(line)

        # predict values
        y_pos = np.zeros(n_delete, dtype=np.float32)

        # delete each sample
        s = 0
        for delete_ndx in delete_indices:
            start = time.time()
            model.delete(delete_ndx)
            delete_time = time.time() - start
            cum_delete_time += delete_time

            y_pos[s] = model.predict2(X_ttest, s)
            s += 1

        print('retrain samples:', model.manager_.retrain_samples)
        print('retrain times:', model.manager_.count)

        y_pos = y_pos.reshape(-1, 1)
        y_proba = np.hstack([1 - y_pos, y_pos])
        y_pred = np.argmax(y_proba, axis=1)

        if score == 'acc':
            acc = accuracy_score(y_ttest, y_pred)
            print('accuracy ACC: {:.3f}'.format(acc))  # surgical
        elif score == 'auc':
            auc = roc_auc_score(y_ttest, y_proba[:, 1])
            print('accuracy AUC: {:.3f}'.format(auc))
        else:
            ap = average_precision_score(y_ttest, y_proba[:, 1])
            print('accuracy APP: {:.3f}'.format(ap))

        print('total time: {:.6f}s'.format(time.time() - time1))
        avg_delete_time = cum_delete_time / n_delete
        print('avg. delete time: {:.6f}s'.format(avg_delete_time))
        print('end')


if __name__ == '__main__':
    dataset = input()
    file_number = input()
    seed = input()
    data_dir = 'C:/Users/admin/PycharmProjects/DARE_new/data'
    # get data
    X_train, X_test, y_train, y_test = load_data(dataset, data_dir)
    print(X_train.shape)

    # I/O settings
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_dir', type=str, default=data_dir, help='data directory.')
    parser.add_argument('--dataset', type=str, default=dataset, help='dataset to use for the experiment.')
    parser.add_argument('--file_number', type=str, default=file_number, help='dataset to use for the experiment.')
    parser.add_argument('--model', type=str, default='dare', help='dare or sklearn')
    parser.add_argument('--delete', default=1, action='store_true', help='whether to deletion or not.')
    parser.add_argument('--test_idempotency', action='store_true', help='simulate deletion multiple times.')
    parser.add_argument('--seed', type=str, default=seed, help='seed to use for the experiment.')

    args = parser.parse_args()
    experiment(args, X_train, X_test, y_train, y_test)
    del args
