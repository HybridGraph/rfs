data = '11 ctr'  # input()
filepath = 'C:/Users/admin/Desktop/实验adaptive lazy/adaptive lazy/' + data + '.txt'
f = open(filepath, 'r')

i = 0
delete_time = 0.0
retrain_samples = 0.0
accuracy = 0.0
for line in f:
    s = line.split()

    # ♥ delete time
    if i in [9, 21, 33, 45, 57, 69, 81, 93, 105, 117]:
        time = s[4]
        delete_time += float(time[0:8])
        print(time[0:8])

    if i in [10, 22, 34, 46, 58, 70, 82, 94, 106, 118]:
        retrain_samples += int(s[2])
        print(s[2])

    if i in [12, 24, 36, 48, 60, 72, 84, 96, 108, 120]:
        accuracy += float(s[1])
        print(s[1])
    i += 1

delete_time /= 10
retrain_samples /= 10
accuracy /= 10

print('mean:-----')
print(delete_time)
print(retrain_samples)
print(accuracy)
