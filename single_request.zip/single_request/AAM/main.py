import matplotlib.pyplot as plt
import numpy as np
from matplotlib.pyplot import MultipleLocator

n = 5000
f = open('C:/Users/admin/desktop/adult_top1_16.txt', 'r')
f1 = open('C:/Users/admin/desktop/adult_top1取值_random16 5000桶.txt', 'a')
num = [0] * n
x = float(0.5 / n)
print('区间长度:', x)
for line in f:
    if float(line) <= 0.5:
        if float(line) == 0.5:
            loc = n - 1
        else:
            loc = int(float(line) / x)
        num[loc] += 1
for i in range(n):
    a = '%.5f' % (i * x)
    b = '%.5f' % ((i + 1) * x)
    # s = str(i) + '   [' + str(a) + ',' + str(b) + '):                ' + str(num[i])
    # + '   ' + str(num[i]/np.sum(num)) +  '\n'
    s = str(i) + '   ' + str(num[i]) + '   ' + str(num[i] / np.sum(num)) + '\n'
    # print(i, x, i * x, (i + 1) * x)
    f1.write(s)
    print(num[i])

# 设置字体，防止乱码
plt.rcParams['font.family'] = 'SimHei'

x = range(1, n+1, 1)  # 0.0005 [0,0.5]
y = num

plt.plot(x, y, 'o-', color='r', label="number")

plt.ylim(0, 10000)
plt.xlabel("差值桶")#横坐标名字
plt.ylabel("百分比（%）")#纵坐标名字
plt.legend(loc="best") #设置图例一般用best就行

#把x轴的刻度间隔设置为1，并存在变量里
x_major_locator=MultipleLocator(1)
#ax为两条坐标轴的实例
ax=plt.gca()
#把x轴的主刻度设置为1的倍数
ax.xaxis.set_major_locator(x_major_locator)

plt.show()
