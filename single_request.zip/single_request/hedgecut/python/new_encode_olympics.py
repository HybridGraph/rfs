import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, LabelEncoder

# 读取CSV文件并创建DataFrame
df1 = pd.read_csv("C:/users/admin/PycharmProjects/hedgecut/datasets/olympics-train.csv", delimiter='\t')
# 计算第一个CSV文件的行数
num_rows_df1 = df1.shape[0]
df2 = pd.read_csv("C:/users/admin/PycharmProjects/hedgecut/datasets/olympics-test.csv", delimiter='\t')
df = pd.concat([df1, df2], ignore_index=True)

# 获取所有的分类属性列
categorical = ['sex', 'noc', 'games', 'year', 'season', 'city', 'sport', 'event']
numeric = ['age','height','weight']
label = ['label']
# 对所有的分类属性列进行one-hot编码
ct = ColumnTransformer([('kbd', 'passthrough', numeric), ('ohe', OneHotEncoder(sparse_output=False, handle_unknown='ignore'), categorical)])
encoded_df = ct.fit_transform(df)
print(encoded_df)
# 使用切片操作将合并后的数组拆分为两个DataFrame
df1_processed = encoded_df[:num_rows_df1]
df2_processed = encoded_df[num_rows_df1:]

# binarize outputs
le = LabelEncoder()
train_label = le.fit_transform(df1[label].to_numpy().ravel()).reshape(-1, 1)
test_label = le.transform(df2[label].to_numpy().ravel()).reshape(-1, 1)

train = np.hstack([df1_processed, train_label]).astype(np.float32)
test = np.hstack([df2_processed, test_label]).astype(np.float32)
# 保存编码后的DataFrame到新的CSV文件
np.save("C:/users/admin/PycharmProjects/hedgecut/datasets/olympics-train.npy", train)
np.save("C:/users/admin/PycharmProjects/hedgecut/datasets/olympics-test.npy", test)