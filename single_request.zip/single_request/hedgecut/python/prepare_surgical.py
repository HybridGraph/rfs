# 处理调整好格式的文件,得到 train.csv和test.csv
import pandas as pd

from experimentation.encoding import discretize, ordinalize, binarize

from sklearn.model_selection import train_test_split

names = ["bmi", "Age", "asa_status", "baseline_cancer", "baseline_charlson", "baseline_cvd", "baseline_dementia",
         "baseline_diabetes", "baseline_digestive", "baseline_osteoart", "baseline_psych", "baseline_pulmonary",
         "ahrq_ccs", "ccsComplicationRate", "ccsMort30Rate", "complication_rsi", "dow", "gender", "hour", "month",
         "moonphase", "mort30", "mortality_rsi", "race", "complication"]

# numeric_col = ['bmi', 'Age', 'ccsComplicationRate', 'ccsMort30Rate',
#                'complication_rsi', 'hour', 'mortality_rsi']
# label = ['complication']
# # 20
# categories = ['asa_status', 'baseline_cancer', 'baseline_charlson', 'baseline_cvd', 'baseline_dementia',
#               'baseline_diabetes', 'baseline_digestive', 'baseline_osteoart', 'baseline_psych', 'baseline_pulmonary',
#               'ahrq_ccs', 'dow', 'gender', 'month', 'moonphase', 'mort30', 'race']

raw_data = pd.read_csv('C:/Users/admin/PycharmProjects/hedgecut/datasets/surgical.csv',
                       sep=',', na_values='?', names=names, index_col=False, engine='python')
raw_data = raw_data.dropna()

train_samples, test_samples = train_test_split(raw_data, test_size=0.2)

# 数值属性离散化
bmi, bmi_discretizer = discretize(train_samples, 'bmi')
Age, Age_discretizer = discretize(train_samples, 'Age')
ccsComplicationRate, ccsComplicationRate_discretizer = discretize(train_samples, 'ccsComplicationRate')
ccsMort30Rate, ccsMort30Rate_discretizer = discretize(train_samples, 'ccsMort30Rate')
complication_rsi, complication_rsi_discretizer = discretize(train_samples, 'complication_rsi')
hour, hour_discretizer = discretize(train_samples, 'hour')
mortality_rsi, mortality_rsi_discretizer = discretize(train_samples, 'mortality_rsi')

# 分类属性有序化
asa_status, asa_status_encoder = ordinalize(raw_data, train_samples, 'asa_status')
baseline_cancer, baseline_cancer_encoder = ordinalize(raw_data, train_samples, 'baseline_cancer')
baseline_charlson, baseline_charlson_encoder = ordinalize(raw_data, train_samples, 'baseline_charlson')
baseline_cvd, baseline_cvd_encoder = ordinalize(raw_data, train_samples, 'baseline_cvd')
baseline_dementia, baseline_dementia_encoder = ordinalize(raw_data, train_samples, 'baseline_dementia')
baseline_diabetes, baseline_diabetes_encoder = ordinalize(raw_data, train_samples, 'baseline_diabetes')
baseline_digestive, baseline_digestive_encoder = ordinalize(raw_data, train_samples, 'baseline_digestive')
baseline_osteoart, baseline_osteoart_encoder = ordinalize(raw_data, train_samples, 'baseline_osteoart')
baseline_psych, baseline_psych_encoder = ordinalize(raw_data, train_samples, 'baseline_psych')
baseline_pulmonary, baseline_pulmonary_encoder = ordinalize(raw_data, train_samples, 'baseline_pulmonary')
ahrq_ccs, ahrq_ccs_encoder = ordinalize(raw_data, train_samples, 'ahrq_ccs')
dow, dow_encoder = ordinalize(raw_data, train_samples, 'dow')
gender, gender_encoder = ordinalize(raw_data, train_samples, 'gender')
month, month_encoder = ordinalize(raw_data, train_samples, 'month')
moonphase, moonphase_encoder = ordinalize(raw_data, train_samples, 'moonphase')
mort30, mort30_encoder = ordinalize(raw_data, train_samples, 'mort30')
race, race_encoder = ordinalize(raw_data, train_samples, 'race')

# 标签二值化
labels = train_samples.apply(lambda row: binarize(row, 'complication', 1), axis=1).values

with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/surgical-train.csv', 'w') as file:
    file.write('\t'.join(['record_id',
                          'bmi', 'Age', 'ccsComplicationRate', 'ccsMort30Rate',
                          'complication_rsi', 'hour', 'mortality_rsi',

                          'asa_status', 'baseline_cancer',
                          'baseline_charlson',
                          'baseline_cvd', 'baseline_dementia',
                          'baseline_diabetes', 'baseline_digestive', 'baseline_osteoart', 'baseline_psych',
                          'baseline_pulmonary',
                          'ahrq_ccs', 'dow', 'gender', 'month', 'moonphase', 'mort30', 'race', 'label']) + '\n')

    for i in range(len(train_samples)):
        line = '\t'.join([
            str(i),
            str(int(bmi[i][0])),
            str(int(Age[i][0])),
            str(int(ccsComplicationRate[i][0])),
            str(int(ccsMort30Rate[i][0])),
            str(int(complication_rsi[i][0])),
            str(int(hour[i][0])),
            str(int(mortality_rsi[i][0])),

            str(asa_status[i]),
            str(baseline_cancer[i]),
            str(baseline_charlson[i]),
            str(baseline_cvd[i]),
            str(baseline_dementia[i]),
            str(baseline_diabetes[i]),
            str(baseline_digestive[i]),
            str(baseline_osteoart[i]),
            str(baseline_psych[i]),
            str(baseline_pulmonary[i]),
            str(ahrq_ccs[i]),
            str(dow[i]),
            str(gender[i]),
            str(month[i]),
            str(moonphase[i]),
            str(mort30[i]),
            str(race[i]),

            str(labels[i])
        ])
        file.write(line + '\n')

# =============================
# 数值属性
bmi = bmi_discretizer.transform(test_samples['bmi'].values.reshape(-1, 1))
Age = Age_discretizer.transform(test_samples['Age'].values.reshape(-1, 1))
ccsComplicationRate = ccsComplicationRate_discretizer.transform(test_samples['ccsComplicationRate'].values.reshape(-1, 1))
ccsMort30Rate = ccsMort30Rate_discretizer.transform(test_samples['ccsMort30Rate'].values.reshape(-1, 1))
complication_rsi = complication_rsi_discretizer.transform(test_samples['complication_rsi'].values.reshape(-1, 1))
hour = hour_discretizer.transform(test_samples['hour'].values.reshape(-1, 1))
mortality_rsi = mortality_rsi_discretizer.transform(test_samples['mortality_rsi'].values.reshape(-1, 1))

# 分类属性
asa_status = asa_status_encoder.transform(test_samples['asa_status'].values.reshape(-1, 1))
baseline_cancer = baseline_cancer_encoder.transform(test_samples['baseline_cancer'].values.reshape(-1, 1))
baseline_charlson = baseline_charlson_encoder.transform(test_samples['baseline_charlson'].values.reshape(-1, 1))
baseline_cvd = baseline_cvd_encoder.transform(test_samples['baseline_cvd'].values.reshape(-1, 1))
baseline_dementia = baseline_dementia_encoder.transform(test_samples['baseline_dementia'].values.reshape(-1, 1))
baseline_diabetes = baseline_diabetes_encoder.transform(test_samples['baseline_diabetes'].values.reshape(-1, 1))
baseline_digestive = baseline_digestive_encoder.transform(test_samples['baseline_digestive'].values.reshape(-1, 1))
baseline_osteoart = baseline_osteoart_encoder.transform(test_samples['baseline_osteoart'].values.reshape(-1, 1))
baseline_psych = baseline_psych_encoder.transform(test_samples['baseline_psych'].values.reshape(-1, 1))
baseline_pulmonary = baseline_pulmonary_encoder.transform(test_samples['baseline_pulmonary'].values.reshape(-1, 1))
ahrq_ccs = ahrq_ccs_encoder.transform(test_samples['ahrq_ccs'].values.reshape(-1, 1))
dow = dow_encoder.transform(test_samples['dow'].values.reshape(-1, 1))
gender = gender_encoder.transform(test_samples['gender'].values.reshape(-1, 1))
month = month_encoder.transform(test_samples['month'].values.reshape(-1, 1))
moonphase = moonphase_encoder.transform(test_samples['moonphase'].values.reshape(-1, 1))
mort30 = mort30_encoder.transform(test_samples['mort30'].values.reshape(-1, 1))
race = race_encoder.transform(test_samples['race'].values.reshape(-1, 1))

# 如果标签是数字1，不用加单引号
labels = test_samples.apply(lambda row: binarize(row, 'complication', 1), axis=1).values

with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/surgical-test.csv', 'w') as file:
    file.write('\t'.join(['record_id',
                          'bmi', 'Age', 'ccsComplicationRate', 'ccsMort30Rate',
                          'complication_rsi', 'hour', 'mortality_rsi', 'asa_status', 'baseline_cancer',
                          'baseline_charlson',
                          'baseline_cvd', 'baseline_dementia',
                          'baseline_diabetes', 'baseline_digestive', 'baseline_osteoart', 'baseline_psych',
                          'baseline_pulmonary',
                          'ahrq_ccs', 'dow', 'gender', 'month', 'moonphase', 'mort30', 'race', 'label']) + '\n')

    for i in range(0, len(test_samples)):
        line = '\t'.join([
            str(i + len(train_samples)),
            str(int(bmi[i][0])),
            str(int(Age[i][0])),
            str(int(ccsComplicationRate[i][0])),
            str(int(ccsMort30Rate[i][0])),
            str(int(complication_rsi[i][0])),
            str(int(hour[i][0])),
            str(int(mortality_rsi[i][0])),

            str(asa_status[i]),
            str(baseline_cancer[i]),
            str(baseline_charlson[i]),
            str(baseline_cvd[i]),
            str(baseline_dementia[i]),
            str(baseline_diabetes[i]),
            str(baseline_digestive[i]),
            str(baseline_osteoart[i]),
            str(baseline_psych[i]),
            str(baseline_pulmonary[i]),
            str(ahrq_ccs[i]),
            str(dow[i]),
            str(gender[i]),
            str(month[i]),
            str(moonphase[i]),
            str(mort30[i]),
            str(race[i]),
            str(labels[i])
        ])
        file.write(line + '\n')

'''
0: Min=0, Max=14634
1: Min=0, Max=12
2: Min=0, Max=12
3: Min=0, Max=12
4: Min=0, Max=10
5: Min=0, Max=12
6: Min=0, Max=13
7: Min=0, Max=12
8: Min=0, Max=2
9: Min=0, Max=1
10: Min=0, Max=13
11: Min=0, Max=1
12: Min=0, Max=1
13: Min=0, Max=1
14: Min=0, Max=1
15: Min=0, Max=1
16: Min=0, Max=1
17: Min=0, Max=1
18: Min=0, Max=21
19: Min=0, Max=4
20: Min=0, Max=1
21: Min=0, Max=11
22: Min=0, Max=3
23: Min=0, Max=1
24: Min=0, Max=2
25: Min=0, Max=1

'''
