import pandas as pd

from experimentation.encoding import discretize, ordinalize, binarize

columns = ['age', 'workclass', 'industry_code', 'occupation_code', 'education',
           'wage_per_hour', 'enrolled_in_edu', 'marital_status', 'major_industry_code', 'major_occupation_code',
           'race', 'hispanic_origin', 'sex', 'union_member', 'unemployment_reason',
           'employment', 'capital_gain', 'capital_loss', 'dividends', 'tax_staus',
           'prev_region', 'prev_state', 'household_stat', 'household_summary', 'weight',
           'migration_msa', 'migration_reg', 'migration_reg_move', '1year_house', 'prev_sunbelt',
           'n_persons_employer', 'parents', 'father_birth', 'mother_birth', 'self_birth',
           'citizenship', 'income', 'business', 'taxable_income', 'veterans_admin',
           'veterans_benfits', 'label']  # 42

# categorize attributes
label = ['label']
numeric = ['age', 'wage_per_hour', 'capital_gain', 'capital_loss', 'dividends', 'weight']  # 6
# categorical = list(set(columns) - set(numeric) - set(label))  # 42-6-1=35
categorical = ['workclass', 'education', 'enrolled_in_edu', 'marital_status', 'major_industry_code',
               'major_occupation_code', 'race', 'hispanic_origin', 'sex', 'union_member', 'unemployment_reason',
               'employment', 'tax_staus', 'prev_region', 'prev_state', 'household_stat', 'household_summary',
               'migration_msa', 'migration_reg', 'migration_reg_move', '1year_house', 'prev_sunbelt', 'parents',
               'father_birth', 'mother_birth', 'self_birth', 'citizenship', 'income', 'business', 'taxable_income']

# retrieve dataset
train_samples = pd.read_csv('C:/Users/admin/PycharmProjects/hedgecut/datasets/census-income.data', header=None,
                            names=columns)
test_samples = pd.read_csv('C:/Users/admin/PycharmProjects/hedgecut/datasets/census-income.test', header=None,
                           names=columns)
raw_data = pd.concat([train_samples, test_samples], ignore_index=True)

# remove select columns
remove_cols = ['industry_code', 'occupation_code', 'n_persons_employer',
               'veterans_admin', 'veterans_benfits']  # 35-5=30

if len(remove_cols) > 0:
    train_df = train_samples.drop(columns=remove_cols)
    test_df = test_samples.drop(columns=remove_cols)
    columns = [x for x in columns if x not in remove_cols]

# 数值属性离散化
p1, p1_discretizer = discretize(train_samples, 'age')
p2, p2_discretizer = discretize(train_samples, 'wage_per_hour')
p3, p3_discretizer = discretize(train_samples, 'capital_gain')
p4, p4_discretizer = discretize(train_samples, 'capital_loss')
p5, p5_discretizer = discretize(train_samples, 'dividends')
p6, p6_discretizer = discretize(train_samples, 'weight')
# 分类属性编码
p7, p7_encoder = ordinalize(raw_data, train_samples, 'workclass')
p8, p8_encoder = ordinalize(raw_data, train_samples, 'education')
p9, p9_encoder = ordinalize(raw_data, train_samples, 'enrolled_in_edu')
p10, p10_encoder = ordinalize(raw_data, train_samples, 'marital_status')
p11, p11_encoder = ordinalize(raw_data, train_samples, 'major_industry_code')
p12, p12_encoder = ordinalize(raw_data, train_samples, 'major_occupation_code')
p13, p13_encoder = ordinalize(raw_data, train_samples, 'race')
p14, p14_encoder = ordinalize(raw_data, train_samples, 'hispanic_origin')
p15, p15_encoder = ordinalize(raw_data, train_samples, 'sex')
p16, p16_encoder = ordinalize(raw_data, train_samples, 'union_member')
p17, p17_encoder = ordinalize(raw_data, train_samples, 'unemployment_reason')
p18, p18_encoder = ordinalize(raw_data, train_samples, 'employment')
p19, p19_encoder = ordinalize(raw_data, train_samples, 'tax_staus')
p20, p20_encoder = ordinalize(raw_data, train_samples, 'prev_region')
p21, p21_encoder = ordinalize(raw_data, train_samples, 'prev_state')
p22, p22_encoder = ordinalize(raw_data, train_samples, 'household_stat')
p23, p23_encoder = ordinalize(raw_data, train_samples, 'household_summary')
p24, p24_encoder = ordinalize(raw_data, train_samples, 'migration_msa')
p25, p25_encoder = ordinalize(raw_data, train_samples, 'migration_reg')
p26, p26_encoder = ordinalize(raw_data, train_samples, 'migration_reg_move')
p27, p27_encoder = ordinalize(raw_data, train_samples, '1year_house')
p28, p28_encoder = ordinalize(raw_data, train_samples, 'prev_sunbelt')
p29, p29_encoder = ordinalize(raw_data, train_samples, 'parents')
p30, p30_encoder = ordinalize(raw_data, train_samples, 'father_birth')
p31, p31_encoder = ordinalize(raw_data, train_samples, 'mother_birth')
p32, p32_encoder = ordinalize(raw_data, train_samples, 'self_birth')
p33, p33_encoder = ordinalize(raw_data, train_samples, 'citizenship')
p34, p34_encoder = ordinalize(raw_data, train_samples, 'income')
p35, p35_encoder = ordinalize(raw_data, train_samples, 'business')
p36, p36_encoder = ordinalize(raw_data, train_samples, 'taxable_income')
labels = train_samples.apply(lambda row: binarize(row, 'label', ' 50000+.'), axis=1).values

# 写train文件
with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/census-train.csv', 'w') as file:

    file.write('\t'.join(['record_id',
                          'p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8', 'p9', 'p10',
                          'p11', 'p12', 'p13', 'p14', 'p15', 'p16', 'p17', 'p18', 'p19', 'p20',
                          'p21', 'p22', 'p23', 'p24', 'p25', 'p26', 'p27', 'p28', 'p29',
                          'p30', 'p31', 'p32', 'p33', 'p34', 'p35', 'p36',
                          'label']) + '\n')

    for i in range(len(train_samples)):
        line = '\t'.join([
            str(i),
            str(int(p1[i][0])),
            str(int(p2[i][0])),
            str(int(p3[i][0])),
            str(int(p4[i][0])),
            str(int(p5[i][0])),
            str(int(p6[i][0])),

            str(p7[i]),
            str(p8[i]),
            str(p9[i]),
            str(p10[i]),
            str(p11[i]),
            str(p12[i]),
            str(p13[i]),
            str(p14[i]),
            str(p15[i]),
            str(p16[i]),
            str(p17[i]),
            str(p18[i]),
            str(p19[i]),
            str(p20[i]),
            str(p21[i]),
            str(p22[i]),
            str(p23[i]),
            str(p24[i]),
            str(p25[i]),
            str(p26[i]),
            str(p27[i]),
            str(p28[i]),
            str(p29[i]),
            str(p30[i]),
            str(p31[i]),
            str(p32[i]),
            str(p33[i]),
            str(p34[i]),
            str(p35[i]),
            str(p36[i]),
            str(labels[i])
        ])
        file.write(line + '\n')

# 数值属性
p1 = p1_discretizer.transform(test_samples['age'].values.reshape(-1, 1))
p2 = p2_discretizer.transform(test_samples['wage_per_hour'].values.reshape(-1, 1))
p3 = p3_discretizer.transform(test_samples['capital_gain'].values.reshape(-1, 1))
p4 = p4_discretizer.transform(test_samples['capital_loss'].values.reshape(-1, 1))
p5 = p5_discretizer.transform(test_samples['dividends'].values.reshape(-1, 1))
p6 = p6_discretizer.transform(test_samples['weight'].values.reshape(-1, 1))
# 离散属性
p7 = p7_encoder.transform(test_samples['workclass'].values.reshape(-1, 1))
p8 = p8_encoder.transform(test_samples['education'].values.reshape(-1, 1))
p9 = p9_encoder.transform(test_samples['enrolled_in_edu'].values.reshape(-1, 1))
p10 = p10_encoder.transform(test_samples['marital_status'].values.reshape(-1, 1))
p11 = p11_encoder.transform(test_samples['major_industry_code'].values.reshape(-1, 1))
p12 = p12_encoder.transform(test_samples['major_occupation_code'].values.reshape(-1, 1))
p13 = p13_encoder.transform(test_samples['race'].values.reshape(-1, 1))
p14 = p14_encoder.transform(test_samples['hispanic_origin'].values.reshape(-1, 1))
p15 = p15_encoder.transform(test_samples['sex'].values.reshape(-1, 1))
p16 = p16_encoder.transform(test_samples['union_member'].values.reshape(-1, 1))
p17 = p17_encoder.transform(test_samples['unemployment_reason'].values.reshape(-1, 1))
p18 = p18_encoder.transform(test_samples['employment'].values.reshape(-1, 1))
p19 = p19_encoder.transform(test_samples['tax_staus'].values.reshape(-1, 1))
p20 = p20_encoder.transform(test_samples['prev_region'].values.reshape(-1, 1))
p21 = p21_encoder.transform(test_samples['prev_state'].values.reshape(-1, 1))
p22 = p22_encoder.transform(test_samples['household_stat'].values.reshape(-1, 1))
p23 = p23_encoder.transform(test_samples['household_summary'].values.reshape(-1, 1))
p24 = p24_encoder.transform(test_samples['migration_msa'].values.reshape(-1, 1))
p25 = p25_encoder.transform(test_samples['migration_reg'].values.reshape(-1, 1))
p26 = p26_encoder.transform(test_samples['migration_reg_move'].values.reshape(-1, 1))
p27 = p27_encoder.transform(test_samples['1year_house'].values.reshape(-1, 1))
p28 = p28_encoder.transform(test_samples['prev_sunbelt'].values.reshape(-1, 1))
p29 = p29_encoder.transform(test_samples['parents'].values.reshape(-1, 1))
p30 = p30_encoder.transform(test_samples['father_birth'].values.reshape(-1, 1))
p31 = p31_encoder.transform(test_samples['mother_birth'].values.reshape(-1, 1))
p32 = p32_encoder.transform(test_samples['self_birth'].values.reshape(-1, 1))
p33 = p33_encoder.transform(test_samples['citizenship'].values.reshape(-1, 1))
p34 = p34_encoder.transform(test_samples['income'].values.reshape(-1, 1))
p35 = p35_encoder.transform(test_samples['business'].values.reshape(-1, 1))
p36 = p36_encoder.transform(test_samples['taxable_income'].values.reshape(-1, 1))
labels = test_samples.apply(lambda row: binarize(row, 'label', ' 50000+.'), axis=1).values

# 写test文件
with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/census-test.csv', 'w') as file:

    file.write('\t'.join(['record_id',
                          'p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8', 'p9', 'p10',
                          'p11', 'p12', 'p13', 'p14', 'p15', 'p16', 'p17', 'p18', 'p19', 'p20',
                          'p21', 'p22', 'p23', 'p24', 'p25', 'p26', 'p27', 'p28', 'p29',
                          'p30', 'p31', 'p32', 'p33', 'p34', 'p35', 'p36',
                          'label']) + '\n')

    for i in range(0, len(test_samples)):
        line = '\t'.join([
            str(i + len(train_samples)),
            str(int(p1[i][0])),
            str(int(p2[i][0])),
            str(int(p3[i][0])),
            str(int(p4[i][0])),
            str(int(p5[i][0])),
            str(int(p6[i][0])),

            str(p7[i]),
            str(p8[i]),
            str(p9[i]),
            str(p10[i]),
            str(p11[i]),
            str(p12[i]),
            str(p13[i]),
            str(p14[i]),
            str(p15[i]),
            str(p16[i]),
            str(p17[i]),
            str(p18[i]),
            str(p19[i]),
            str(p20[i]),
            str(p21[i]),
            str(p22[i]),
            str(p23[i]),
            str(p24[i]),
            str(p25[i]),
            str(p26[i]),
            str(p27[i]),
            str(p28[i]),
            str(p29[i]),
            str(p30[i]),
            str(p31[i]),
            str(p32[i]),
            str(p33[i]),
            str(p34[i]),
            str(p35[i]),
            str(p36[i]),
            str(labels[i])
        ])
        file.write(line + '\n')
'''
0: Min=0, Max=299284

1: Min=0, Max=15
2: Min=0, Max=0
3: Min=0, Max=0
4: Min=0, Max=0
5: Min=0, Max=1
6: Min=0, Max=15

7: Min=0, Max=8
8: Min=0, Max=16
9: Min=0, Max=2
10: Min=0, Max=6
11: Min=0, Max=23
12: Min=0, Max=14
13: Min=0, Max=4
14: Min=0, Max=9
15: Min=0, Max=1
16: Min=0, Max=2
17: Min=0, Max=5
18: Min=0, Max=7
19: Min=0, Max=5
20: Min=0, Max=5
21: Min=0, Max=50
22: Min=0, Max=37
23: Min=0, Max=7
24: Min=0, Max=9
25: Min=0, Max=8
26: Min=0, Max=9
27: Min=0, Max=2
28: Min=0, Max=3
29: Min=0, Max=4
30: Min=0, Max=42
31: Min=0, Max=42
32: Min=0, Max=42
33: Min=0, Max=4
34: Min=0, Max=2
35: Min=0, Max=2
36: Min=0, Max=2

37: Min=0, Max=1
'''