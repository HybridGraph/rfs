# 保证格式跟adult.csv一样【,隔开 没有双引号】

# 导入所需模块
import csv

# 指定输入文件路径和输出文件路径
input_file = 'C:/Users/admin/PycharmProjects/hedgecut/datasets/athlete_events.csv'
output_file = '/datasets/olympics.csv'

# 打开输入文件和输出文件
with open(input_file, 'r') as f_in, open(output_file, 'w', newline='') as f_out:
    # 创建CSV读取器和写入器
    reader = csv.reader(f_in, delimiter=',')
    writer = csv.writer(f_out, delimiter=',')

    # 遍历输入文件的每一行
    for row in reader:
        # 将分号替换为逗号，并删除双引号
        cleaned_row = [cell.replace('"', '').replace('"', '')for cell in row]

        # 写入处理后的行到输出文件
        writer.writerow(cleaned_row)

# 处理完成，输出提示信息
print("文件处理完成！")
