# 处理调整好格式的文件,得到 train.csv和test.csv
import pandas as pd

from experimentation.encoding import discretize, ordinalize, binarize

from sklearn.model_selection import train_test_split

names = ['encounter_id', 'patient_nbr', 'race', 'gender', 'age', 'weight', 'admission_type_id',
         'discharge_disposition_id', 'admission_source_id', 'time_in_hospital', 'payer_code', 'medical_specialty',
         'num_lab_procedures', 'num_procedures', 'num_medications', 'number_outpatient', 'number_emergency',
         'number_inpatient', 'diag_1', 'diag_2', 'diag_3', 'number_diagnoses', 'max_glu_serum', 'A1Cresult',
         'metformin', 'repaglinide', 'nateglinide', 'chlorpropamide', 'glimepiride', 'acetohexamide', 'glipizide',
         'glyburide', 'tolbutamide', 'pioglitazone', 'rosiglitazone', 'acarbose', 'miglitol', 'troglitazone',
         'tolazamide', 'examide', 'citoglipton', 'insulin', 'glyburide-metformin', 'glipizide-metformin',
         'glimepiride-pioglitazone', 'metformin-rosiglitazone', 'metformin-pioglitazone', 'change', 'diabetesMed',
         'readmitted'
         ]  # 50
label = ['readmitted']
numeric = ['time_in_hospital', 'num_lab_procedures', 'num_medications',
           'number_outpatient', 'number_emergency', 'number_inpatient',
           'number_diagnoses']  # 7
categories = ['race', 'gender', 'age', 'admission_type_id',
              'discharge_disposition_id', 'admission_source_id', 'payer_code', 'medical_specialty',
              'num_procedures',
              'max_glu_serum', 'A1Cresult', 'metformin', 'repaglinide',
              'nateglinide', 'chlorpropamide', 'glimepiride', 'acetohexamide', 'glipizide', 'glyburide',
              'tolbutamide', 'pioglitazone', 'rosiglitazone', 'acarbose', 'miglitol', 'troglitazone',
              'tolazamide', 'examide', 'citoglipton', 'insulin', 'glyburide-metformin', 'glipizide-metformin',
              'glimepiride-pioglitazone', 'metformin-rosiglitazone', 'metformin-pioglitazone',
              'change', 'diabetesMed']  # 36

raw_data = pd.read_csv('C:/Users/admin/PycharmProjects/hedgecut/datasets/diabetes.csv',
                       sep=',', na_values='?', names=names, index_col=False, engine='python')

# remove select columns
remove_cols = ['encounter_id', 'patient_nbr', 'weight',
               'diag_1', 'diag_2', 'diag_3']
if len(remove_cols) > 0:
    raw_data = raw_data.drop(columns=remove_cols)

# remove nan rows
#nan_rows = raw_data[raw_data.isnull().any(axis=1)]
#raw_data = raw_data.dropna()

raw_data['readmitted'] = raw_data['readmitted'].apply(lambda x: 0 if x == 'NO' else 1)

train_samples, test_samples = train_test_split(raw_data, test_size=0.2)
#print(train_samples)
# 数值属性离散化
time_in_hospital, time_in_hospital_discretizer = discretize(train_samples, 'time_in_hospital')
num_lab_procedures, num_lab_procedures_discretizer = discretize(train_samples, 'num_lab_procedures')
num_medications, num_medications_discretizer = discretize(train_samples, 'num_medications')
number_outpatient, number_outpatient_discretizer = discretize(train_samples, 'number_outpatient')
number_emergency, number_emergency_discretizer = discretize(train_samples, 'number_emergency')
number_inpatient, number_inpatient_discretizer = discretize(train_samples, 'number_inpatient')
number_diagnoses, number_diagnoses_discretizer = discretize(train_samples, 'number_diagnoses')

# 分类属性有序化
race, race_encoder = ordinalize(raw_data, train_samples, 'race')
gender, gender_encoder = ordinalize(raw_data, train_samples, 'gender')
age, age_encoder = ordinalize(raw_data, train_samples, 'age')
admission_type_id, admission_type_id_encoder = ordinalize(raw_data, train_samples, 'admission_type_id')
discharge_disposition_id, discharge_disposition_id_encoder = ordinalize(raw_data, train_samples, 'discharge_disposition_id')
admission_source_id, admission_source_id_encoder = ordinalize(raw_data, train_samples, 'admission_source_id')
payer_code, payer_code_encoder = ordinalize(raw_data, train_samples, 'payer_code')
medical_specialty, medical_specialty_encoder = ordinalize(raw_data, train_samples, 'medical_specialty')
num_procedures, num_procedures_encoder = ordinalize(raw_data, train_samples, 'num_procedures')
max_glu_serum, max_glu_serum_encoder = ordinalize(raw_data, train_samples, 'max_glu_serum')
A1Cresult, A1Cresult_encoder = ordinalize(raw_data, train_samples, 'A1Cresult')
metformin, metformin_encoder = ordinalize(raw_data, train_samples, 'metformin')
repaglinide, repaglinide_encoder = ordinalize(raw_data, train_samples, 'repaglinide')
nateglinide, nateglinide_encoder = ordinalize(raw_data, train_samples, 'nateglinide')
chlorpropamide, chlorpropamide_encoder = ordinalize(raw_data, train_samples, 'chlorpropamide')
glimepiride, glimepiride_encoder = ordinalize(raw_data, train_samples, 'glimepiride')
acetohexamide, acetohexamide_encoder = ordinalize(raw_data, train_samples, 'acetohexamide')
glipizide, glipizide_encoder = ordinalize(raw_data, train_samples, 'glipizide')
glyburide, glyburide_encoder = ordinalize(raw_data, train_samples, 'glyburide')
tolbutamide, tolbutamide_encoder = ordinalize(raw_data, train_samples, 'tolbutamide')
pioglitazone, pioglitazone_encoder = ordinalize(raw_data, train_samples, 'pioglitazone')
rosiglitazone, rosiglitazone_encoder = ordinalize(raw_data, train_samples, 'rosiglitazone')
acarbose, acarbose_encoder = ordinalize(raw_data, train_samples, 'acarbose')
miglitol, miglitol_encoder = ordinalize(raw_data, train_samples, 'miglitol')
troglitazone, troglitazone_encoder = ordinalize(raw_data, train_samples, 'troglitazone')
tolazamide, tolazamide_encoder = ordinalize(raw_data, train_samples, 'tolazamide')
examide, examide_encoder = ordinalize(raw_data, train_samples, 'examide')
citoglipton, citoglipton_encoder = ordinalize(raw_data, train_samples, 'citoglipton')
insulin, insulin_encoder = ordinalize(raw_data, train_samples, 'insulin')
glyburide_metformin, glyburide_metformin_encoder = ordinalize(raw_data, train_samples, 'glyburide-metformin')
glipizide_metformin, glipizide_metformin_encoder = ordinalize(raw_data, train_samples, 'glipizide-metformin')
glimepiride_pioglitazone, glimepiride_pioglitazone_encoder = ordinalize(raw_data, train_samples, 'glimepiride-pioglitazone')
metformin_rosiglitazone, metformin_rosiglitazone_encoder = ordinalize(raw_data, train_samples, 'metformin-rosiglitazone')
metformin_pioglitazone, metformin_pioglitazone_encoder = ordinalize(raw_data, train_samples, 'metformin-pioglitazone')
change, change_encoder = ordinalize(raw_data, train_samples, 'change')
diabetesMed, diabetesMed_encoder = ordinalize(raw_data, train_samples, 'diabetesMed')

# 标签二值化
labels = train_samples.apply(lambda row: binarize(row, 'readmitted', 1), axis=1).values

with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/diabetes-train.csv', 'w') as file:
    file.write('\t'.join(['record_id',
                          'time_in_hospital', 'num_lab_procedures', 'num_medications',
                          'number_outpatient', 'number_emergency', 'number_inpatient',
                          'number_diagnoses',

                          'race', 'gender', 'age', 'admission_type_id',
                          'discharge_disposition_id', 'admission_source_id', 'payer_code', 'medical_specialty',
                          'num_procedures',
                          'max_glu_serum', 'A1Cresult', 'metformin', 'repaglinide',
                          'nateglinide', 'chlorpropamide', 'glimepiride', 'acetohexamide', 'glipizide', 'glyburide',
                          'tolbutamide', 'pioglitazone', 'rosiglitazone', 'acarbose', 'miglitol', 'troglitazone',
                          'tolazamide', 'examide', 'citoglipton', 'insulin', 'glyburide_metformin',
                          'glipizide_metformin',
                          'glimepiride_pioglitazone', 'metformin_rosiglitazone', 'metformin_pioglitazone',
                          'change', 'diabetesMed',
                          'label']) + '\n')

    for i in range(len(train_samples)):
        line = '\t'.join([
            str(i),
            str(int(time_in_hospital[i][0])),
            str(int(num_lab_procedures[i][0])),
            str(int(num_medications[i][0])),
            str(int(number_outpatient[i][0])),
            str(int(number_emergency[i][0])),
            str(int(number_inpatient[i][0])),
            str(int(number_diagnoses[i][0])),

            str(race[i]),
            str(gender[i]),
            str(age[i]),
            str(admission_type_id[i]),
            str(discharge_disposition_id[i]),
            str(admission_source_id[i]),
            str(payer_code[i]),
            str(medical_specialty[i]),
            str(num_procedures[i]),
            str(max_glu_serum[i]),
            str(A1Cresult[i]),
            str(metformin[i]),
            str(repaglinide[i]),
            str(nateglinide[i]),
            str(chlorpropamide[i]),
            str(glimepiride[i]),
            str(acetohexamide[i]),
            str(glipizide[i]),
            str(glyburide[i]),
            str(tolbutamide[i]),
            str(pioglitazone[i]),
            str(rosiglitazone[i]),
            str(acarbose[i]),
            str(miglitol[i]),
            str(troglitazone[i]),
            str(tolazamide[i]),
            str(examide[i]),
            str(citoglipton[i]),
            str(insulin[i]),
            str(glyburide_metformin[i]),
            str(glipizide_metformin[i]),
            str(glimepiride_pioglitazone[i]),
            str(metformin_rosiglitazone[i]),
            str(metformin_pioglitazone[i]),
            str(change[i]),
            str(diabetesMed[i]),

            str(labels[i])
        ])
        file.write(line + '\n')

# 数值属性
time_in_hospital = time_in_hospital_discretizer.transform(test_samples['time_in_hospital'].values.reshape(-1, 1))
num_lab_procedures = num_lab_procedures_discretizer.transform(test_samples['num_lab_procedures'].values.reshape(-1, 1))
num_medications = num_medications_discretizer.transform(test_samples['num_medications'].values.reshape(-1, 1))
number_outpatient = number_outpatient_discretizer.transform(test_samples['number_outpatient'].values.reshape(-1, 1))
number_emergency = number_emergency_discretizer.transform(test_samples['number_emergency'].values.reshape(-1, 1))
number_inpatient = number_inpatient_discretizer.transform(test_samples['number_inpatient'].values.reshape(-1, 1))
number_diagnoses = number_diagnoses_discretizer.transform(test_samples['number_diagnoses'].values.reshape(-1, 1))

# 分类属性
race = race_encoder.transform(test_samples['race'].values.reshape(-1, 1))
gender = gender_encoder.transform(test_samples['gender'].values.reshape(-1, 1))
age = age_encoder.transform(test_samples['age'].values.reshape(-1, 1))
admission_type_id = admission_type_id_encoder.transform(test_samples['admission_type_id'].values.reshape(-1, 1))
discharge_disposition_id = discharge_disposition_id_encoder.transform(test_samples['discharge_disposition_id'].values.reshape(-1, 1))
admission_source_id = admission_source_id_encoder.transform(test_samples['admission_source_id'].values.reshape(-1, 1))
payer_code = payer_code_encoder.transform(test_samples['payer_code'].values.reshape(-1, 1))
medical_specialty = medical_specialty_encoder.transform(test_samples['medical_specialty'].values.reshape(-1, 1))
num_procedures = num_procedures_encoder.transform(test_samples['num_procedures'].values.reshape(-1, 1))
max_glu_serum = max_glu_serum_encoder.transform(test_samples['max_glu_serum'].values.reshape(-1, 1))
A1Cresult = A1Cresult_encoder.transform(test_samples['A1Cresult'].values.reshape(-1, 1))
metformin = metformin_encoder.transform(test_samples['metformin'].values.reshape(-1, 1))
repaglinide = repaglinide_encoder.transform(test_samples['repaglinide'].values.reshape(-1, 1))
nateglinide = nateglinide_encoder.transform(test_samples['nateglinide'].values.reshape(-1, 1))
chlorpropamide = chlorpropamide_encoder.transform(test_samples['chlorpropamide'].values.reshape(-1, 1))
glimepiride = glimepiride_encoder.transform(test_samples['glimepiride'].values.reshape(-1, 1))
acetohexamide = acetohexamide_encoder.transform(test_samples['acetohexamide'].values.reshape(-1, 1))
glipizide = glipizide_encoder.transform(test_samples['glipizide'].values.reshape(-1, 1))
glyburide = glyburide_encoder.transform(test_samples['glyburide'].values.reshape(-1, 1))
tolbutamide = tolbutamide_encoder.transform(test_samples['tolbutamide'].values.reshape(-1, 1))
pioglitazone = pioglitazone_encoder.transform(test_samples['pioglitazone'].values.reshape(-1, 1))
rosiglitazone = rosiglitazone_encoder.transform(test_samples['rosiglitazone'].values.reshape(-1, 1))
acarbose = acarbose_encoder.transform(test_samples['acarbose'].values.reshape(-1, 1))
miglitol = miglitol_encoder.transform(test_samples['miglitol'].values.reshape(-1, 1))
troglitazone = troglitazone_encoder.transform(test_samples['troglitazone'].values.reshape(-1, 1))
tolazamide = tolazamide_encoder.transform(test_samples['tolazamide'].values.reshape(-1, 1))
examide = examide_encoder.transform(test_samples['examide'].values.reshape(-1, 1))
citoglipton = citoglipton_encoder.transform(test_samples['citoglipton'].values.reshape(-1, 1))
insulin = insulin_encoder.transform(test_samples['insulin'].values.reshape(-1, 1))
glyburide_metformin = glyburide_metformin_encoder.transform(test_samples['glyburide-metformin'].values.reshape(-1, 1))
glipizide_metformin = glipizide_metformin_encoder.transform(test_samples['glipizide-metformin'].values.reshape(-1, 1))
glimepiride_pioglitazone = glimepiride_pioglitazone_encoder.transform(test_samples['glimepiride-pioglitazone'].values.reshape(-1, 1))
metformin_rosiglitazone = metformin_rosiglitazone_encoder.transform(test_samples['metformin-rosiglitazone'].values.reshape(-1, 1))
metformin_pioglitazone = metformin_pioglitazone_encoder.transform(test_samples['metformin-pioglitazone'].values.reshape(-1, 1))
change = change_encoder.transform(test_samples['change'].values.reshape(-1, 1))
diabetesMed = diabetesMed_encoder.transform(test_samples['diabetesMed'].values.reshape(-1, 1))

# 如果标签是数字1，不用加单引号
labels = test_samples.apply(lambda row: binarize(row, 'readmitted', 1), axis=1).values

with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/diabetes-test.csv', 'w') as file:
    file.write('\t'.join(['record_id',
                          'time_in_hospital', 'num_lab_procedures', 'num_medications',
                          'number_outpatient', 'number_emergency', 'number_inpatient',
                          'number_diagnoses',

                          'race', 'gender', 'age', 'admission_type_id',
                          'discharge_disposition_id', 'admission_source_id', 'payer_code', 'medical_specialty',
                          'num_procedures',
                          'max_glu_serum', 'A1Cresult', 'metformin', 'repaglinide',
                          'nateglinide', 'chlorpropamide', 'glimepiride', 'acetohexamide', 'glipizide', 'glyburide',
                          'tolbutamide', 'pioglitazone', 'rosiglitazone', 'acarbose', 'miglitol', 'troglitazone',
                          'tolazamide', 'examide', 'citoglipton', 'insulin', 'glyburide_metformin',
                          'glipizide_metformin',
                          'glimepiride_pioglitazone', 'metformin_rosiglitazone', 'metformin_pioglitazone',
                          'change', 'diabetesMed',
                          'label']) + '\n')

    for i in range(0, len(test_samples)):
        line = '\t'.join([
            str(i + len(train_samples)),
            str(int(time_in_hospital[i][0])),
            str(int(num_lab_procedures[i][0])),
            str(int(num_medications[i][0])),
            str(int(number_outpatient[i][0])),
            str(int(number_emergency[i][0])),
            str(int(number_inpatient[i][0])),
            str(int(number_diagnoses[i][0])),

            str(race[i]),
            str(gender[i]),
            str(age[i]),
            str(admission_type_id[i]),
            str(discharge_disposition_id[i]),
            str(admission_source_id[i]),
            str(payer_code[i]),
            str(medical_specialty[i]),
            str(num_procedures[i]),
            str(max_glu_serum[i]),
            str(A1Cresult[i]),
            str(metformin[i]),
            str(repaglinide[i]),
            str(nateglinide[i]),
            str(chlorpropamide[i]),
            str(glimepiride[i]),
            str(acetohexamide[i]),
            str(glipizide[i]),
            str(glyburide[i]),
            str(tolbutamide[i]),
            str(pioglitazone[i]),
            str(rosiglitazone[i]),
            str(acarbose[i]),
            str(miglitol[i]),
            str(troglitazone[i]),
            str(tolazamide[i]),
            str(examide[i]),
            str(citoglipton[i]),
            str(insulin[i]),
            str(glyburide_metformin[i]),
            str(glipizide_metformin[i]),
            str(glimepiride_pioglitazone[i]),
            str(metformin_rosiglitazone[i]),
            str(metformin_pioglitazone[i]),
            str(change[i]),
            str(diabetesMed[i]),

            str(labels[i])
        ])
        file.write(line + '\n')

'''
0: Min=0, Max=101765
1: Min=0, Max=8
2: Min=0, Max=15
3: Min=0, Max=15
4: Min=0, Max=2
5: Min=0, Max=1
6: Min=0, Max=3
7: Min=0, Max=6
8: Min=0, Max=5
9: Min=0, Max=2
10: Min=0, Max=9
11: Min=0, Max=7
12: Min=0, Max=25
13: Min=0, Max=16
14: Min=0, Max=17
15: Min=0, Max=72==
16: Min=0, Max=6
17: Min=0, Max=3
18: Min=0, Max=3
19: Min=0, Max=3
20: Min=0, Max=3
21: Min=0, Max=3
22: Min=0, Max=3
23: Min=0, Max=3
24: Min=0, Max=1
25: Min=0, Max=3
26: Min=0, Max=3
27: Min=0, Max=1
28: Min=0, Max=3
29: Min=0, Max=3
30: Min=0, Max=3
31: Min=0, Max=3
32: Min=0, Max=1
33: Min=0, Max=2
34: Min=0, Max=0
35: Min=0, Max=0
36: Min=0, Max=3
37: Min=0, Max=3
38: Min=0, Max=1
39: Min=0, Max=1
40: Min=0, Max=1
41: Min=0, Max=1
42: Min=0, Max=1
43: Min=0, Max=1
44: Min=0, Max=1

Process finished with exit code 0
'''