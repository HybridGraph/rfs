def calculate_average_time(time_str):
    time_list = time_str.strip().split('\n')  # 将时间值分割成列表
    total_time = sum(int(time_value.strip().split(',')[2].split()[0]) for time_value in time_list)  # 将时间值转换为整数并计算总和
    print(total_time)
    print(len(time_list))
    average_time = total_time / len(time_list)
    return average_time

# 输入的时间值
time_values = """adult,hedgecut,12 us
adult,hedgecut,7 us
adult,hedgecut,18 us
adult,hedgecut,2 us
adult,hedgecut,22 us
adult,hedgecut,14 us
adult,hedgecut,32 us
adult,hedgecut,2 us
adult,hedgecut,18 us
adult,hedgecut,2 us
adult,hedgecut,2 us
adult,hedgecut,9 us
adult,hedgecut,23 us
adult,hedgecut,6 us
adult,hedgecut,5 us
adult,hedgecut,4 us
adult,hedgecut,1 us
adult,hedgecut,7 us
adult,hedgecut,1 us
adult,hedgecut,2 us
adult,hedgecut,7 us
adult,hedgecut,9 us
adult,hedgecut,18 us
adult,hedgecut,6 us
"""

# 计算时间的平均值
average_time = calculate_average_time(time_values)
print("时间的平均值为:", average_time, "us")


