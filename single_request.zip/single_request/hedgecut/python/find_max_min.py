# 每一列的最大值最小值

import pandas as pd

data = 'census'
# 读取第一个CSV文件
df1 = pd.read_csv('C:/Users/admin/PycharmProjects/hedgecut/datasets/' + str(data) + '-train.csv', sep='\t', skiprows=1,
                  header=None)

# 读取第二个CSV文件，跳过第一行（列名行）
df2 = pd.read_csv('C:/Users/admin/PycharmProjects/hedgecut/datasets/' + str(data) + '-test.csv', sep='\t', skiprows=1, header=None)

# 合并两个数据集
combined_data = pd.concat([df1, df2], axis=0)

# 遍历每一列，并找到最大值和最小值
min_max_values = {}
for column in combined_data.columns:
    if column != "label":
        min_value = combined_data[column].min()
        max_value = combined_data[column].max()
        min_max_values[column] = {'min': min_value, 'max': max_value}

# 输出最大值和最小值
for column, values in min_max_values.items():
    print(f"{column}: Min={values['min']}, Max={values['max']}")
