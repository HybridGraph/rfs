
for i in range(7,37):
    print('str(p' + str(i) + '[i]),')

# 依此类推，对 p9 到 p36 执行类似的操作
