from sklearn.metrics import accuracy_score, roc_auc_score, average_precision_score

def read_data_from_file(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()

    data = []
    for i in range(0, len(lines), 2):
        y_true = list(map(int, lines[i].split()))
        y_scores = list(map(float, lines[i+1].split()))
        data.append((y_true, y_scores))

    return data

def calculate_metrics(y_true, y_scores):
    acc = accuracy_score(y_true, [1 if score > 0.5 else 0 for score in y_scores])
    auc = roc_auc_score(y_true, y_scores)
    ap = average_precision_score(y_true, y_scores)
    return acc, auc, ap


if __name__ == "__main__":
    file_path = "C:/Users/admin/PycharmProjects/hedgecut/python/predict.txt"  # 修改为你的文件路径
    data = read_data_from_file(file_path)

    for idx, (y_true, y_scores) in enumerate(data, start=1):
        acc, auc, ap = calculate_metrics(y_true, y_scores)
        print(f"Metrics for group {idx}:")
        print(f"Accuracy: {acc:.4f}")
        print(f"AUC: {auc:.4f}")
        print(f"AP: {ap:.4f}")
        print()
