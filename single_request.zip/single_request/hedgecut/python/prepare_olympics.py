# 处理调整好格式的文件,得到 train.csv和test.csv
import pandas as pd

from experimentation.encoding import discretize, ordinalize, binarize

from sklearn.model_selection import train_test_split

names = ['iD', 'name', 'sex', 'age', 'height', 'weight', 'team', 'noc', 'games',
         'year', 'season', 'city', 'sport',
         'event', 'medal'
         ]#15

label = ['medal']
numeric_col = ['age', 'height', 'weight']#3
categories_col = ['sex', 'noc', 'games', 'year', 'season', 'city', 'sport', 'event']#8
# 跟dare不太一样，因为这里每个分类属性最多有50个取值
raw_data = pd.read_csv('C:/Users/admin/PycharmProjects/hedgecut/datasets/olympics.csv',
                       sep=',', na_values='?', names=names, index_col=False, engine='python')

pd.set_option('display.max_columns', 100)

# remove select columns
remove_cols = ['iD', 'name', 'team']
raw_data = raw_data.drop(columns=remove_cols)

raw_data['medal'] = raw_data['medal'].fillna(pd.NA).fillna(0)
raw_data['medal'] = raw_data['medal'].apply(lambda x: 0 if x == 0 else 1)

# remove nan rows
nan_rows = raw_data[raw_data.isnull().any(axis=1)]
raw_data = raw_data.dropna()

train_samples, test_samples = train_test_split(raw_data, test_size=0.2)

# 数值属性离散化
age, age_discretizer = discretize(train_samples, 'age')
height, height_discretizer = discretize(train_samples, 'height')
weight, weight_discretizer = discretize(train_samples, 'weight')

# 分类属性有序化
sex, sex_encoder = ordinalize(raw_data, train_samples, 'sex')
noc, noc_encoder = ordinalize(raw_data, train_samples, 'noc')
games, games_encoder = ordinalize(raw_data, train_samples, 'games')
year, year_encoder = ordinalize(raw_data, train_samples, 'year')
season, season_encoder = ordinalize(raw_data, train_samples, 'season')
city, city_encoder = ordinalize(raw_data, train_samples, 'city')
sport, sport_encoder = ordinalize(raw_data, train_samples, 'sport')
event, event_encoder = ordinalize(raw_data, train_samples, 'event')


# 标签二值化
labels = train_samples.apply(lambda row: binarize(row, 'medal', 1), axis=1).values

with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/olympics-train.csv', 'w') as file:
    file.write('\t'.join(['record_id',
                          'age', 'height', 'weight',
                          'sex', 'noc', 'games', 'year', 'season', 'city', 'sport', 'event',
                          'label']) + '\n')

    for i in range(len(train_samples)):
        line = '\t'.join([
            str(i),
            str(int(age[i][0])),
            str(int(height[i][0])),
            str(int(weight[i][0])),

            str(sex[i]),
            str(noc[i]),
            str(games[i]),
            str(year[i]),
            str(season[i]),
            str(city[i]),
            str(sport[i]),
            str(event[i]),

            str(labels[i])
        ])
        file.write(line + '\n')

# =============================
# 数值属性
# 'age', 'height', 'weight',
# 'sex', 'noc', 'games', 'year', 'season', 'city', 'sport', 'event',
age = age_discretizer.transform(test_samples['age'].values.reshape(-1, 1))
height = height_discretizer.transform(test_samples['height'].values.reshape(-1, 1))
weight = weight_discretizer.transform(test_samples['weight'].values.reshape(-1, 1))

# 分类属性
sex = sex_encoder.transform(test_samples['sex'].values.reshape(-1, 1))
noc = noc_encoder.transform(test_samples['noc'].values.reshape(-1, 1))
games = games_encoder.transform(test_samples['games'].values.reshape(-1, 1))
year = year_encoder.transform(test_samples['year'].values.reshape(-1, 1))
season = season_encoder.transform(test_samples['season'].values.reshape(-1, 1))
city = city_encoder.transform(test_samples['city'].values.reshape(-1, 1))
sport = sport_encoder.transform(test_samples['sport'].values.reshape(-1, 1))
event = event_encoder.transform(test_samples['event'].values.reshape(-1, 1))

# 如果标签是数字1，不用加单引号
labels = test_samples.apply(lambda row: binarize(row, 'medal', 1), axis=1).values

with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/olympics-test.csv', 'w') as file:
    file.write('\t'.join(['record_id',
                          'age', 'height', 'weight',
                          'sex', 'noc', 'games', 'year', 'season', 'city', 'sport', 'event',
                          'label']) + '\n')

    for i in range(0, len(test_samples)):
        line = '\t'.join([
            str(i + len(train_samples)),
            str(int(age[i][0])),
            str(int(height[i][0])),
            str(int(weight[i][0])),

            str(sex[i]),
            str(noc[i]),
            str(games[i]),
            str(year[i]),
            str(season[i]),
            str(city[i]),
            str(sport[i]),
            str(event[i]),

            str(labels[i])
        ])
        file.write(line + '\n')

'''
0: Min=0, Max=206164
1: Min=0, Max=13
2: Min=0, Max=15
3: Min=0, Max=15
4: Min=0, Max=1
5: Min=0, Max=225
6: Min=0, Max=50
7: Min=0, Max=34
8: Min=0, Max=1
9: Min=0, Max=41
10: Min=0, Max=55
11: Min=0, Max=589
'''
