# 处理调整好格式的文件,得到 train.csv和test.csv
import pandas as pd

from experimentation.encoding import discretize, ordinalize, binarize

from sklearn.model_selection import train_test_split

names = ['PatientId', 'AppointmentID', 'Gender', 'ScheduledDay', 'AppointmentDay', 'Age', 'Neighbourhood',
         'Scholarship', 'Hipertension', 'Diabetes', 'Alcoholism',
         'Handcap', 'SMS_received', 'No-show']

label = ['No-show']
numeric_col = ['Age',
               'scheduled_day', 'scheduled_month', 'scheduled_year', 'scheduled_hour',
               'appointment_day', 'appointment_month', 'appointment_year', 'appointment_hour']
categories_col = ['Gender', 'Neighbourhood','Scholarship', 'Hipertension', 'Diabetes',
               'Alcoholism', 'Handcap', 'SMS_received']
# 跟dare不太一样，因为离散化了这里，然后有三列是定值
raw_data = pd.read_csv('C:/Users/admin/PycharmProjects/hedgecut/datasets/noshow.csv',
                       sep=',', na_values='?', names=names, index_col=False, engine='python')
raw_data = raw_data.dropna()

# remove nan rows==========================================
nan_rows = raw_data[raw_data.isnull().any(axis=1)]
print('nan rows: {}'.format(len(nan_rows)))
raw_data = raw_data.dropna()

# transform timestamps into separate year, month, and day columns
# 加8列
scheduled_date = pd.to_datetime(raw_data['ScheduledDay'])
raw_data['scheduled_day'] = scheduled_date.dt.day
raw_data['scheduled_month'] = scheduled_date.dt.month
raw_data['scheduled_year'] = scheduled_date.dt.year
raw_data['scheduled_hour'] = scheduled_date.dt.hour

appointment_date = pd.to_datetime(raw_data['AppointmentDay'])
raw_data['appointment_day'] = appointment_date.dt.day
raw_data['appointment_month'] = appointment_date.dt.month
raw_data['appointment_year'] = appointment_date.dt.year
raw_data['appointment_hour'] = appointment_date.dt.hour

# remove columns====================================================
# 删四列
remove_cols = ['PatientId', 'AppointmentID', 'ScheduledDay', 'AppointmentDay']
raw_data = raw_data.drop(remove_cols, axis=1)

train_samples, test_samples = train_test_split(raw_data, test_size=0.2)

# 数值属性离散化
Age, Age_discretizer = discretize(train_samples, 'Age')
scheduled_day, scheduled_day_discretizer = discretize(train_samples, 'scheduled_day')
scheduled_month, scheduled_month_discretizer = discretize(train_samples, 'scheduled_month')
scheduled_year, scheduled_year_discretizer = discretize(train_samples, 'scheduled_year')
scheduled_hour, scheduled_hour_discretizer = discretize(train_samples, 'scheduled_hour')
appointment_day, appointment_day_discretizer = discretize(train_samples, 'appointment_day')
appointment_month, appointment_month_discretizer = discretize(train_samples, 'appointment_month')
appointment_year, appointment_year_discretizer = discretize(train_samples, 'appointment_year')
appointment_hour, appointment_hour_discretizer = discretize(train_samples, 'appointment_hour')

# 分类属性有序化
Gender, Gender_encoder = ordinalize(raw_data, train_samples, 'Gender')
Neighbourhood, Neighbourhood_encoder = ordinalize(raw_data, train_samples, 'Neighbourhood')
Scholarship, Scholarship_encoder = ordinalize(raw_data, train_samples, 'Scholarship')
Hipertension, Hipertension_encoder = ordinalize(raw_data, train_samples, 'Hipertension')
Diabetes, Diabetes_encoder = ordinalize(raw_data, train_samples, 'Diabetes')
Alcoholism, Alcoholism_encoder = ordinalize(raw_data, train_samples, 'Alcoholism')
Handcap, Handcap_encoder = ordinalize(raw_data, train_samples, 'Handcap')
SMS_received, SMS_received_encoder = ordinalize(raw_data, train_samples, 'SMS_received')

# 标签二值化
labels = train_samples.apply(lambda row: binarize(row, 'No-show', 'Yes'), axis=1).values

with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/noshow-train.csv', 'w') as file:
    file.write('\t'.join(['record_id',
                          'Age',
                          'scheduled_day', 'scheduled_month', 'scheduled_year', 'scheduled_hour',
                          'appointment_day', 'appointment_month', 'appointment_year', 'appointment_hour',
                          'Gender', 'Neighbourhood','Scholarship', 'Hipertension', 'Diabetes',
                          'Alcoholism', 'Handcap', 'SMS_received',
                          'label']) + '\n')

    for i in range(len(train_samples)):
        line = '\t'.join([
            str(i),
            str(int(Age[i][0])),
            str(int(scheduled_day[i][0])),
            str(int(scheduled_month[i][0])),
            str(int(scheduled_year[i][0])),
            str(int(scheduled_hour[i][0])),
            str(int(appointment_day[i][0])),
            str(int(appointment_month[i][0])),
            str(int(appointment_year[i][0])),
            str(int(appointment_hour[i][0])),

            str(Gender[i]),
            str(Neighbourhood[i]),
            str(Scholarship[i]),
            str(Hipertension[i]),
            str(Diabetes[i]),
            str(Alcoholism[i]),
            str(Handcap[i]),
            str(SMS_received[i]),

            str(labels[i])
        ])
        file.write(line + '\n')

# =============================
# 数值属性
Age = Age_discretizer.transform(test_samples['Age'].values.reshape(-1, 1))
scheduled_day = scheduled_day_discretizer.transform(test_samples['scheduled_day'].values.reshape(-1, 1))
scheduled_month = scheduled_month_discretizer.transform(test_samples['scheduled_month'].values.reshape(-1, 1))
scheduled_year = scheduled_year_discretizer.transform(test_samples['scheduled_year'].values.reshape(-1, 1))
scheduled_hour = scheduled_hour_discretizer.transform(test_samples['scheduled_hour'].values.reshape(-1, 1))
appointment_day = appointment_day_discretizer.transform(test_samples['appointment_day'].values.reshape(-1, 1))
appointment_month = appointment_month_discretizer.transform(test_samples['appointment_month'].values.reshape(-1, 1))
appointment_year = appointment_year_discretizer.transform(test_samples['appointment_year'].values.reshape(-1, 1))
appointment_hour = appointment_hour_discretizer.transform(test_samples['appointment_hour'].values.reshape(-1, 1))

# 分类属性
Gender = Gender_encoder.transform(test_samples['Gender'].values.reshape(-1, 1))
Neighbourhood = Neighbourhood_encoder.transform(test_samples['Neighbourhood'].values.reshape(-1, 1))
Scholarship = Scholarship_encoder.transform(test_samples['Scholarship'].values.reshape(-1, 1))
Hipertension = Hipertension_encoder.transform(test_samples['Hipertension'].values.reshape(-1, 1))
Diabetes = Diabetes_encoder.transform(test_samples['Diabetes'].values.reshape(-1, 1))
Alcoholism = Alcoholism_encoder.transform(test_samples['Alcoholism'].values.reshape(-1, 1))
Handcap = Handcap_encoder.transform(test_samples['Handcap'].values.reshape(-1, 1))
SMS_received = SMS_received_encoder.transform(test_samples['SMS_received'].values.reshape(-1, 1))
# 如果标签是数字1，不用加单引号
labels = test_samples.apply(lambda row: binarize(row, 'No-show', 'Yes'), axis=1).values

with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/noshow-test.csv', 'w') as file:
    file.write('\t'.join(['record_id',
                          'Age',
                          'scheduled_day', 'scheduled_month', 'scheduled_year', 'scheduled_hour',
                          'appointment_day', 'appointment_month', 'appointment_year', 'appointment_hour',
                          'Gender', 'Neighbourhood','Scholarship', 'Hipertension', 'Diabetes',
                          'Alcoholism', 'Handcap', 'SMS_received',
                          'label']) + '\n')

    for i in range(0, len(test_samples)):
        line = '\t'.join([
            str(i + len(train_samples)),
            str(int(Age[i][0])),
            str(int(scheduled_day[i][0])),
            str(int(scheduled_month[i][0])),
            str(int(scheduled_year[i][0])),
            str(int(scheduled_hour[i][0])),
            str(int(appointment_day[i][0])),
            str(int(appointment_month[i][0])),
            str(int(appointment_year[i][0])),
            str(int(appointment_hour[i][0])),

            str(Gender[i]),
            str(Neighbourhood[i]),
            str(Scholarship[i]),
            str(Hipertension[i]),
            str(Diabetes[i]),
            str(Alcoholism[i]),
            str(Handcap[i]),
            str(SMS_received[i]),
            str(labels[i])
        ])
        file.write(line + '\n')

'''
0: Min=0, Max=110526
1: Min=0, Max=15
2: Min=0, Max=15
3: Min=0, Max=3
4: Min=0, Max=0
5: Min=0, Max=10
6: Min=0, Max=14
7: Min=0, Max=1
8: Min=0, Max=0
9: Min=0, Max=0
10: Min=0, Max=1
11: Min=0, Max=80 cut!!!!!!!
12: Min=0, Max=1
13: Min=0, Max=1
14: Min=0, Max=1
15: Min=0, Max=1
16: Min=0, Max=4
17: Min=0, Max=1


'''
