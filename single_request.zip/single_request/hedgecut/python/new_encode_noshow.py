import math

import pandas as pd
import numpy as np

names = ['record_id',
         'Age',
         'scheduled_day', 'scheduled_month', 'scheduled_year', 'scheduled_hour',
         'appointment_day', 'appointment_month', 'appointment_year', 'appointment_hour',
         'Gender', 'Neighbourhood', 'Scholarship', 'Hipertension', 'Diabetes',
         'Alcoholism', 'Handcap', 'SMS_received',
         'label']

# Train -----------------------------------------------------------------------------------------------------
df = pd.read_csv('C:/Users/admin/PycharmProjects/hedgecut/datasets/noshow-train.csv',
                 sep='\t', na_values='?', names=names, index_col=False, engine='python')
# print(df)
# 创建十个新列，并为每个列赋予相同的默认值（例如，0）
for i in range(1, 3):
    df.insert(len(df.columns) - 1, f'p{i}', 0)

size = 63
max_value = 80


def set_p_values(x, max_value):
    num_internal = math.ceil(max_value / size)  # 288/63=5
    code_list = [0 for _ in range(num_internal)]
    # print(x)
    for k in range(num_internal):
        # print(k, (k + 1) * size)
        if x < (k + 1) * size:
            # print(k)
            code_list[k] = x - k * size + 1
            break
    return code_list


# 重新编码
print(df.shape)

for i in range(0, df.shape[0]):
    # print(int(df['Origin'].iloc[i+1]))
    value_list = set_p_values(int(df['Neighbourhood'].iloc[i]), max_value)
    # print(value_list)
    column_index = df.columns.get_loc('p1')
    df.iloc[i, column_index:column_index + len(value_list)] = value_list

df = df.drop("Neighbourhood", axis=1)
# 保存修改后的DataFrame到一个新的CSV文件
df.to_csv("C:/Users/admin/PycharmProjects/hedgecut/datasets/noshow1-train.csv", sep='\t', index=False)

# Test -----------------------------------------------------------------------------------------------------

# 将CSV文件读入pandas DataFrame
df = pd.read_csv('C:/Users/admin/PycharmProjects/hedgecut/datasets/noshow-test.csv',
                 sep='\t', na_values='?', names=names, index_col=False, engine='python')
# print(df)
# 创建十个新列，并为每个列赋予相同的默认值（例如，0）
for i in range(1, 3):
    df.insert(len(df.columns) - 1, f'p{i}', 0)

size = 63
max_value = 80


def set_p_values(x, max_value):
    num_internal = math.ceil(max_value / size)  # 288/63=5
    code_list = [0 for _ in range(num_internal)]
    # print(x)
    for k in range(num_internal):
        # print(k, (k + 1) * size)
        if x < (k + 1) * size:
            # print(k)
            code_list[k] = x - k * size + 1
            break
    return code_list


# 重新编码
print(df.shape)

for i in range(0, df.shape[0]):
    # print(int(df['Origin'].iloc[i+1]))
    value_list = set_p_values(int(df['Neighbourhood'].iloc[i]), max_value)
    # print(value_list)
    column_index = df.columns.get_loc('p1')
    df.iloc[i, column_index:column_index + len(value_list)] = value_list

df = df.drop("Neighbourhood", axis=1)
# 保存修改后的DataFrame到一个新的CSV文件
df.to_csv("C:/Users/admin/PycharmProjects/hedgecut/datasets/noshow1-test.csv", sep='\t', index=False)
