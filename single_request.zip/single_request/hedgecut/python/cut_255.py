import csv

cut_value = 63  # u8
dataset = 'flight'
# 读取 CSV 文件并解析为二维数组
data = []
with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/' + dataset + '-train.csv', 'r') as file:
    csv_reader = csv.reader(file, delimiter='\t')
    for row in csv_reader:
        data.append(row)

# 遍历二维数组，处理超过 255 的数字
for i in range(1, len(data)):
    for j in range(1, len(data[i])):
        try:
            value = int(data[i][j])
            if value > cut_value:
                data[i][j] = str(cut_value)
        except ValueError:
            # 元素不是数字，跳过
            pass

# 将处理后的数据写回 CSV 文件
with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/' + dataset + '-train.csv', 'w', newline='') as file:
    csv_writer = csv.writer(file, delimiter='\t')
    csv_writer.writerows(data)


# 读取 CSV 文件并解析为二维数组
data = []
with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/' + dataset + '-test.csv', 'r') as file:
    csv_reader = csv.reader(file, delimiter='\t')
    for row in csv_reader:
        data.append(row)

# 遍历二维数组，处理超过 255 的数字
for i in range(1, len(data)):
    for j in range(1, len(data[i])):
        try:
            value = int(data[i][j])
            if value > cut_value:
                data[i][j] = str(cut_value)
        except ValueError:
            # 元素不是数字，跳过
            pass

# 将处理后的数据写回 CSV 文件
with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/' + dataset + '-test.csv', 'w', newline='') as file:
    csv_writer = csv.writer(file, delimiter='\t')
    csv_writer.writerows(data)
