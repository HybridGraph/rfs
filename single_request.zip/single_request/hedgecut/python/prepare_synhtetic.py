import os

import numpy as np
import pandas as pd

from experimentation.encoding import discretize, ordinalize, binarize

data_dir = 'C:/Users/admin/PycharmProjects/DARE_new/data/synthetic/continuous'
train = np.load(os.path.join(data_dir, 'train.npy')).astype(np.float32)
test = np.load(os.path.join(data_dir, 'test.npy')).astype(np.float32)

# 设置保存的CSV文件路径
csv_file_path1 = 'C:/Users/admin/PycharmProjects/hedgecut/datasets/synthetic-train.csv'
csv_file_path2 = 'C:/Users/admin/PycharmProjects/hedgecut/datasets/synthetic-test.csv'

train_samples = pd.DataFrame(train)
test_samples = pd.DataFrame(test)

# ========================================处理train=========================================
# 40个数值属性加一个label
num_attributes = 40
names = [f"p{i}" for i in range(1, num_attributes + 1)]
names.append('label')
train_samples.columns = names
test_samples.columns = names

# 数值属性离散化
p1, p1_discretizer = discretize(train_samples, 'p1')
p2, p2_discretizer = discretize(train_samples, 'p2')
p3, p3_discretizer = discretize(train_samples, 'p3')
p4, p4_discretizer = discretize(train_samples, 'p4')
p5, p5_discretizer = discretize(train_samples, 'p5')
p6, p6_discretizer = discretize(train_samples, 'p6')
p7, p7_discretizer = discretize(train_samples, 'p7')
p8, p8_discretizer = discretize(train_samples, 'p8')
p9, p9_discretizer = discretize(train_samples, 'p9')
p10, p10_discretizer = discretize(train_samples, 'p10')
p11, p11_discretizer = discretize(train_samples, 'p11')
p12, p12_discretizer = discretize(train_samples, 'p12')
p13, p13_discretizer = discretize(train_samples, 'p13')
p14, p14_discretizer = discretize(train_samples, 'p14')
p15, p15_discretizer = discretize(train_samples, 'p15')
p16, p16_discretizer = discretize(train_samples, 'p16')
p17, p17_discretizer = discretize(train_samples, 'p17')
p18, p18_discretizer = discretize(train_samples, 'p18')
p19, p19_discretizer = discretize(train_samples, 'p19')
p20, p20_discretizer = discretize(train_samples, 'p20')
p21, p21_discretizer = discretize(train_samples, 'p21')
p22, p22_discretizer = discretize(train_samples, 'p22')
p23, p23_discretizer = discretize(train_samples, 'p23')
p24, p24_discretizer = discretize(train_samples, 'p24')
p25, p25_discretizer = discretize(train_samples, 'p25')
p26, p26_discretizer = discretize(train_samples, 'p26')
p27, p27_discretizer = discretize(train_samples, 'p27')
p28, p28_discretizer = discretize(train_samples, 'p28')
p29, p29_discretizer = discretize(train_samples, 'p29')
p30, p30_discretizer = discretize(train_samples, 'p30')
p31, p31_discretizer = discretize(train_samples, 'p31')
p32, p32_discretizer = discretize(train_samples, 'p32')
p33, p33_discretizer = discretize(train_samples, 'p33')
p34, p34_discretizer = discretize(train_samples, 'p34')
p35, p35_discretizer = discretize(train_samples, 'p35')
p36, p36_discretizer = discretize(train_samples, 'p36')
p37, p37_discretizer = discretize(train_samples, 'p37')
p38, p38_discretizer = discretize(train_samples, 'p38')
p39, p39_discretizer = discretize(train_samples, 'p39')
p40, p40_discretizer = discretize(train_samples, 'p40')

# 标签二值化
labels = train_samples.apply(lambda row: binarize(row, 'label', 1), axis=1).values

with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/synthetic-train.csv', 'w') as file:
    file.write('\t'.join(['record_id',
                          'p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8', 'p9', 'p10',
                          'p11', 'p12', 'p13', 'p14', 'p15', 'p16', 'p17', 'p18', 'p19', 'p20',
                          'p21', 'p22', 'p23', 'p24', 'p25', 'p26', 'p27', 'p28', 'p29',
                          'p30', 'p31', 'p32', 'p33', 'p34', 'p35', 'p36', 'p37', 'p38', 'p39', 'p40',
                          'label']) + '\n')

    for i in range(len(train_samples)):
        line = '\t'.join([
            str(i),
            str(int(p1[i][0])),
            str(int(p2[i][0])),
            str(int(p3[i][0])),
            str(int(p4[i][0])),
            str(int(p5[i][0])),
            str(int(p6[i][0])),
            str(int(p7[i][0])),
            str(int(p8[i][0])),
            str(int(p9[i][0])),
            str(int(p10[i][0])),
            str(int(p11[i][0])),
            str(int(p12[i][0])),
            str(int(p13[i][0])),
            str(int(p14[i][0])),
            str(int(p15[i][0])),
            str(int(p16[i][0])),
            str(int(p17[i][0])),
            str(int(p18[i][0])),
            str(int(p19[i][0])),
            str(int(p20[i][0])),
            str(int(p21[i][0])),
            str(int(p22[i][0])),
            str(int(p23[i][0])),
            str(int(p24[i][0])),
            str(int(p25[i][0])),
            str(int(p26[i][0])),
            str(int(p27[i][0])),
            str(int(p28[i][0])),
            str(int(p29[i][0])),

            str(int(p30[i][0])),
            str(int(p31[i][0])),
            str(int(p32[i][0])),
            str(int(p33[i][0])),
            str(int(p34[i][0])),
            str(int(p35[i][0])),
            str(int(p36[i][0])),
            str(int(p37[i][0])),
            str(int(p38[i][0])),
            str(int(p39[i][0])),
            str(int(p40[i][0])),
            str(labels[i])
        ])
        file.write(line + '\n')

# 数值属性
p1 = p1_discretizer.transform(test_samples['p1'].values.reshape(-1, 1))
p2 = p2_discretizer.transform(test_samples['p2'].values.reshape(-1, 1))
p3 = p3_discretizer.transform(test_samples['p3'].values.reshape(-1, 1))
p4 = p4_discretizer.transform(test_samples['p4'].values.reshape(-1, 1))
p5 = p5_discretizer.transform(test_samples['p5'].values.reshape(-1, 1))
p6 = p6_discretizer.transform(test_samples['p6'].values.reshape(-1, 1))
p7 = p7_discretizer.transform(test_samples['p7'].values.reshape(-1, 1))
p8 = p8_discretizer.transform(test_samples['p8'].values.reshape(-1, 1))
p9 = p9_discretizer.transform(test_samples['p9'].values.reshape(-1, 1))
p10 = p10_discretizer.transform(test_samples['p10'].values.reshape(-1, 1))
p11 = p11_discretizer.transform(test_samples['p11'].values.reshape(-1, 1))
p12 = p12_discretizer.transform(test_samples['p12'].values.reshape(-1, 1))
p13 = p13_discretizer.transform(test_samples['p13'].values.reshape(-1, 1))
p14 = p14_discretizer.transform(test_samples['p14'].values.reshape(-1, 1))
p15 = p15_discretizer.transform(test_samples['p15'].values.reshape(-1, 1))
p16 = p16_discretizer.transform(test_samples['p16'].values.reshape(-1, 1))
p17 = p17_discretizer.transform(test_samples['p17'].values.reshape(-1, 1))
p18 = p18_discretizer.transform(test_samples['p18'].values.reshape(-1, 1))
p19 = p19_discretizer.transform(test_samples['p19'].values.reshape(-1, 1))
p20 = p20_discretizer.transform(test_samples['p20'].values.reshape(-1, 1))
p21 = p21_discretizer.transform(test_samples['p21'].values.reshape(-1, 1))
p22 = p22_discretizer.transform(test_samples['p22'].values.reshape(-1, 1))
p23 = p23_discretizer.transform(test_samples['p23'].values.reshape(-1, 1))
p24 = p24_discretizer.transform(test_samples['p24'].values.reshape(-1, 1))
p25 = p25_discretizer.transform(test_samples['p25'].values.reshape(-1, 1))
p26 = p26_discretizer.transform(test_samples['p26'].values.reshape(-1, 1))
p27 = p27_discretizer.transform(test_samples['p27'].values.reshape(-1, 1))
p28 = p28_discretizer.transform(test_samples['p28'].values.reshape(-1, 1))
p29 = p29_discretizer.transform(test_samples['p29'].values.reshape(-1, 1))

p30 = p30_discretizer.transform(test_samples['p30'].values.reshape(-1, 1))
p31 = p31_discretizer.transform(test_samples['p31'].values.reshape(-1, 1))
p32 = p32_discretizer.transform(test_samples['p32'].values.reshape(-1, 1))
p33 = p33_discretizer.transform(test_samples['p33'].values.reshape(-1, 1))
p34 = p34_discretizer.transform(test_samples['p34'].values.reshape(-1, 1))
p35 = p35_discretizer.transform(test_samples['p35'].values.reshape(-1, 1))
p36 = p36_discretizer.transform(test_samples['p36'].values.reshape(-1, 1))
p37 = p37_discretizer.transform(test_samples['p37'].values.reshape(-1, 1))
p38 = p38_discretizer.transform(test_samples['p38'].values.reshape(-1, 1))
p39 = p39_discretizer.transform(test_samples['p39'].values.reshape(-1, 1))
p40 = p40_discretizer.transform(test_samples['p40'].values.reshape(-1, 1))

labels = test_samples.apply(lambda row: binarize(row, 'label', 1), axis=1).values

with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/synthetic-test.csv', 'w') as file:
    file.write('\t'.join(['record_id',
                          'p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8', 'p9', 'p10',
                          'p11', 'p12', 'p13', 'p14', 'p15', 'p16', 'p17', 'p18', 'p19', 'p20',
                          'p21', 'p22', 'p23', 'p24', 'p25', 'p26', 'p27', 'p28', 'p29',
                          'p30', 'p31', 'p32', 'p33', 'p34', 'p35', 'p36', 'p37', 'p38', 'p39', 'p40',

                          'label']) + '\n')

    for i in range(len(test_samples)):
        line = '\t'.join([
            str(i + len(train_samples)),
            str(int(p1[i][0])),
            str(int(p2[i][0])),
            str(int(p3[i][0])),
            str(int(p4[i][0])),
            str(int(p5[i][0])),
            str(int(p6[i][0])),
            str(int(p7[i][0])),
            str(int(p8[i][0])),
            str(int(p9[i][0])),
            str(int(p10[i][0])),
            str(int(p11[i][0])),
            str(int(p12[i][0])),
            str(int(p13[i][0])),
            str(int(p14[i][0])),
            str(int(p15[i][0])),
            str(int(p16[i][0])),
            str(int(p17[i][0])),
            str(int(p18[i][0])),
            str(int(p19[i][0])),
            str(int(p20[i][0])),
            str(int(p21[i][0])),
            str(int(p22[i][0])),
            str(int(p23[i][0])),
            str(int(p24[i][0])),
            str(int(p25[i][0])),
            str(int(p26[i][0])),
            str(int(p27[i][0])),
            str(int(p28[i][0])),
            str(int(p29[i][0])),

            str(int(p30[i][0])),
            str(int(p31[i][0])),
            str(int(p32[i][0])),
            str(int(p33[i][0])),
            str(int(p34[i][0])),
            str(int(p35[i][0])),
            str(int(p36[i][0])),
            str(int(p37[i][0])),
            str(int(p38[i][0])),
            str(int(p39[i][0])),
            str(int(p40[i][0])),

            str(labels[i])
        ])
        file.write(line + '\n')

'''
0: Min=0, Max=999999
1: Min=0, Max=15
2: Min=0, Max=15
3: Min=0, Max=15
4: Min=0, Max=15
5: Min=0, Max=15
6: Min=0, Max=15
7: Min=0, Max=15
8: Min=0, Max=15
9: Min=0, Max=15
10: Min=0, Max=15
11: Min=0, Max=15
12: Min=0, Max=15
13: Min=0, Max=15
14: Min=0, Max=15
15: Min=0, Max=15
16: Min=0, Max=15
17: Min=0, Max=15
18: Min=0, Max=15
19: Min=0, Max=15
20: Min=0, Max=15
21: Min=0, Max=15
22: Min=0, Max=15
23: Min=0, Max=15
24: Min=0, Max=15
25: Min=0, Max=15
26: Min=0, Max=15
27: Min=0, Max=15
28: Min=0, Max=15
29: Min=0, Max=15
30: Min=0, Max=15
31: Min=0, Max=15
32: Min=0, Max=15
33: Min=0, Max=15
34: Min=0, Max=15
35: Min=0, Max=15
36: Min=0, Max=15
37: Min=0, Max=15
38: Min=0, Max=15
39: Min=0, Max=15
40: Min=0, Max=15
41: Min=0, Max=1
'''
