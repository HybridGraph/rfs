# 处理调整好格式的文件,得到 train.csv和test.csv
# 超过255种分类进行截断
import pandas as pd

from experimentation.encoding import discretize, ordinalize, binarize

from sklearn.model_selection import train_test_split

names = ["Month", "DayofMonth", "DayOfWeek", "DepTime", "UniqueCarrier", "Origin", "Dest", "Distance",
         "dep_delayed_15min"]

numeric_cols = ['DepTime', 'Distance']
categorical_cols = ["Month", "DayofMonth", "DayOfWeek", "UniqueCarrier", "Origin", "Dest"]
label = ['dep_delayed_15min']

raw_data = pd.read_csv('C:/Users/admin/PycharmProjects/hedgecut/datasets/flight.csv',
                       sep=',', na_values='?', names=names, index_col=False, engine='python')
raw_data = raw_data.dropna()

train_samples, test_samples = train_test_split(raw_data, test_size=0.2)

# 数值属性离散化
dep_time, dep_time_discretizer = discretize(train_samples, 'DepTime')
distance, distance_discretizer = discretize(train_samples, 'Distance')

# 分类属性有序化
month, month_encoder = ordinalize(raw_data, train_samples, 'Month')
day_of_month, day_of_month_encoder = ordinalize(raw_data, train_samples, 'DayofMonth')
day_of_week, day_of_week_encoder = ordinalize(raw_data, train_samples, 'DayOfWeek')
unique_carrier, unique_carrier_encoder = ordinalize(raw_data, train_samples, 'UniqueCarrier')
origin, origin_encoder = ordinalize(raw_data, train_samples, 'Origin')
dest, dest_encoder = ordinalize(raw_data, train_samples, 'Dest')

# 标签二值化
labels = train_samples.apply(lambda row: binarize(row, 'dep_delayed_15min', 'Y'), axis=1).values

# =============train================
# 先写数值属性，再写分类属性
# 注意有个record_id
with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/flight-train.csv', 'w') as file:
    file.write('\t'.join(['record_id','DepTime', 'Distance', "Month", "DayofMonth", "DayOfWeek",
                          "UniqueCarrier", "Origin", "Dest", 'label']) + '\n')

    for i in range(len(train_samples)):
        line = '\t'.join([
            str(i),
            str(int(dep_time[i][0])),
            str(int(distance[i][0])),
            str(month[i]),
            str(day_of_month[i]),
            str(day_of_week[i]),
            str(unique_carrier[i]),
            str(origin[i]),
            str(dest[i]),
            str(labels[i])
        ])
        file.write(line + '\n')

# =============test================
# 数值属性
dep_time = dep_time_discretizer.transform(test_samples['DepTime'].values.reshape(-1, 1))
distance = distance_discretizer.transform(test_samples['Distance'].values.reshape(-1, 1))

# 分类属性
month = month_encoder.transform(test_samples['Month'].values.reshape(-1, 1))
day_of_month = day_of_month_encoder.transform(test_samples['DayofMonth'].values.reshape(-1, 1))
day_of_week = day_of_week_encoder.transform(test_samples['DayOfWeek'].values.reshape(-1, 1))
unique_carrier = unique_carrier_encoder.transform(test_samples['UniqueCarrier'].values.reshape(-1, 1))
origin = origin_encoder.transform(test_samples['Origin'].values.reshape(-1, 1))
dest = dest_encoder.transform(test_samples['Dest'].values.reshape(-1, 1))


labels = test_samples.apply(lambda row: binarize(row, 'dep_delayed_15min', 'Y'), axis=1).values

with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/flight-test.csv', 'w') as file:
    file.write('\t'.join(['record_id','DepTime', 'Distance', "Month", "DayofMonth", "DayOfWeek",
                          "UniqueCarrier", "Origin", "Dest", 'label']) + '\n')

    for i in range(0, len(test_samples)):
        line = '\t'.join([
            str(i + len(train_samples)),
            str(int(dep_time[i][0])),
            str(int(distance[i][0])),
            str(month[i]),
            str(day_of_month[i]),
            str(day_of_week[i]),
            str(unique_carrier[i]),
            str(origin[i]),
            str(dest[i]),
            str(labels[i])
        ])
        file.write(line + '\n')

'''
0: Min=0, Max=99999
1: Min=0, Max=15
2: Min=0, Max=15
3: Min=0, Max=11
4: Min=0, Max=30
5: Min=0, Max=6
6: Min=0, Max=21
7: Min=0, Max=288
8: Min=0, Max=288
9: Min=0, Max=1

Process finished with exit code 0
'''
