# 处理调整好格式的文件,得到 train.csv和test.csv
import pandas as pd

from experimentation.encoding import discretize, ordinalize, binarize

from sklearn.model_selection import train_test_split

names = ["age", "job", "marital", "education", "default", "housing", "loan", "contact", "month", "day_of_week",
         "duration",
         "campaign", "pdays", "previous", "poutcome", "emp.var.rate", "cons.price.idx", "cons.conf.idx", "euribor3m",
         "nr.employed", "y"]

# numeric_cols = ['age', 'duration', 'campaign', 'pdays', 'previous', 'emp.var.rate', 'cons.price.idx',
# 'cons.conf.idx', 'euribor3m', 'nr.employed'] categorical_cols = ['job', 'marital', 'education', 'default',
# 'housing', 'loan', 'contact', 'month', 'day_of_week', 'poutcome'] label_col = 'y'


raw_data = pd.read_csv('C:/Users/admin/PycharmProjects/hedgecut/datasets/bank.csv',
                       sep=',', na_values='?', names=names, index_col=False, engine='python')
raw_data = raw_data.dropna()

train_samples, test_samples = train_test_split(raw_data, test_size=0.2)

# 数值属性离散化
age, age_discretizer = discretize(train_samples, 'age')
duration, duration_discretizer = discretize(train_samples, 'duration')
campaign, campaign_discretizer = discretize(train_samples, 'campaign')
pdays, pdays_discretizer = discretize(train_samples, 'pdays')
previous, previous_discretizer = discretize(train_samples, 'previous')
emp_var_rate, emp_var_rate_discretizer = discretize(train_samples, 'emp.var.rate')
cons_price_idx, cons_price_idx_discretizer = discretize(train_samples, 'cons.price.idx')
cons_conf_idx, cons_conf_idx_discretizer = discretize(train_samples, 'cons.conf.idx')
euribor3m, euribor3m_discretizer = discretize(train_samples, 'euribor3m')
nr_employed, nr_employed_discretizer = discretize(train_samples, 'nr.employed')
# 分类属性有序化
job, job_encoder = ordinalize(raw_data, train_samples, 'job')
marital, marital_encoder = ordinalize(raw_data, train_samples, 'marital')
education, education_encoder = ordinalize(raw_data, train_samples, 'education')
default, default_encoder = ordinalize(raw_data, train_samples, 'default')
housing, housing_encoder = ordinalize(raw_data, train_samples, 'housing')
loan, loan_encoder = ordinalize(raw_data, train_samples, 'loan')
contact, contact_encoder = ordinalize(raw_data, train_samples, 'contact')
month, month_encoder = ordinalize(raw_data, train_samples, 'month')
day_of_week, day_of_week_encoder = ordinalize(raw_data, train_samples, 'day_of_week')
poutcome, poutcome_encoder = ordinalize(raw_data, train_samples, 'poutcome')

# 标签二值化
labels = train_samples.apply(lambda row: binarize(row, 'y', 'yes'), axis=1).values

with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/bank-train.csv', 'w') as file:
    file.write('\t'.join(['record_id', 'age', 'duration', 'campaign', 'pdays', 'previous', 'emp.var.rate',
                         'cons.price.idx', 'cons.conf.idx', 'euribor3m', 'nr.employed', 'job', 'marital', 'education',
                         'default', 'housing', 'loan', 'contact', 'month', 'day_of_week', 'poutcome', 'label']) + '\n')

    for i in range(len(train_samples)):
        line = '\t'.join([
            str(i),
            str(int(age[i][0])),
            str(int(duration[i][0])),
            str(int(campaign[i][0])),
            str(int(pdays[i][0])),
            str(int(previous[i][0])),
            str(int(emp_var_rate[i][0])),
            str(int(cons_price_idx[i][0])),
            str(int(cons_conf_idx[i][0])),
            str(int(euribor3m[i][0])),
            str(int(nr_employed[i][0])),
            str(job[i]),
            str(marital[i]),
            str(education[i]),
            str(default[i]),
            str(housing[i]),
            str(loan[i]),
            str(contact[i]),
            str(month[i]),
            str(day_of_week[i]),
            str(poutcome[i]),
            str(labels[i])
        ])
        file.write(line + '\n')

# =============================
# 数值属性
age = age_discretizer.transform(test_samples['age'].values.reshape(-1, 1))
duration = duration_discretizer.transform(test_samples['duration'].values.reshape(-1, 1))
campaign = campaign_discretizer.transform(test_samples['campaign'].values.reshape(-1, 1))
pdays = pdays_discretizer.transform(test_samples['pdays'].values.reshape(-1, 1))
previous = previous_discretizer.transform(test_samples['previous'].values.reshape(-1, 1))
emp_var_rate = emp_var_rate_discretizer.transform(test_samples['emp.var.rate'].values.reshape(-1, 1))
cons_price_idx = cons_price_idx_discretizer.transform(test_samples['cons.price.idx'].values.reshape(-1, 1))
cons_conf_idx = cons_conf_idx_discretizer.transform(test_samples['cons.conf.idx'].values.reshape(-1, 1))
euribor3m = euribor3m_discretizer.transform(test_samples['euribor3m'].values.reshape(-1, 1))
nr_employed = nr_employed_discretizer.transform(test_samples['nr.employed'].values.reshape(-1, 1))

# 分类属性
job = job_encoder.transform(test_samples['job'].values.reshape(-1, 1))
marital = marital_encoder.transform(test_samples['marital'].values.reshape(-1, 1))
education = education_encoder.transform(test_samples['education'].values.reshape(-1, 1))
default = default_encoder.transform(test_samples['default'].values.reshape(-1, 1))
housing = housing_encoder.transform(test_samples['housing'].values.reshape(-1, 1))
loan = loan_encoder.transform(test_samples['loan'].values.reshape(-1, 1))
contact = contact_encoder.transform(test_samples['contact'].values.reshape(-1, 1))
month = month_encoder.transform(test_samples['month'].values.reshape(-1, 1))
day_of_week = day_of_week_encoder.transform(test_samples['day_of_week'].values.reshape(-1, 1))
poutcome = poutcome_encoder.transform(test_samples['poutcome'].values.reshape(-1, 1))

labels = test_samples.apply(lambda row: binarize(row, 'y', 'yes'), axis=1).values


with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/bank-test.csv', 'w') as file:
    file.write('\t'.join(['record_id', 'age', 'duration', 'campaign', 'pdays', 'previous', 'emp.var.rate',
                         'cons.price.idx', 'cons.conf.idx', 'euribor3m', 'nr.employed', 'job', 'marital', 'education',
                         'default', 'housing', 'loan', 'contact', 'month', 'day_of_week', 'poutcome', 'label']) + '\n')

    for i in range(0, len(test_samples)):
        line = '\t'.join([
            str(i + len(train_samples)),
            str(int(age[i][0])),
            str(int(duration[i][0])),
            str(int(campaign[i][0])),
            str(int(pdays[i][0])),
            str(int(previous[i][0])),
            str(int(emp_var_rate[i][0])),
            str(int(cons_price_idx[i][0])),
            str(int(cons_conf_idx[i][0])),
            str(int(euribor3m[i][0])),
            str(int(nr_employed[i][0])),
            str(job[i]),
            str(marital[i]),
            str(education[i]),
            str(default[i]),
            str(housing[i]),
            str(loan[i]),
            str(contact[i]),
            str(month[i]),
            str(day_of_week[i]),
            str(poutcome[i]),
            str(labels[i])
        ])
        file.write(line + '\n')


# C:\Users\admin\PycharmProjects\hedgecut\venv\Scripts\python.exe C:/Users/admin/PycharmProjects/hedgecut
# /python/find_max_min.py
# 1: Min=0, Max=15
# 2: Min=0, Max=15
# 3: Min=0, Max=4
# 4: Min=0, Max=0
# 5: Min=0, Max=1
# 6: Min=0, Max=5
# 7: Min=0, Max=9
# 8: Min=0, Max=8
# 9: Min=0, Max=15
# 10: Min=0, Max=4
# 11: Min=0, Max=11
# 12: Min=0, Max=3
# 13: Min=0, Max=7
# 14: Min=0, Max=2
# 15: Min=0, Max=2
# 16: Min=0, Max=2
# 17: Min=0, Max=1
# 18: Min=0, Max=9
# 19: Min=0, Max=4
# 20: Min=0, Max=2
# 21: Min=0, Max=1
#
# Process finished with exit code 0
