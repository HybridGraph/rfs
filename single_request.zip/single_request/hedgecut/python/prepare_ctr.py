import os

import numpy as np
import pandas as pd

from experimentation.encoding import discretize, ordinalize, binarize

data_dir = 'C:/Users/admin/PycharmProjects/DARE_new/data/ctr/continuous'
train = np.load(os.path.join(data_dir, 'train.npy')).astype(np.float32)
test = np.load(os.path.join(data_dir, 'test.npy')).astype(np.float32)

# 设置保存的CSV文件路径
csv_file_path1 = 'C:/Users/admin/PycharmProjects/hedgecut/datasets/ctr-train.csv'
csv_file_path2 = 'C:/Users/admin/PycharmProjects/hedgecut/datasets/ctr-test.csv.csv'

train_samples = pd.DataFrame(train)
test_samples = pd.DataFrame(test)

# ========================================处理train=========================================
# 29个数值属性加一个label
num_attributes = 13
names = [f"p{i}" for i in range(1, num_attributes + 1)]
names.append('label')
train_samples.columns = names
test_samples.columns = names

# 数值属性离散化
p1, p1_discretizer = discretize(train_samples, 'p1')
p2, p2_discretizer = discretize(train_samples, 'p2')
p3, p3_discretizer = discretize(train_samples, 'p3')
p4, p4_discretizer = discretize(train_samples, 'p4')
p5, p5_discretizer = discretize(train_samples, 'p5')
p6, p6_discretizer = discretize(train_samples, 'p6')
p7, p7_discretizer = discretize(train_samples, 'p7')
p8, p8_discretizer = discretize(train_samples, 'p8')
p9, p9_discretizer = discretize(train_samples, 'p9')
p10, p10_discretizer = discretize(train_samples, 'p10')
p11, p11_discretizer = discretize(train_samples, 'p11')
p12, p12_discretizer = discretize(train_samples, 'p12')
p13, p13_discretizer = discretize(train_samples, 'p13')

# 标签二值化
labels = train_samples.apply(lambda row: binarize(row, 'label', 1), axis=1).values

with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/ctr-train.csv', 'w') as file:
    file.write('\t'.join(['record_id',
                          'p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8', 'p9', 'p10',
                          'p11', 'p12', 'p13',
                          'label']) + '\n')

    for i in range(len(train_samples)):
        line = '\t'.join([
            str(i),
            str(int(p1[i][0])),
            str(int(p2[i][0])),
            str(int(p3[i][0])),
            str(int(p4[i][0])),
            str(int(p5[i][0])),
            str(int(p6[i][0])),
            str(int(p7[i][0])),
            str(int(p8[i][0])),
            str(int(p9[i][0])),
            str(int(p10[i][0])),
            str(int(p11[i][0])),
            str(int(p12[i][0])),
            str(int(p13[i][0])),
            str(labels[i])
        ])
        file.write(line + '\n')

# 数值属性
p1 = p1_discretizer.transform(test_samples['p1'].values.reshape(-1, 1))
p2 = p2_discretizer.transform(test_samples['p2'].values.reshape(-1, 1))
p3 = p3_discretizer.transform(test_samples['p3'].values.reshape(-1, 1))
p4 = p4_discretizer.transform(test_samples['p4'].values.reshape(-1, 1))
p5 = p5_discretizer.transform(test_samples['p5'].values.reshape(-1, 1))
p6 = p6_discretizer.transform(test_samples['p6'].values.reshape(-1, 1))
p7 = p7_discretizer.transform(test_samples['p7'].values.reshape(-1, 1))
p8 = p8_discretizer.transform(test_samples['p8'].values.reshape(-1, 1))
p9 = p9_discretizer.transform(test_samples['p9'].values.reshape(-1, 1))
p10 = p10_discretizer.transform(test_samples['p10'].values.reshape(-1, 1))
p11 = p11_discretizer.transform(test_samples['p11'].values.reshape(-1, 1))
p12 = p12_discretizer.transform(test_samples['p12'].values.reshape(-1, 1))
p13 = p13_discretizer.transform(test_samples['p13'].values.reshape(-1, 1))

labels = test_samples.apply(lambda row: binarize(row, 'label', 1), axis=1).values

with open('C:/Users/admin/PycharmProjects/hedgecut/datasets/ctr-test.csv', 'w') as file:
    file.write('\t'.join(['record_id',
                          'p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8', 'p9', 'p10',
                          'p11', 'p12', 'p13',
                          'label']) + '\n')

    for i in range(len(test_samples)):
        line = '\t'.join([
            str(i + len(train_samples)),
            str(int(p1[i][0])),
            str(int(p2[i][0])),
            str(int(p3[i][0])),
            str(int(p4[i][0])),
            str(int(p5[i][0])),
            str(int(p6[i][0])),
            str(int(p7[i][0])),
            str(int(p8[i][0])),
            str(int(p9[i][0])),
            str(int(p10[i][0])),
            str(int(p11[i][0])),
            str(int(p12[i][0])),
            str(int(p13[i][0])),
            str(labels[i])
        ])
        file.write(line + '\n')




'''
0: Min=0, Max=999999
1: Min=0, Max=10
2: Min=0, Max=15
3: Min=0, Max=10
4: Min=0, Max=9
5: Min=0, Max=8
6: Min=0, Max=3
7: Min=0, Max=1
8: Min=0, Max=12
9: Min=0, Max=11
10: Min=0, Max=2
11: Min=0, Max=6
12: Min=0, Max=15
13: Min=0, Max=10
14: Min=0, Max=1

Process finished with exit code 0
'''