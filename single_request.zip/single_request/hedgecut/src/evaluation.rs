#![allow(deprecated)] // TODO use rand_xorshift crate to remove this...
use std::{mem};
use std::fs::{OpenOptions};
use std::io::{BufWriter, Write};
use crate::dataset::{Sample, Dataset};
use crate::tree::ExtremelyRandomizedTrees;
use rand::{thread_rng, RngCore, Rng};
use std::time::Instant;
use rand::seq::SliceRandom;
use crate::split_stats::{SplitStats};
use crate::tree::{TreeElement};
use crate::tree::Split;
// 导入失败===输出向量到python计算吧
// use rusty_machine::analysis::roc::RocCurve;
// use rusty_machine::analysis::pr::PrecisionRecallCurve;

pub fn evaluate<S: Sample + Sync>(
    name: &str,
    trees: &ExtremelyRandomizedTrees,
    test_data: &Vec<S>,
    training_time_and_max_tries: Option<(u128, usize)>,

) {
    let mut t_p = 0;
    let mut _f_p = 0;
    let mut t_n = 0;
    let mut _f_n = 0;

    for sample in test_data.iter() {
        let predicted_label = trees.predict(sample);

        if sample.true_label() {
            if predicted_label {
                t_p += 1;
            } else {
                _f_n += 1;
            }
        } else {
            if predicted_label {
                _f_p += 1;
            } else {
                t_n += 1;
            }
        }
    }

    let accuracy = (t_p + t_n) as f64 / test_data.len() as f64;
    //println!("Accuracy {}", accuracy);
    //println!("[{}\t{}\n{}\t{}]", t_p, _f_n, _f_p, t_n);

    match training_time_and_max_tries {
        Some((duration, tries)) => {
            println!("{},hedgecut,{},{},{}", name, accuracy, duration, tries)
        },
        None => println!("{},hedgecut,{}", name, accuracy),
    }

}

pub fn evaluate1<S: Sample + Sync>(
    trees: &ExtremelyRandomizedTrees,
    test_data: &Vec<S>,

) {
    let mut y_true = Vec::new();
    let mut y_scores = Vec::new();

    for sample in test_data.iter() {
        let predicted_value = trees.predict1(sample);

        if sample.true_label() {
            y_true.push(1);
            y_scores.push(predicted_value);
        } else {
            y_true.push(0);
            y_scores.push(predicted_value);
        }
    }

    // 将 y_true 和 y_scores 转换为字符串形式，用空格分隔每个元素
    let y_true_str: String = y_true.iter().map(|val| val.to_string()).collect::<Vec<_>>().join(" ");
    let y_scores_str: String = y_scores.iter().map(|val| format!("{:.6}", val)).collect::<Vec<_>>().join(" ");

    // 打开文件，如果文件不存在则会创建
    let file_path = "python/predict.txt";
    let file = OpenOptions::new()
        .write(true)
        .append(true)
        .create(true)
        .open(file_path)
        .expect("Failed to open file");

    // 使用 BufWriter 来提高写入性能
    let mut writer = BufWriter::new(file);

    // 将 y_true 写入文件，一行一个向量
    writeln!(writer, "{}", y_true_str)
        .expect("Failed to write y_true to file");

    // 将 y_scores 写入文件，一行一个向量
    writeln!(writer, "{}", y_scores_str)
        .expect("Failed to write y_scores to file");
}

pub fn end_to_end<D: Dataset + Sync, S: Sample + Sync>(
    name: &str,
    dataset: D,
    samples: Vec<S>,
    test_data: Vec<S>,
    _seed: u64,
    num_trees: usize,
    min_leaf_size: usize,
    max_tries_per_split: usize,
) {

    let mut rng = thread_rng();
    let seed = rng.next_u64();

    let training_start = Instant::now();
    let mut etr = ExtremelyRandomizedTrees::fit(
        &dataset,
        samples,
        seed,
        num_trees,
        min_leaf_size,
        max_tries_per_split
    );

    let training_duration = training_start.elapsed();
    println!("Fitted {} trees in {} ms", num_trees, training_duration.as_millis());

    // for tree in etr.trees{
    //     let (tree_num_robust, tree_num_non_robust) = node_count(tree);
    //     num_robust += tree_num_robust;
    //     num_non_robust += tree_num_non_robust;
    //     num_total_nodes += tree_num_robust + tree_num_non_robust;
    // 这俩不能同时运行，会出现什么产权问题
    evaluate(name, &etr, &test_data, None);

    // score
    // evaluate1(&etr, &test_data);
    for tree in etr.trees{
        let result = memory_count(tree);
        println!("memory usage: {}", result);
    }
}

// new add==========================================================================================
pub fn get_node_num<D: Dataset + Sync, S: Sample + Sync>(
    dataset: D,
    samples: Vec<S>,
    _seed: u64,
    num_trees: usize,
    min_leaf_size: usize,
    max_tries_per_split: usize,
) {

    let mut rng = thread_rng();
    let seed = rng.next_u64();

    let training_start = Instant::now();
    let etr = ExtremelyRandomizedTrees::fit(
        &dataset,
        samples,
        seed,
        num_trees,
        min_leaf_size,
        max_tries_per_split
    );

    let training_duration = training_start.elapsed();
    println!("Fitted {} trees in {} ms", num_trees, training_duration.as_millis());

    let mut num_robust = 0;
    let mut num_non_robust = 0;
    let mut num_total_nodes = 0;
    for tree in etr.trees{
        let (tree_num_robust, tree_num_non_robust) = node_count(tree);
        num_robust += tree_num_robust;
        num_non_robust += tree_num_non_robust;
        num_total_nodes += tree_num_robust + tree_num_non_robust;
    }
    println!("Number of robust nodes: {}", num_robust);
    println!("Number of non-robust nodes: {}", num_non_robust);
    println!("Total number of nodes: {}", num_total_nodes);

}

// new add==========================================================================================
pub fn get_memory_usage<D: Dataset + Sync, S: Sample + Sync>(
    dataset: D,
    samples: Vec<S>,
    _seed: u64,
    num_trees: usize,
    min_leaf_size: usize,
    max_tries_per_split: usize,
) {

    // train---------------------------------------------------------
    let mut rng = thread_rng();
    let seed = rng.next_u64();

    let training_start = Instant::now();
    let etr = ExtremelyRandomizedTrees::fit(
        &dataset,
        samples,
        seed,
        num_trees,
        min_leaf_size,
        max_tries_per_split
    );

    let training_duration = training_start.elapsed();
    println!("Fitted {} trees in {} ms", num_trees, training_duration.as_millis());

    // count----------------------------------------------------------

    for tree in etr.trees{
        let result = memory_count(tree);
        println!("memory usage: {}", result);
    }

}

// new add==========================================================================================
pub fn memory_count(tree: crate::tree::Tree) -> usize {
    let mut result = 0;

    result += std::mem::size_of_val(&tree);
    //println!("==========memory usage tree itself: {}", result); //160固定值
    //let check1 = std::mem::size_of_val(&tree.tree_elements);
    //println!("subtree memory usage: {}", check1);
    //let check2 = std::mem::size_of_val(&tree.alternative_subtrees);
    //println!("subtree memory usage: {}", check2);
    //let check3 = std::mem::size_of_val(&tree.rng);
    //println!("subtree memory usage: {}", check3);

    // 遍历 tree.elements
    for (_, value) in tree.tree_elements {
        let key_size = mem::size_of::<u64>();
        let value_size = match value {

            TreeElement::Node { split } =>
                match split {
                    Split::Numerical {
                        attribute_index: _,
                        cut_off: _,
                    } => mem::size_of::<u8>() * 2,
                    Split::Categorical {
                        attribute_index: _,
                        subset: _,
                    } => mem::size_of::<u8>() + mem::size_of::<u64>(),
                },
            TreeElement::Leaf { num_samples:_, num_plus:_ } => mem::size_of::<u32>() * 2,
        };
        result += key_size + value_size;

    }
    //println!("2222222222222222memory usage: {}", result);

    // 遍历子树
    let mut subtree_result = 0;

    for (_, subtrees) in tree.alternative_subtrees {
        // 键的内存
        let key_size = mem::size_of::<u64>();
        subtree_result += key_size;
        // 向量本身的内存
        let vec_size = std::mem::size_of_val(&subtrees);
        // println!("vec usage tree itself: {}", vec_size); //24固定值（根号p长度）
        subtree_result += vec_size;
        // 每个元素（替换树的内存）
        for subtree in subtrees {
            // check
            //println!("check====================================================");
            //let check1 = std::mem::size_of_val(&subtree);
           // println!("subtree memory usage: {}", check1);
            //let check2 = std::mem::size_of_val(&subtree.tree);
            //println!("subtree.tree memory usage: {}", check2);
            //let check3 = std::mem::size_of_val(&subtree.split);
            //println!("subtree.tree memory usage: {}", check3);
            //let check4 = std::mem::size_of_val(&subtree.split_stats);
           // println!("subtree.tree memory usage: {}", check4);
            // split
            let split_size = match subtree.split {
                    Split::Numerical {
                        attribute_index: _,
                        cut_off: _,
                    } => mem::size_of::<u8>() * 2,
                    Split::Categorical {
                        attribute_index: _,
                        subset: _,
                    } => mem::size_of::<u8>() + mem::size_of::<u64>(),
            };
            subtree_result += split_size;
            //println!("split memory usage: {}", split_size);
            // split state
            let split_state_size = mem::size_of::<SplitStats>();
            subtree_result += split_state_size;
            //println!("splitstate memory usage: {}", split_state_size);
            // 子树内存
            subtree_result +=  memory_count(subtree.tree);
            //println!("11111subtree.tree memory usage: {}", subtree_result);
        }
    }

    result += subtree_result;
    //println!("0000000all tree.tree memory usage: {}", result);
    return result
}


pub fn accuracy_forget<D: Dataset + Sync, S: Sample + Sync + Eq>(
    name: &str,
    dataset: D,
    samples: Vec<S>,
    test_data: Vec<S>,
    num_trees: usize,
    min_leaf_size: usize,
    max_tries_per_split: usize,
) {

    let mut rng = thread_rng();
    let seed = rng.next_u64();

    let target_robustness = ((dataset.num_records() as f64) / 1000.0).round() as usize;

    let samples_to_forget: Vec<S> =
        samples.choose_multiple(&mut rng, target_robustness).cloned().collect();

    let samples_for_retraining: Vec<S> = samples.iter()
        .filter_map(|s| {
            if samples_to_forget.contains(&s) {
                None
            } else {
                Some(s.clone())
            }
        })
        .collect();

    let mut trees = ExtremelyRandomizedTrees::fit(
        &dataset,
        samples,
        seed,
        num_trees,
        min_leaf_size,
        max_tries_per_split
    );

    let mut t_p = 0;
    let mut f_p = 0;
    let mut t_n = 0;
    let mut f_n = 0;

    for sample in test_data.iter() {
        let predicted_label = trees.predict(sample);

        if sample.true_label() {
            if predicted_label {
                t_p += 1;
            } else {
                f_n += 1;
            }
        } else {
            if predicted_label {
                f_p += 1;
            } else {
                t_n += 1;
            }
        }
    }

    let accuracy = (t_p + t_n) as f64 / test_data.len() as f64;

    for sample in &samples_to_forget {
        trees.forget(sample);
    }

    let mut t_p_forget = 0;
    let mut f_p_forget = 0;
    let mut t_n_forget = 0;
    let mut f_n_forget = 0;

    for sample in test_data.iter() {
        let predicted_label = trees.predict(sample);

        if sample.true_label() {
            if predicted_label {
                t_p_forget += 1;
            } else {
                f_n_forget += 1;
            }
        } else {
            if predicted_label {
                f_p_forget += 1;
            } else {
                t_n_forget += 1;
            }
        }
    }

    let accuracy_forget = (t_p_forget + t_n_forget) as f64 / test_data.len() as f64;

    let retrained_trees = ExtremelyRandomizedTrees::fit(
        &dataset,
        samples_for_retraining,
        seed,
        num_trees,
        min_leaf_size,
        max_tries_per_split
    );

    let mut t_p_retrained = 0;
    let mut f_p_retrained = 0;
    let mut t_n_retrained = 0;
    let mut f_n_retrained = 0;

    for sample in test_data.iter() {
        let predicted_label = retrained_trees.predict(sample);

        if sample.true_label() {
            if predicted_label {
                t_p_retrained += 1;
            } else {
                f_n_retrained += 1;
            }
        } else {
            if predicted_label {
                f_p_retrained += 1;
            } else {
                t_n_retrained += 1;
            }
        }
    }

    let accuracy_retrained = (t_p_retrained + t_n_retrained) as f64 / test_data.len() as f64;

    println!(
        "{},hedgecut_forget,{},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{}",
        name,
        target_robustness,
        accuracy,
        t_p,
        f_n,
        f_p,
        t_n,
        accuracy_forget,
        t_p_forget,
        f_n_forget,
        f_p_forget,
        t_n_forget,
        accuracy_retrained,
        t_p_retrained,
        f_n_retrained,
        f_p_retrained,
        t_n_retrained
    );
}

pub fn forget2<D: Dataset + Sync, S: Sample + Sync>(
    name: &str,
    dataset: D,
    samples: Vec<S>,
    num_trees: usize,
    min_leaf_size: usize,
    max_tries_per_split: usize,
) {

    let mut rng = thread_rng();
    let seed = rng.next_u64();

    let target_robustness = ((dataset.num_records() as f64) / 1000.0).round() as usize;

    let samples_to_forget: Vec<S> = (0..target_robustness)
        .map(|_| {
            let index = rng.gen_range(0, dataset.num_records());
            samples.get(index as usize).unwrap().clone()
        })
        .collect();

    let mut ert = ExtremelyRandomizedTrees::fit(
        &dataset,
        samples,
        seed,
        num_trees,
        min_leaf_size,
        max_tries_per_split
    );

    // let training_duration = training_start.elapsed();
    // println!("Fitted {} trees in {} ms", num_trees, training_duration.as_millis());
    use crate::tree::Tree;

    let mut total_hit = 0;
    let mut total_changed = 0;

    for sample in &samples_to_forget {
        ert.trees.iter_mut().for_each(|tree| {
            let (hit, changed) = Tree::forget_from2(tree, sample, 1);
            total_hit += hit;
            total_changed += changed;
        });

        //println!("{},hedgecut,{}", name, removal_duration.as_micros());
    }

    println!("{},{},{},{}", name, min_leaf_size, total_hit, total_changed);
}

pub fn forget<D: Dataset + Sync, S: Sample + Sync>(
    name: &str,
    dataset: D,
    samples: Vec<S>,
    num_trees: usize,
    min_leaf_size: usize,
    max_tries_per_split: usize,
) {
    println!("{}--------------------------------------",name);
    let mut rng = thread_rng();
    let seed = rng.next_u64();

    let target_robustness = ((dataset.num_records() as f64) / 1000.0).round() as usize;
    println!("train size:{}, target robustness,{}", dataset.num_records() as f64,target_robustness);

    let samples_to_forget: Vec<S> = (0..target_robustness)
        .map(|_| {
            let index = rng.gen_range(0, dataset.num_records());
            samples.get(index as usize).unwrap().clone()
        })
        .collect();

    let training_start = Instant::now();
    let mut trees = ExtremelyRandomizedTrees::fit(
        &dataset,
        samples,
        seed,
        num_trees,
        min_leaf_size,
        max_tries_per_split
    );

    let training_duration = training_start.elapsed();
    println!("Fitted {} trees in {} ms", num_trees, training_duration.as_millis());

    let mut removal_total = 0;
    for sample in &samples_to_forget {
        let removal_start = Instant::now();
        trees.forget(sample);
        let removal_duration = removal_start.elapsed();
        removal_total += removal_duration.as_micros();
        println!("{},hedgecut,{} us", name, removal_duration.as_micros());
    }
    println!("{},hedgecut, total: {} us", name, removal_total);
    //println!("{},hedgecut, avg: {} us", name, removal_total.as_micros()/target_robustness);

    // 将输出内容格式化为字符串
    let output_string = format!("{},hedgecut, total: {} us", name, removal_total);

    // 打开文件（以追加模式）
    let file_path = "output.txt";
    let mut file = OpenOptions::new()
        .create(true)
        .append(true)
        .open(file_path)
        .expect("Failed to open file");

    // 将字符串写入文件
    match file.write_all(output_string.as_bytes()) {
        Ok(()) => println!("输出已写入文件：{}", file_path),
        Err(e) => eprintln!("写入文件时出现错误：{}", e),
    }
}

pub fn max_tries<D: Dataset + Sync, S: Sample + Sync>(
    name: &str,
    dataset: D,
    samples: Vec<S>,
    test_data: Vec<S>,
    num_trees: usize,
    min_leaf_size: usize,
    max_tries_per_split_candidates: Vec<usize>,
) {

    let mut rng = thread_rng();

    for _ in 0..6 {
        for max_tries_per_split in &max_tries_per_split_candidates {
            let seed = rng.next_u64();

            let training_samples = samples.clone();

            let training_start = Instant::now();
            let trees = ExtremelyRandomizedTrees::fit(
                &dataset,
                training_samples,
                seed,
                num_trees,
                min_leaf_size,
                max_tries_per_split.clone()
            );
            let training_duration = training_start.elapsed();
            evaluate(
                name,
                &trees,
                &test_data,
                Some((training_duration.as_millis(), max_tries_per_split.clone()))
            );
        }
    }

}

pub fn train_time<D: Dataset + Sync, S: Sample + Sync>(
    name: &str,
    dataset: D,
    samples: Vec<S>,
    num_trees: usize,
    min_leaf_size: usize,
    max_tries_per_split: usize,
) {

    let mut rng = thread_rng();

    let seed = rng.next_u64();

    let training_samples = samples.clone();

    let training_start = Instant::now();
    ExtremelyRandomizedTrees::fit(
        &dataset,
        training_samples,
        seed,
        num_trees,
        min_leaf_size,
        max_tries_per_split.clone()
    );
    let training_duration = training_start.elapsed();
    println!("{},hedgecut,{}", name, training_duration.as_millis());
}

pub fn robustness<D: Dataset + Sync, S: Sample + Sync>(
    name: &str,
    dataset: D,
    samples: Vec<S>,
    num_trees: usize,
    min_leaf_size: usize,
    max_tries_per_split: usize,
) {

    let mut rng = thread_rng();

    let seed = rng.next_u64();

    for epsilon_factor in &[10000, 5000, 1000, 500, 100, 50] {
        let training_samples = samples.clone();
        let epsilon = 1.0 / *epsilon_factor as f64;

        let training_start = Instant::now();
        ExtremelyRandomizedTrees::fit_with_epsilon(
            &dataset,
            training_samples,
            seed,
            num_trees,
            min_leaf_size,
            max_tries_per_split.clone(),
            epsilon
        );
        let training_duration = training_start.elapsed();
        println!("{},hedgecut,{},{}", name, epsilon_factor, training_duration.as_millis());
    }
}

pub fn robustness2<D: Dataset + Sync, S: Sample + Sync>(
    name: &str,
    dataset: D,
    samples: Vec<S>,
    num_trees: usize,
    min_leaf_size: usize,
    max_tries_per_split: usize,
) {

    let mut rng = thread_rng();

    let seed = rng.next_u64();

    for epsilon_factor in &[10000, 5000, 1000, 500, 100, 50] {
        let training_samples = samples.clone();
        let epsilon = 1.0 / *epsilon_factor as f64;

        let ert = ExtremelyRandomizedTrees::fit_with_epsilon(
            &dataset,
            training_samples,
            seed,
            num_trees,
            min_leaf_size,
            max_tries_per_split.clone(),
            epsilon
        );

        let mut num_robust = 0;
        let mut num_non_robust = 0;

        for tree in ert.trees {
            let (tree_num_robust, tree_num_non_robust) = node_count(tree);
            num_robust += tree_num_robust;
            num_non_robust += tree_num_non_robust;
        }
        let ratio = num_non_robust as f64 / (num_non_robust + num_robust) as f64;

        println!("{},hedgecut,{},{},{},{}", name, epsilon_factor, ratio, num_robust, num_non_robust);
    }
}

//====================================================================================================
pub fn node_count(tree: crate::tree::Tree) -> (usize, usize) {

    let mut num_robust = 0;
    let mut num_non_robust = 0;

    num_robust += tree.num_robust_nodes;
    num_non_robust += tree.num_non_robust_nodes;

    for (_, subtrees) in tree.alternative_subtrees {
        for subtree in subtrees {
            let (subtree_num_robust, subtree_num_non_robust) = node_count(subtree.tree);
            num_robust += subtree_num_robust;
            num_non_robust += subtree_num_non_robust;
        }
    }


    (num_robust, num_non_robust)

}

pub fn robustness_accuracy<D: Dataset + Sync, S: Sample + Sync>(
    name: &str,
    dataset: D,
    samples: Vec<S>,
    test_data: Vec<S>,
    num_trees: usize,
    min_leaf_size: usize,
    max_tries_per_split: usize,
) {

    let mut rng = thread_rng();

    let seed = rng.next_u64();

    for epsilon_factor in &[10000, 5000, 1000, 500, 100, 50] {
        let training_samples = samples.clone();
        let epsilon = 1.0 / *epsilon_factor as f64;

        let trees = ExtremelyRandomizedTrees::fit_with_epsilon(
            &dataset,
            training_samples,
            seed,
            num_trees,
            min_leaf_size,
            max_tries_per_split.clone(),
            epsilon
        );

        let mut t_p = 0;
        let mut t_n = 0;

        for sample in test_data.iter() {
            let predicted_label = trees.predict(sample);

            if sample.true_label() {
                if predicted_label {
                    t_p += 1;
                }
            } else {
                if !predicted_label {
                    t_n += 1;
                }
            }
        }

        let accuracy = (t_p + t_n) as f64 / test_data.len() as f64;
        println!("{},{},{}", name, epsilon_factor, accuracy);
    }


}

#[derive(Clone)]
enum Request<S: Sample> {
    Predict(S),
    Forget(S),
}

pub fn stress_test<D: Dataset + Sync, S: Sample + Sync>(
    name: &str,
    dataset: D,
    samples: Vec<S>,
    test_data: Vec<S>,
    multiplication_factor: usize,
    num_trees: usize,
    min_leaf_size: usize,
    max_tries_per_split: usize,
) {
    let mut rng = thread_rng();

    let target_robustness = ((dataset.num_records() as f64) / 1000.0).round() as usize;

    let mut stress_test_data = Vec::new();
    for _ in 0..multiplication_factor {
        for sample in &test_data {
            stress_test_data.push(Request::Predict(sample.clone()));
        }
    }

    stress_test_data.shuffle(&mut rng);

    let mut stress_test_data_with_forgets = stress_test_data.clone();

    (0..target_robustness)
        .for_each(|_| {
            let sample_to_forget_index = rng.gen_range(0, samples.len());
            let sample_to_forget = samples.get(sample_to_forget_index).unwrap().clone();
            let forget_request = Request::Forget(sample_to_forget);

            let forget_request_index = rng.gen_range(0, stress_test_data_with_forgets.len());
            let request = stress_test_data_with_forgets.get_mut(forget_request_index).unwrap();
            *request = forget_request;
        });

    let seed = rng.next_u64();

    let mut trees = ExtremelyRandomizedTrees::fit(
        &dataset,
        samples,
        seed,
        num_trees,
        min_leaf_size,
        max_tries_per_split.clone()
    );

    let prediction_start = Instant::now();
    for test_sample in &stress_test_data {
        match test_sample {
            Request::Predict(sample) => { trees.predict(sample); } ,
            Request::Forget(sample) => trees.forget(sample),
        }
    }
    let prediction_duration = prediction_start.elapsed();
    let throughput =
        ((stress_test_data.len() as f64 / prediction_duration.as_millis() as f64)
            * 1000.0) as usize;

    println!("{},predict_only,{},{}", name, prediction_duration.as_millis(), throughput);

    let prediction_start = Instant::now();
    for test_sample in &stress_test_data_with_forgets {
        match test_sample {
            Request::Predict(sample) => { trees.predict(sample); } ,
            Request::Forget(sample) => trees.forget(sample),
        }
    }
    let prediction_duration = prediction_start.elapsed();
    let throughput =
        ((stress_test_data_with_forgets.len() as f64 / prediction_duration.as_millis() as f64)
            * 1000.0) as usize;

    println!("{},forgets,{},{}", name, prediction_duration.as_millis(), throughput);
}
