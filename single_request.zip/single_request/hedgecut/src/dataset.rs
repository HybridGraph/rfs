use std::str::FromStr;
use crate::tree::Split;

pub trait Dataset {
    fn num_records(&self) -> u32;
    fn num_plus(&self) -> u32;
    fn num_attributes(&self) -> u8;
    fn attribute_range(&self, index: u8) -> (u8, u8);
    fn attribute_type(&self, index: u8) -> AttributeType;
}

pub enum AttributeType {
    Numerical,
    Categorical
}

pub trait Sample: Clone {

    fn is_left_of(&self, split: &Split) -> bool {

        let attribute_index = split.attribute_index();
        let attribute_value = self.attribute_value(attribute_index);

        match split {
            Split::Numerical { attribute_index: _, cut_off } => {
                attribute_value < *cut_off
            },
            Split::Categorical { attribute_index: _, subset } => {
                *subset & (1_u64 << attribute_value as u64) != 0
            }

        }
    }

    fn attribute_value(&self, attribute_index: u8) -> u8;
    fn true_label(&self) -> bool;
}

// =============================
pub struct TitanicDataset {
    pub num_records: u32,
    pub num_plus: u32,
}

#[derive(Eq,PartialEq,Debug,Clone)]
pub struct TitanicSample {
    pub age: u8,
    pub fare: u8,
    pub siblings: u8,
    pub children: u8,
    pub gender: u8,
    pub pclass: u8,
    pub label: bool,
}

impl Sample for TitanicSample {

    fn attribute_value(&self, attribute_index: u8) -> u8 {
        match attribute_index {
            0 => self.age,
            1 => self.fare,
            2 => self.siblings,
            3 => self.children,
            4 => self.gender,
            5 => self.pclass,
            _ => panic!("Requested range for non-existing attribute {}!", attribute_index)
        }
    }

    fn true_label(&self) -> bool {
        self.label
    }
}

impl TitanicDataset {

    pub fn from_samples(samples: &Vec<TitanicSample>) -> TitanicDataset {
        let num_plus = samples.iter().filter(|sample| sample.true_label()).count();

        TitanicDataset {
            num_records: samples.len() as u32,
            num_plus: num_plus as u32
        }
    }

    pub fn samples_from_csv(file: &str) -> Vec<TitanicSample> {

        let mut samples: Vec<TitanicSample> = Vec::new();


        let mut reader = csv::ReaderBuilder::new()
            .has_headers(true)
            .delimiter(b'\t')
            .from_path(file)
            .unwrap();

        for result in reader.records() {
            let record = result.unwrap();

            let age = u8::from_str(record.get(1).unwrap()).unwrap();
            let fare = u8::from_str(record.get(2).unwrap()).unwrap();
            let siblings = u8::from_str(record.get(3).unwrap()).unwrap();
            let children = u8::from_str(record.get(4).unwrap()).unwrap();
            let gender = u8::from_str(record.get(5).unwrap()).unwrap();
            let pclass = u8::from_str(record.get(6).unwrap()).unwrap();
            let label = u8::from_str(record.get(4).unwrap()).unwrap() == 1;

            let sample = TitanicSample { age, fare, siblings, children, gender, pclass, label };

            samples.push(sample);
        }

        samples
    }

}

impl Dataset for TitanicDataset {

    fn num_records(&self) -> u32 { self.num_records }

    fn num_plus(&self) -> u32 { self.num_plus }

    fn num_attributes(&self) -> u8 { 6 }

    fn attribute_range(&self, index: u8) -> (u8, u8) {
        match index {
            0 => (0, 19),
            1 => (0, 19),
            2 => (0, 8),
            3 => (0, 6),
            4 => (0, 1),
            5 => (0, 2),
            _ => panic!("Requested range for non-existing attribute {}!", index)
        }
    }

    fn attribute_type(&self, index: u8) -> AttributeType {
        match index {
            0 => AttributeType::Numerical,
            1 => AttributeType::Numerical,
            2 => AttributeType::Numerical,
            3 => AttributeType::Numerical,
            4 => AttributeType::Categorical,
            5 => AttributeType::Categorical,
            _ => panic!("Requested range for non-existing attribute {}!", index)
        }
    }
}
// ==================================
pub struct DefaultsDataset {
    pub num_records: u32,
    pub num_plus: u32,
}

impl DefaultsDataset {

    pub fn from_samples(samples: &Vec<DefaultsSample>) -> DefaultsDataset {
        let num_plus = samples.iter().filter(|sample| sample.true_label()).count();

        DefaultsDataset {
            num_records: samples.len() as u32,
            num_plus: num_plus as u32
        }
    }

    pub fn samples_from_csv(file: &str) -> Vec<DefaultsSample> {

        let mut samples: Vec<DefaultsSample> = Vec::new();

        let mut reader = csv::ReaderBuilder::new()
            .has_headers(true)
            .delimiter(b'\t')
            .from_path(file)
            .unwrap();

        for result in reader.records() {
            let record = result.unwrap();

            let limit = u8::from_str(record.get(1).unwrap()).unwrap();
            let sex = u8::from_str(record.get(2).unwrap()).unwrap();
            let education = u8::from_str(record.get(3).unwrap()).unwrap();
            let marriage = u8::from_str(record.get(4).unwrap()).unwrap();
            let age = u8::from_str(record.get(5).unwrap()).unwrap();
            let pay0 = u8::from_str(record.get(6).unwrap()).unwrap();
            let pay2 = u8::from_str(record.get(7).unwrap()).unwrap();
            let pay3 = u8::from_str(record.get(8).unwrap()).unwrap();
            let pay4 = u8::from_str(record.get(9).unwrap()).unwrap();
            let pay5 = u8::from_str(record.get(10).unwrap()).unwrap();
            let pay6 = u8::from_str(record.get(11).unwrap()).unwrap();
            let bill_amt1 = u8::from_str(record.get(12).unwrap()).unwrap();
            let bill_amt2 = u8::from_str(record.get(13).unwrap()).unwrap();
            let bill_amt3 = u8::from_str(record.get(14).unwrap()).unwrap();
            let bill_amt4 = u8::from_str(record.get(15).unwrap()).unwrap();
            let bill_amt5 = u8::from_str(record.get(16).unwrap()).unwrap();
            let bill_amt6 = u8::from_str(record.get(17).unwrap()).unwrap();
            let pay_amt1 = u8::from_str(record.get(18).unwrap()).unwrap();
            let pay_amt2 = u8::from_str(record.get(19).unwrap()).unwrap();
            let pay_amt3 = u8::from_str(record.get(20).unwrap()).unwrap();
            let pay_amt4 = u8::from_str(record.get(21).unwrap()).unwrap();
            let pay_amt5 = u8::from_str(record.get(22).unwrap()).unwrap();
            let pay_amt6 = u8::from_str(record.get(23).unwrap()).unwrap();
            let label = u8::from_str(record.get(24).unwrap()).unwrap() == 1;

            let sample = DefaultsSample {
                limit,
                sex,
                education,
                marriage,
                age,
                pay0,
                pay2,
                pay3,
                pay4,
                pay5,
                pay6,
                bill_amt1,
                bill_amt2,
                bill_amt3,
                bill_amt4,
                bill_amt5,
                bill_amt6,
                pay_amt1,
                pay_amt2,
                pay_amt3,
                pay_amt4,
                pay_amt5,
                pay_amt6,
                label
            };

            samples.push(sample);
        }

        samples
    }
}

impl Dataset for DefaultsDataset {

    fn num_records(&self) -> u32 {
        self.num_records
    }

    fn num_plus(&self) -> u32 { self.num_plus }

    fn num_attributes(&self) -> u8 {
        23
    }

    fn attribute_range(&self, index: u8) -> (u8, u8) {
        match index {
            0 => (0, 14),
            1 => (0, 1),
            2 => (0, 6),
            3 => (0, 3),
            4 => (0, 15),
            5 => (0, 10),
            6 => (0, 9),
            7 => (0, 10),
            8 => (0, 10),
            9 => (0, 10),
            10 => (0, 10),
            11 => (0, 15),
            12 => (0, 15),
            13 => (0, 15),
            14 => (0, 14),
            15 => (0, 14),
            16 => (0, 14),
            17 => (0, 13),
            18 => (0, 13),
            19 => (0, 12),
            20 => (0, 12),
            21 => (0, 12),
            22 => (0, 12),
            _ => panic!("Requested non-existing attribute!")
        }
    }

    fn attribute_type(&self, index: u8) -> AttributeType {
        match index {
            0 => AttributeType::Numerical,
            1 => AttributeType::Categorical,
            2 => AttributeType::Categorical,
            3 => AttributeType::Categorical,
            4 => AttributeType::Numerical,
            5 => AttributeType::Numerical,
            6 => AttributeType::Numerical,
            7 => AttributeType::Numerical,
            8 => AttributeType::Numerical,
            9 => AttributeType::Numerical,
            10 => AttributeType::Numerical,
            11 => AttributeType::Numerical,
            12 => AttributeType::Numerical,
            13 => AttributeType::Numerical,
            14 => AttributeType::Numerical,
            15 => AttributeType::Numerical,
            16 => AttributeType::Numerical,
            17 => AttributeType::Numerical,
            18 => AttributeType::Numerical,
            19 => AttributeType::Numerical,
            20 => AttributeType::Numerical,
            21 => AttributeType::Numerical,
            22 => AttributeType::Numerical,
            _ => panic!("Requested non-existing attribute!")
        }
    }
}

#[derive(Eq,PartialEq,Debug,Clone)]
pub struct DefaultsSample {
    pub limit: u8,
    pub sex: u8,
    pub education: u8,
    pub marriage: u8,
    pub age: u8,
    pub pay0: u8,
    pub pay2: u8,
    pub pay3: u8,
    pub pay4: u8,
    pub pay5: u8,
    pub pay6: u8,
    pub bill_amt1: u8,
    pub bill_amt2: u8,
    pub bill_amt3: u8,
    pub bill_amt4: u8,
    pub bill_amt5: u8,
    pub bill_amt6: u8,
    pub pay_amt1: u8,
    pub pay_amt2: u8,
    pub pay_amt3: u8,
    pub pay_amt4: u8,
    pub pay_amt5: u8,
    pub pay_amt6: u8,
    pub label: bool,
}

impl Sample for DefaultsSample {

    fn attribute_value(&self, attribute_index: u8) -> u8 {
        match attribute_index {
            0 => self.limit,
            1 => self.sex,
            2 => self.education,
            3 => self.marriage,
            4 => self.age,
            5 => self.pay0,
            6 => self.pay2,
            7 => self.pay3,
            8 => self.pay4,
            9 => self.pay5,
            10 => self.pay6,
            11 => self.bill_amt1,
            12 => self.bill_amt2,
            13 => self.bill_amt3,
            14 => self.bill_amt4,
            15 => self.bill_amt5,
            16 => self.bill_amt6,
            17 => self.pay_amt1,
            18 => self.pay_amt2,
            19 => self.pay_amt3,
            20 => self.pay_amt4,
            21 => self.pay_amt5,
            22 => self.pay_amt6,
            _ => panic!("Requested non-existing attribute!")
        }
    }


    fn true_label(&self) -> bool {
        self.label
    }
}



// =====================adult=====================================
pub struct AdultDataset {
    pub num_records: u32,
    pub num_plus: u32,
}

#[derive(Eq,PartialEq,Debug,Clone)]
pub struct AdultSample {
    pub age: u8,
    pub workclass: u8,
    pub fnlwgt: u8,
    pub education: u8,
    pub marital_status: u8,
    pub occupation: u8,
    pub relationship: u8,
    pub race: u8,
    pub sex: u8,
    pub capital_gain: u8,
    pub hours_per_week: u8,
    pub native_country: u8,
    pub label: bool,
}

impl AdultDataset {

    pub fn from_samples(samples: &Vec<AdultSample>) -> AdultDataset {
        let num_plus = samples.iter().filter(|sample| sample.true_label()).count();

        AdultDataset {
            num_records: samples.len() as u32,
            num_plus: num_plus as u32
        }
    }

    pub fn samples_from_csv(file: &str) -> Vec<AdultSample> {

        let mut samples: Vec<AdultSample> = Vec::new();

        let mut reader = csv::ReaderBuilder::new()
            .has_headers(true)
            .delimiter(b'\t')
            .from_path(file)
            .unwrap();

        for result in reader.records() {
            let record = result.unwrap();

            let age = u8::from_str(record.get(1).unwrap()).unwrap();
            let workclass = u8::from_str(record.get(2).unwrap()).unwrap();
            let fnlwgt = u8::from_str(record.get(3).unwrap()).unwrap();
            let education = u8::from_str(record.get(4).unwrap()).unwrap();
            let marital_status = u8::from_str(record.get(5).unwrap()).unwrap();
            let occupation = u8::from_str(record.get(6).unwrap()).unwrap();
            let relationship = u8::from_str(record.get(7).unwrap()).unwrap();
            let race = u8::from_str(record.get(8).unwrap()).unwrap();
            let sex = u8::from_str(record.get(9).unwrap()).unwrap();
            let capital_gain = u8::from_str(record.get(10).unwrap()).unwrap();
            let hours_per_week = u8::from_str(record.get(11).unwrap()).unwrap();
            let native_country = u8::from_str(record.get(12).unwrap()).unwrap();
            let label = u8::from_str(record.get(13).unwrap()).unwrap() == 1;

            let sample = AdultSample {
                age,
                workclass,
                fnlwgt,
                education,
                marital_status,
                occupation,
                relationship,
                race,
                sex,
                capital_gain,
                hours_per_week,
                native_country,
                label
            };

            samples.push(sample);
        }

        samples
    }
}

impl Dataset for AdultDataset {

    fn num_records(&self) -> u32 { self.num_records }

    fn num_plus(&self) -> u32 { self.num_plus }

    fn num_attributes(&self) -> u8 { 12 }

    fn attribute_range(&self, index: u8) -> (u8, u8) {
        match index {
            0 => (0, 15),
            1 => (0, 6),
            2 => (0, 15),
            3 => (0, 15),
            4 => (0, 6),
            5 => (0, 13),
            6 => (0, 5),
            7 => (0, 4),
            8 => (0, 1),
            9 => (0, 1),
            10 => (0, 7),
            11 => (0, 40),
            _ => panic!("Requested range for non-existing attribute {}!", index)
        }
    }

    fn attribute_type(&self, index: u8) -> AttributeType {
        match index {
            0 => AttributeType::Numerical,
            1 => AttributeType::Categorical,
            2 => AttributeType::Numerical,
            3 => AttributeType::Categorical,
            4 => AttributeType::Categorical,
            5 => AttributeType::Categorical,
            6 => AttributeType::Categorical,
            7 => AttributeType::Categorical,
            8 => AttributeType::Categorical,
            9 => AttributeType::Numerical,
            10 => AttributeType::Numerical,
            11 => AttributeType::Categorical,
            _ => panic!("Requested range for non-existing attribute {}!", index)
        }
    }
}

impl Sample for AdultSample {

    fn attribute_value(&self, attribute_index: u8) -> u8 {

        match attribute_index {
            0 => self.age,
            1 => self.workclass,
            2 => self.fnlwgt,
            3 => self.education,
            4 => self.marital_status,
            5 => self.occupation,
            6 => self.relationship,
            7 => self.race,
            8 => self.sex,
            9 => self.capital_gain,
            10 => self.hours_per_week,
            11 => self.native_country,
            _ => panic!("Requested non-existing attribute {}!", attribute_index)
        }
    }

    fn true_label(&self) -> bool {
        self.label
    }
}

// ======================bank==================================
pub struct BankDataset {
    pub num_records: u32,
    pub num_plus: u32,
}
#[derive(Eq,PartialEq,Debug,Clone)]
pub struct BankSample {
    pub age: u8,
    pub duration: u8,
    pub campaign: u8,
    pub pdays: u8,
    pub previous: u8,
    pub emp_var_rate: u8,
    pub cons_price_idx: u8,
    pub cons_conf_idx: u8,
    pub euribor3m: u8,
    pub nr_employed: u8,
    pub job: u8,
    pub marital: u8,
    pub education: u8,
    pub default: u8,
    pub housing: u8,
    pub loan: u8,
    pub contact: u8,
    pub month: u8,
    pub day_of_week: u8,
    pub poutcome: u8,
    pub label: bool,
}

impl BankDataset {
    pub fn from_samples(samples: &Vec<BankSample>) -> BankDataset {
        let num_plus = samples.iter().filter(|sample| sample.true_label()).count();

        BankDataset {
            num_records: samples.len() as u32,
            num_plus: num_plus as u32,
        }
    }

    pub fn samples_from_csv(file: &str) -> Vec<BankSample> {
        let mut samples: Vec<BankSample> = Vec::new();

        let mut reader = csv::ReaderBuilder::new()
            .has_headers(true)
            .delimiter(b'\t')
            .from_path(file)
            .unwrap();

        for result in reader.records() {
            let record = result.unwrap();

            let age = u8::from_str(record.get(1).unwrap()).unwrap();
            let duration = u8::from_str(record.get(2).unwrap()).unwrap();
            let campaign = u8::from_str(record.get(3).unwrap()).unwrap();
            let pdays = u8::from_str(record.get(4).unwrap()).unwrap();
            let previous = u8::from_str(record.get(5).unwrap()).unwrap();
            let emp_var_rate = u8::from_str(record.get(6).unwrap()).unwrap();
            let cons_price_idx = u8::from_str(record.get(7).unwrap()).unwrap();
            let cons_conf_idx = u8::from_str(record.get(8).unwrap()).unwrap();
            let euribor3m = u8::from_str(record.get(9).unwrap()).unwrap();
            let nr_employed = u8::from_str(record.get(10).unwrap()).unwrap();
            let job = u8::from_str(record.get(11).unwrap()).unwrap();
            let marital = u8::from_str(record.get(12).unwrap()).unwrap();
            let education = u8::from_str(record.get(13).unwrap()).unwrap();
            let default = u8::from_str(record.get(14).unwrap()).unwrap();
            let housing = u8::from_str(record.get(15).unwrap()).unwrap();
            let loan = u8::from_str(record.get(16).unwrap()).unwrap();
            let contact = u8::from_str(record.get(17).unwrap()).unwrap();
            let month = u8::from_str(record.get(18).unwrap()).unwrap();
            let day_of_week = u8::from_str(record.get(19).unwrap()).unwrap();
            let poutcome = u8::from_str(record.get(20).unwrap()).unwrap();
            let label = u8::from_str(record.get(21).unwrap()).unwrap() == 1;

            let sample = BankSample {
                age,
                duration,
                campaign,
                pdays,
                previous,
                emp_var_rate,
                cons_price_idx,
                cons_conf_idx,
                euribor3m,
                nr_employed,
                job,
                marital,
                education,
                default,
                housing,
                loan,
                contact,
                month,
                day_of_week,
                poutcome,
                label
            };

            samples.push(sample);
        }

        samples
    }
}

impl Dataset for BankDataset {
    fn num_records(&self) -> u32 { self.num_records }

    fn num_plus(&self) -> u32 { self.num_plus }

    fn num_attributes(&self) -> u8 { 20 }

    fn attribute_range(&self, index: u8) -> (u8, u8) {
        match index {
            0 => (0, 15),
            1 => (0, 15),
            2 => (0, 4),
            3 => (0, 0),
            4 => (0, 1),
            5 => (0, 5),
            6 => (0, 9),
            7 => (0, 8),
            8 => (0, 15),
            9 => (0, 4),
            10 => (0, 11),
            11 => (0, 3),
            12 => (0, 7),
            13 => (0, 2),
            14 => (0, 2),
            15 => (0, 2),
            16 => (0, 1),
            17 => (0, 9),
            18 => (0, 4),
            19 => (0, 2),
            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }

    fn attribute_type(&self, index: u8) -> AttributeType {
        match index {
            0 => AttributeType::Numerical,
            1 => AttributeType::Numerical,
            2 => AttributeType::Numerical,
            3 => AttributeType::Numerical,
            4 => AttributeType::Numerical,
            5 => AttributeType::Numerical,
            6 => AttributeType::Numerical,
            7 => AttributeType::Numerical,
            8 => AttributeType::Numerical,
            9 => AttributeType::Numerical,

            10 => AttributeType::Categorical,
            11 => AttributeType::Categorical,
            12 => AttributeType::Categorical,
            13 => AttributeType::Categorical,
            14 => AttributeType::Categorical,
            15 => AttributeType::Categorical,
            16 => AttributeType::Categorical,
            17 => AttributeType::Categorical,
            18 => AttributeType::Categorical,
            19 => AttributeType::Categorical,

            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }
}


impl Sample for BankSample {

    fn attribute_value(&self, attribute_index: u8) -> u8 {

        match attribute_index {
            0 => self.age,
            1 => self.duration,
            2 => self.campaign,
            3 => self.pdays,
            4 => self.previous,
            5 => self.emp_var_rate,
            6 => self.cons_price_idx,
            7 => self.cons_conf_idx,
            8 => self.euribor3m,
            9 => self.nr_employed,
            10 => self.job,
            11 => self.marital,
            12 => self.education,
            13 => self.default,
            14 => self.housing,
            15 => self.loan,
            16 => self.contact,
            17 => self.month,
            18 => self.day_of_week,
            19 => self.poutcome,
            _ => panic!("Requested non-existing attribute {}!", attribute_index)
        }
    }

    fn true_label(&self) -> bool {
        self.label
    }
}

// =====================flight================================
pub struct FlightDataset {
    pub num_records: u32,
    pub num_plus: u32,
}
#[derive(Eq,PartialEq,Debug,Clone)]
pub struct FlightSample {
    pub dep_time: u8,
    pub distance: u8,
    pub month: u8,
    pub dayof_month: u8,
    pub dayof_week: u8,
    pub unique_carrier: u8,
    pub origin: u8,
    pub dest: u8,
    pub label: bool,
}

impl FlightDataset {
    pub fn from_samples(samples: &Vec<FlightSample>) -> FlightDataset {
        let num_plus = samples.iter().filter(|sample| sample.true_label()).count();

        FlightDataset {
            num_records: samples.len() as u32,
            num_plus: num_plus as u32,
        }
    }

    pub fn samples_from_csv(file: &str) -> Vec<FlightSample> {
        let mut samples: Vec<FlightSample> = Vec::new();

        let mut reader = csv::ReaderBuilder::new()
            .has_headers(true)
            .delimiter(b'\t')
            .from_path(file)
            .unwrap();

        for result in reader.records() {
            let record = result.unwrap();

            let dep_time = u8::from_str(record.get(1).unwrap()).unwrap();
            let distance = u8::from_str(record.get(2).unwrap()).unwrap();
            let month = u8::from_str(record.get(3).unwrap()).unwrap();
            let dayof_month = u8::from_str(record.get(4).unwrap()).unwrap();
            let dayof_week = u8::from_str(record.get(5).unwrap()).unwrap();
            let unique_carrier = u8::from_str(record.get(6).unwrap()).unwrap();
            let origin = u8::from_str(record.get(7).unwrap()).unwrap();
            let dest = u8::from_str(record.get(8).unwrap()).unwrap();

            let label = u8::from_str(record.get(9).unwrap()).unwrap() == 1;

            let sample = FlightSample {
                dep_time,
                distance,
                month,
                dayof_month,
                dayof_week,
                unique_carrier,
                origin,
                dest,
                label
            };

            samples.push(sample);
        }

        samples
    }
}


impl Dataset for FlightDataset {
    fn num_records(&self) -> u32 { self.num_records }

    fn num_plus(&self) -> u32 { self.num_plus }

    fn num_attributes(&self) -> u8 { 8 }

    fn attribute_range(&self, index: u8) -> (u8, u8) {
        match index {
            0 => (0, 15),
            1 => (0, 15),
            2 => (0, 11),
            3 => (0, 30),
            4 => (0, 6),
            5 => (0, 21),
            6 => (0, 63),
            7 => (0, 63),

            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }

    fn attribute_type(&self, index: u8) -> AttributeType {
        match index {
            0 => AttributeType::Numerical,
            1 => AttributeType::Numerical,

            2 => AttributeType::Categorical,
            3 => AttributeType::Categorical,
            4 => AttributeType::Categorical,
            5 => AttributeType::Categorical,
            6 => AttributeType::Categorical,
            7 => AttributeType::Categorical,
            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }
}

impl Sample for FlightSample {

    fn attribute_value(&self, attribute_index: u8) -> u8 {

        match attribute_index {
            0 => self.dep_time,
            1 => self.distance,
            2 => self.month,
            3 => self.dayof_month,
            4 => self.dayof_week,
            5 => self.unique_carrier,
            6 => self.origin,
            7 => self.dest,
            _ => panic!("Requested non-existing attribute {}!", attribute_index)
        }
    }

    fn true_label(&self) -> bool {
        self.label
    }
}

// ====================surgical==================================
pub struct SurgicalDataset {
    pub num_records: u32,
    pub num_plus: u32,
}
#[derive(Eq,PartialEq,Debug,Clone)]
pub struct SurgicalSample {
    pub bmi: u8,
    pub age: u8,
    pub asa_status: u8,
    pub baseline_cancer: u8,
    pub baseline_charlson: u8,
    pub baseline_cvd: u8,
    pub baseline_dementia: u8,
    pub baseline_diabetes: u8,
    pub baseline_digestive: u8,
    pub baseline_osteoart: u8,
    pub baseline_psych: u8,
    pub baseline_pulmonary: u8,
    pub ahrq_ccs: u8,
    pub ccs_complication_rate: u8,
    pub ccs_mort30rate: u8,
    pub complication_rsi: u8,
    pub dow: u8,
    pub gender: u8,
    pub hour: u8,
    pub month: u8,
    pub moonphase: u8,
    pub mort30: u8,
    pub mortality_rsi: u8,
    pub race: u8,
    //超过50就溢出了 不行
    pub label: bool,
}

impl SurgicalDataset {
    pub fn from_samples(samples: &Vec<SurgicalSample>) -> SurgicalDataset {
        let num_plus = samples.iter().filter(|sample| sample.true_label()).count();

        SurgicalDataset {
            num_records: samples.len() as u32,
            num_plus: num_plus as u32,
        }
    }

    pub fn samples_from_csv(file: &str) -> Vec<SurgicalSample> {
        let mut samples: Vec<SurgicalSample> = Vec::new();

        let mut reader = csv::ReaderBuilder::new()
            .has_headers(true)
            .delimiter(b'\t')
            .from_path(file)
            .unwrap();

        for result in reader.records() {
            let record = result.unwrap();

            let bmi = u8::from_str(record.get(1).unwrap()).unwrap();
            let age = u8::from_str(record.get(2).unwrap()).unwrap();
            let asa_status = u8::from_str(record.get(3).unwrap()).unwrap();
            let baseline_cancer = u8::from_str(record.get(4).unwrap()).unwrap();
            let baseline_charlson = u8::from_str(record.get(5).unwrap()).unwrap();
            let baseline_cvd = u8::from_str(record.get(6).unwrap()).unwrap();
            let baseline_dementia = u8::from_str(record.get(7).unwrap()).unwrap();
            let baseline_diabetes = u8::from_str(record.get(8).unwrap()).unwrap();
            let baseline_digestive = u8::from_str(record.get(9).unwrap()).unwrap();
            let baseline_osteoart = u8::from_str(record.get(10).unwrap()).unwrap();
            let baseline_psych = u8::from_str(record.get(11).unwrap()).unwrap();
            let baseline_pulmonary = u8::from_str(record.get(12).unwrap()).unwrap();
            let ahrq_ccs = u8::from_str(record.get(13).unwrap()).unwrap();
            let ccs_complication_rate = u8::from_str(record.get(14).unwrap()).unwrap();
            let ccs_mort30rate = u8::from_str(record.get(15).unwrap()).unwrap();
            let complication_rsi = u8::from_str(record.get(16).unwrap()).unwrap();
            let dow = u8::from_str(record.get(17).unwrap()).unwrap();
            let gender = u8::from_str(record.get(18).unwrap()).unwrap();
            let hour = u8::from_str(record.get(19).unwrap()).unwrap();
            let month = u8::from_str(record.get(20).unwrap()).unwrap();
            let moonphase = u8::from_str(record.get(21).unwrap()).unwrap();
            let mort30 = u8::from_str(record.get(22).unwrap()).unwrap();
            let mortality_rsi = u8::from_str(record.get(23).unwrap()).unwrap();
            let race = u8::from_str(record.get(24).unwrap()).unwrap();

            let label = u8::from_str(record.get(25).unwrap()).unwrap() == 1;

            let sample = SurgicalSample {
                bmi,
                age,
                asa_status,
                baseline_cancer,
                baseline_charlson,
                baseline_cvd,
                baseline_dementia,
                baseline_diabetes,
                baseline_digestive,
                baseline_osteoart,
                baseline_psych,
                baseline_pulmonary,
                ahrq_ccs,
                ccs_complication_rate,
                ccs_mort30rate,
                complication_rsi,
                dow,
                gender,
                hour,
                month,
                moonphase,
                mort30,
                mortality_rsi,
                race,
                label
            };

            samples.push(sample);
        }

        samples
    }
}


impl Dataset for SurgicalDataset {
    fn num_records(&self) -> u32 { self.num_records }

    fn num_plus(&self) -> u32 { self.num_plus }

    fn num_attributes(&self) -> u8 { 24 }

    fn attribute_range(&self, index: u8) -> (u8, u8) {
        match index {
                0 => (0, 12),
                1 => (0, 12),
                2 => (0, 12),
                3 => (0, 10),
                4 => (0, 12),
                5 => (0, 13),
                6 => (0, 12),

                7 => (0, 2),
                8 => (0, 1),
                9 => (0, 13),
                10 => (0, 1),
                11 => (0, 1),
                12 => (0, 1),
                13 => (0, 1),
                14 => (0, 1),
                15 => (0, 1),
                16 => (0, 1),
                17 => (0, 21),
                18 => (0, 4),
                19 => (0, 1),
                20 => (0, 11),
                21 => (0, 3),
                22 => (0, 1),
                23 => (0, 2),
            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }

    fn attribute_type(&self, index: u8) -> AttributeType {
        match index {

            0 => AttributeType::Numerical,
            1 => AttributeType::Numerical,
            2 => AttributeType::Numerical,
            3 => AttributeType::Numerical,
            4 => AttributeType::Numerical,
            5 => AttributeType::Numerical,
            6 => AttributeType::Numerical,

            7 => AttributeType::Categorical,
            8 => AttributeType::Categorical,
            9 => AttributeType::Categorical,
            10 => AttributeType::Categorical,
            11 => AttributeType::Categorical,
            12 => AttributeType::Categorical,
            13 => AttributeType::Categorical,
            14 => AttributeType::Categorical,
            15 => AttributeType::Categorical,
            16 => AttributeType::Categorical,
            17 => AttributeType::Categorical,
            18 => AttributeType::Categorical,
            19 => AttributeType::Categorical,
            20 => AttributeType::Categorical,
            21 => AttributeType::Categorical,
            22 => AttributeType::Categorical,
            23 => AttributeType::Categorical,
            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }
}

impl Sample for SurgicalSample {

    fn attribute_value(&self, attribute_index: u8) -> u8 {

        match attribute_index {
            0 => self.bmi,
            1 => self.age,
            2 => self.asa_status,
            3 => self.baseline_cancer,
            4 => self.baseline_charlson,
            5 => self.baseline_cvd,
            6 => self.baseline_dementia,
            7 => self.baseline_diabetes,
            8 => self.baseline_digestive,
            9 => self.baseline_osteoart,
            10 => self.baseline_psych,
            11 => self.baseline_pulmonary,
            12 => self.ahrq_ccs,
            13 => self.ccs_complication_rate,
            14 => self.ccs_mort30rate,
            15 => self.complication_rsi,
            16 => self.dow,
            17 => self.gender,
            18 => self.hour,
            19 => self.month,
            20 => self.moonphase,
            21 => self.mort30,
            22 => self.mortality_rsi,
            23 => self.race,

            //不能有label

            _ => panic!("Requested non-existing attribute {}!", attribute_index)
        }
    }

    fn true_label(&self) -> bool {
        self.label
    }
}

// ======================noshow=================================
pub struct NoshowDataset {
    pub num_records: u32,
    pub num_plus: u32,
}
#[derive(Eq,PartialEq,Debug,Clone)]
pub struct NoshowSample {

    pub age:u8,
    pub scheduled_day:u8,
    pub scheduled_month:u8,
    pub scheduled_year:u8,
    pub scheduled_hour:u8,
    pub appointment_day:u8,
    pub appointment_month:u8,
    pub appointment_year:u8,
    pub appointment_hour:u8,
    pub gender:u8,
    pub scholarship:u8,
    pub hypertension:u8,
    pub diabetes:u8,
    pub alcoholism:u8,
    pub handicap:u8,
    pub sms_received:u8,
    pub p1:u8,
    pub p2:u8,
    //超过50就溢出了 不行
    pub label: bool,
}

impl NoshowDataset {
    pub fn from_samples(samples: &Vec<NoshowSample>) -> NoshowDataset {
        let num_plus = samples.iter().filter(|sample| sample.true_label()).count();

        NoshowDataset {
            num_records: samples.len() as u32,
            num_plus: num_plus as u32,
        }
    }

    pub fn samples_from_csv(file: &str) -> Vec<NoshowSample> {
        let mut samples: Vec<NoshowSample> = Vec::new();

        let mut reader = csv::ReaderBuilder::new()
            .has_headers(true)
            .delimiter(b'\t')
            .from_path(file)
            .unwrap();

        for result in reader.records() {
            let record = result.unwrap();

            let age = u8::from_str(record.get(1).unwrap()).unwrap();
            let scheduled_day = u8::from_str(record.get(2).unwrap()).unwrap();
            let scheduled_month = u8::from_str(record.get(3).unwrap()).unwrap();
            let scheduled_year = u8::from_str(record.get(4).unwrap()).unwrap();
            let scheduled_hour = u8::from_str(record.get(5).unwrap()).unwrap();
            let appointment_day = u8::from_str(record.get(6).unwrap()).unwrap();
            let appointment_month = u8::from_str(record.get(7).unwrap()).unwrap();
            let appointment_year = u8::from_str(record.get(8).unwrap()).unwrap();
            let appointment_hour = u8::from_str(record.get(9).unwrap()).unwrap();
            let gender = u8::from_str(record.get(10).unwrap()).unwrap();
            let scholarship = u8::from_str(record.get(11).unwrap()).unwrap();
            let hypertension = u8::from_str(record.get(12).unwrap()).unwrap();
            let diabetes = u8::from_str(record.get(13).unwrap()).unwrap();
            let alcoholism = u8::from_str(record.get(14).unwrap()).unwrap();
            let handicap = u8::from_str(record.get(15).unwrap()).unwrap();
            let sms_received = u8::from_str(record.get(16).unwrap()).unwrap();
            let p1 = u8::from_str(record.get(17).unwrap()).unwrap();
            let p2 = u8::from_str(record.get(18).unwrap()).unwrap();

            let label = u8::from_str(record.get(19).unwrap()).unwrap() == 1;

            let sample = NoshowSample {
                age,
                scheduled_day,
                scheduled_month,
                scheduled_year,
                scheduled_hour,
                appointment_day,
                appointment_month,
                appointment_year,
                appointment_hour,
                gender,
                scholarship,
                hypertension,
                diabetes,
                alcoholism,
                handicap,
                sms_received,
                p1,
                p2,
                label
            };

            samples.push(sample);
        }

        samples
    }
}


impl Dataset for NoshowDataset {
    fn num_records(&self) -> u32 { self.num_records }

    fn num_plus(&self) -> u32 { self.num_plus }

    fn num_attributes(&self) -> u8 { 18 }

    fn attribute_range(&self, index: u8) -> (u8, u8) {
        match index {
                0 => (0, 15),
                1 => (0, 15),
                2 => (0, 3),
                3 => (0, 0),
                4 => (0, 10),
                5 => (0, 14),
                6 => (0, 1),
                7 => (0, 0),
                8 => (0, 0),

                9 => (0, 1),
                10 => (0, 1),
                11 => (0, 1),
                12 => (0, 1),
                13 => (0, 1),
                14 => (0, 4),
                15 => (0, 1),
                16 => (0, 63),
                17 => (0, 18),
            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }

    fn attribute_type(&self, index: u8) -> AttributeType {
        match index {

            0 => AttributeType::Numerical,
            1 => AttributeType::Numerical,
            2 => AttributeType::Numerical,
            3 => AttributeType::Numerical,
            4 => AttributeType::Numerical,
            5 => AttributeType::Numerical,
            6 => AttributeType::Numerical,
            7 => AttributeType::Numerical,
            8 => AttributeType::Numerical,

            9 => AttributeType::Categorical,
            10 => AttributeType::Categorical,
            11 => AttributeType::Categorical,
            12 => AttributeType::Categorical,
            13 => AttributeType::Categorical,
            14 => AttributeType::Categorical,
            15 => AttributeType::Categorical,
            16 => AttributeType::Categorical,
            17 => AttributeType::Categorical,
            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }
}

impl Sample for NoshowSample {

    fn attribute_value(&self, attribute_index: u8) -> u8 {

        match attribute_index {
            0 => self.age,
            1 => self.scheduled_day,
            2 => self.scheduled_month,
            3 => self.scheduled_year,
            4 => self.scheduled_hour,
            5 => self.appointment_day,
            6 => self.appointment_month,
            7 => self.appointment_year,
            8 => self.appointment_hour,
            9 => self.gender,
            10 => self.scholarship,
            11 => self.hypertension,
            12 => self.diabetes,
            13 => self.alcoholism,
            14 => self.handicap,
            15 => self.sms_received,
            16 => self.p1,
            17 => self.p2,
            //不能有label

            _ => panic!("Requested non-existing attribute {}!", attribute_index)
        }
    }

    fn true_label(&self) -> bool {
        self.label
    }
}

// ====================olympics===============================
pub struct OlympicsDataset {
    pub num_records: u32,
    pub num_plus: u32,
}
#[derive(Eq,PartialEq,Debug,Clone)]
pub struct OlympicsSample {

    pub age:u8,
    pub height: u8,
    pub weight: u8,
    pub sex: u8,
    pub noc: u8,
    pub games: u8,
    pub year: u8,
    pub season: u8,
    pub city: u8,
    pub sport: u8,
    pub event: u8,
    //超过50就溢出了 不行
    pub label: bool,
}

impl OlympicsDataset {
    pub fn from_samples(samples: &Vec<OlympicsSample>) -> OlympicsDataset {
        let num_plus = samples.iter().filter(|sample| sample.true_label()).count();

        OlympicsDataset {
            num_records: samples.len() as u32,
            num_plus: num_plus as u32,
        }
    }

    pub fn samples_from_csv(file: &str) -> Vec<OlympicsSample> {
        let mut samples: Vec<OlympicsSample> = Vec::new();

        let mut reader = csv::ReaderBuilder::new()
            .has_headers(true)
            .delimiter(b'\t')
            .from_path(file)
            .unwrap();

        for result in reader.records() {
            let record = result.unwrap();

            let age = u8::from_str(record.get(1).unwrap()).unwrap();
            let height = u8::from_str(record.get(2).unwrap()).unwrap();
            let weight = u8::from_str(record.get(3).unwrap()).unwrap();
            let sex = u8::from_str(record.get(4).unwrap()).unwrap();
            let noc = u8::from_str(record.get(5).unwrap()).unwrap();
            let games = u8::from_str(record.get(6).unwrap()).unwrap();
            let year = u8::from_str(record.get(7).unwrap()).unwrap();
            let season = u8::from_str(record.get(8).unwrap()).unwrap();
            let city = u8::from_str(record.get(9).unwrap()).unwrap();
            let sport = u8::from_str(record.get(10).unwrap()).unwrap();
            let event = u8::from_str(record.get(11).unwrap()).unwrap();

            let label = u8::from_str(record.get(12).unwrap()).unwrap() == 1;

            let sample = OlympicsSample {
                age,
                height,
                weight,
                sex,
                noc,
                games,
                year,
                season,
                city,
                sport,
                event,
                label
            };

            samples.push(sample);
        }

        samples
    }
}


impl Dataset for OlympicsDataset {
    fn num_records(&self) -> u32 { self.num_records }

    fn num_plus(&self) -> u32 { self.num_plus }

    fn num_attributes(&self) -> u8 { 11 }

    fn attribute_range(&self, index: u8) -> (u8, u8) {
        match index {
                0 => (0, 13),
                1 => (0, 15),
                2 => (0, 15),

                3 => (0, 1),
                4 => (0, 63),
                5 => (0, 50),
                6 => (0, 34),
                7 => (0, 1),
                8 => (0, 41),
                9 => (0, 55),
                10 => (0, 63),
            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }

    fn attribute_type(&self, index: u8) -> AttributeType {
        match index {

            0 => AttributeType::Numerical,
            1 => AttributeType::Numerical,
            2 => AttributeType::Numerical,

            3 => AttributeType::Categorical,
            4 => AttributeType::Categorical,
            5 => AttributeType::Categorical,
            6 => AttributeType::Categorical,
            7 => AttributeType::Categorical,
            8 => AttributeType::Categorical,
            9 => AttributeType::Categorical,
            10 => AttributeType::Categorical,

            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }
}

impl Sample for OlympicsSample {

    fn attribute_value(&self, attribute_index: u8) -> u8 {

        match attribute_index {
            0 => self.age,
            1 => self.height,
            2 => self.weight,
            3 => self.sex,
            4 => self.noc,
            5 => self.games,
            6 => self.year,
            7 => self.season,
            8 => self.city,
            9 => self.sport,
            10 => self.event,
            //不能有label

            _ => panic!("Requested non-existing attribute {}!", attribute_index)
        }
    }

    fn true_label(&self) -> bool {
        self.label
    }
}

// =================Diabetes=====================================
pub struct DiabetesDataset {
    pub num_records: u32,
    pub num_plus: u32,
}
#[derive(Eq,PartialEq,Debug,Clone)]
pub struct DiabetesSample {

    pub time_in_hospital: u8,
    pub num_lab_procedures: u8,
    pub num_medications: u8,
    pub number_outpatient: u8,
    pub number_emergency: u8,
    pub number_inpatient: u8,
    pub number_diagnoses: u8,

    pub race: u8,
    pub gender: u8,
    pub age: u8,
    pub admission_type_id: u8,
    pub discharge_disposition_id: u8,
    pub admission_source_id: u8,
    pub payer_code: u8,

    pub num_procedures: u8,
    pub max_glu_serum: u8,
    pub a1_cresult: u8,//-----------
    pub metformin: u8,
    pub repaglinide: u8,
    pub nateglinide: u8,
    pub chlorpropamide: u8,
    pub glimepiride: u8,
    pub acetohexamide: u8,
    pub glipizide: u8,
    pub glyburide: u8,
    pub tolbutamide: u8,
    pub pioglitazone: u8,
    pub rosiglitazone: u8,
    pub acarbose: u8,
    pub miglitol: u8,
    pub troglitazone: u8,
    pub tolazamide: u8,
    pub examide: u8,
    pub citoglipton: u8,
    pub insulin: u8,
    pub glyburide_metformin: u8,
    pub glipizide_metformin: u8,
    pub glimepiride_pioglitazone: u8,
    pub metformin_rosiglitazone: u8,
    pub metformin_pioglitazone: u8,
    pub change: u8,
    pub diabetes_med: u8,
    pub p1:u8,
    pub p2:u8,
    pub label: bool,
}

impl DiabetesDataset {
    pub fn from_samples(samples: &Vec<DiabetesSample>) -> DiabetesDataset {
        let num_plus = samples.iter().filter(|sample| sample.true_label()).count();

        DiabetesDataset {
            num_records: samples.len() as u32,
            num_plus: num_plus as u32,
        }
    }

    pub fn samples_from_csv(file: &str) -> Vec<DiabetesSample> {
        let mut samples: Vec<DiabetesSample> = Vec::new();

        let mut reader = csv::ReaderBuilder::new()
            .has_headers(true)
            .delimiter(b'\t')
            .from_path(file)
            .unwrap();

        for result in reader.records() {
            let record = result.unwrap();

            let time_in_hospital = u8::from_str(record.get(1).unwrap()).unwrap();
            let num_lab_procedures = u8::from_str(record.get(2).unwrap()).unwrap();
            let num_medications = u8::from_str(record.get(3).unwrap()).unwrap();
            let number_outpatient = u8::from_str(record.get(4).unwrap()).unwrap();
            let number_emergency = u8::from_str(record.get(5).unwrap()).unwrap();
            let number_inpatient = u8::from_str(record.get(6).unwrap()).unwrap();
            let number_diagnoses = u8::from_str(record.get(7).unwrap()).unwrap();

            let race = u8::from_str(record.get(8).unwrap()).unwrap();
            let gender = u8::from_str(record.get(9).unwrap()).unwrap();
            let age = u8::from_str(record.get(10).unwrap()).unwrap();
            let admission_type_id = u8::from_str(record.get(11).unwrap()).unwrap();
            let discharge_disposition_id = u8::from_str(record.get(12).unwrap()).unwrap();
            let admission_source_id = u8::from_str(record.get(13).unwrap()).unwrap();
            let payer_code = u8::from_str(record.get(14).unwrap()).unwrap();

            let num_procedures = u8::from_str(record.get(15).unwrap()).unwrap();
            let max_glu_serum = u8::from_str(record.get(16).unwrap()).unwrap();
            let a1_cresult = u8::from_str(record.get(17).unwrap()).unwrap();
            let metformin = u8::from_str(record.get(18).unwrap()).unwrap();
            let repaglinide = u8::from_str(record.get(19).unwrap()).unwrap();
            let nateglinide = u8::from_str(record.get(20).unwrap()).unwrap();
            let chlorpropamide = u8::from_str(record.get(21).unwrap()).unwrap();
            let glimepiride = u8::from_str(record.get(22).unwrap()).unwrap();
            let acetohexamide = u8::from_str(record.get(23).unwrap()).unwrap();
            let glipizide = u8::from_str(record.get(24).unwrap()).unwrap();
            let glyburide = u8::from_str(record.get(25).unwrap()).unwrap();
            let tolbutamide = u8::from_str(record.get(26).unwrap()).unwrap();
            let pioglitazone = u8::from_str(record.get(27).unwrap()).unwrap();
            let rosiglitazone = u8::from_str(record.get(28).unwrap()).unwrap();
            let acarbose = u8::from_str(record.get(29).unwrap()).unwrap();
            let miglitol = u8::from_str(record.get(30).unwrap()).unwrap();
            let troglitazone = u8::from_str(record.get(31).unwrap()).unwrap();
            let tolazamide = u8::from_str(record.get(32).unwrap()).unwrap();
            let examide = u8::from_str(record.get(33).unwrap()).unwrap();
            let citoglipton = u8::from_str(record.get(34).unwrap()).unwrap();
            let insulin = u8::from_str(record.get(35).unwrap()).unwrap();
            let glyburide_metformin = u8::from_str(record.get(36).unwrap()).unwrap();
            let glipizide_metformin = u8::from_str(record.get(37).unwrap()).unwrap();
            let glimepiride_pioglitazone = u8::from_str(record.get(38).unwrap()).unwrap();
            let metformin_rosiglitazone = u8::from_str(record.get(39).unwrap()).unwrap();
            let metformin_pioglitazone = u8::from_str(record.get(40).unwrap()).unwrap();
            let change = u8::from_str(record.get(41).unwrap()).unwrap();
            let diabetes_med = u8::from_str(record.get(42).unwrap()).unwrap();
            let p1 = u8::from_str(record.get(43).unwrap()).unwrap();
            let p2 = u8::from_str(record.get(44).unwrap()).unwrap();

            let label = u8::from_str(record.get(45).unwrap()).unwrap() == 1;

            let sample = DiabetesSample {
                time_in_hospital,
                num_lab_procedures,
                num_medications,
                number_outpatient,
                number_emergency,
                number_inpatient,
                number_diagnoses,

                race,
                gender,
                age,
                admission_type_id,
                discharge_disposition_id,
                admission_source_id,
                payer_code,
                num_procedures,
                max_glu_serum,
                a1_cresult,
                metformin,
                repaglinide,
                nateglinide,
                chlorpropamide,
                glimepiride,
                acetohexamide,
                glipizide,
                glyburide,
                tolbutamide,
                pioglitazone,
                rosiglitazone,
                acarbose,
                miglitol,
                troglitazone,
                tolazamide,
                examide,
                citoglipton,
                insulin,
                glyburide_metformin,
                glipizide_metformin,
                glimepiride_pioglitazone,
                metformin_rosiglitazone,
                metformin_pioglitazone,
                change,
                diabetes_med,
                p1,
                p2,

                label
            };

            samples.push(sample);
        }

        samples
    }
}


impl Dataset for DiabetesDataset {
    fn num_records(&self) -> u32 { self.num_records }

    fn num_plus(&self) -> u32 { self.num_plus }

    fn num_attributes(&self) -> u8 { 44 }

    fn attribute_range(&self, index: u8) -> (u8, u8) {
        match index {
            0 => (0, 8),
            1 => (0, 15),
            2 => (0, 15),
            3 => (0, 2),
            4 => (0, 1),
            5 => (0, 3),
            6 => (0, 6),

            7 => (0, 5),
            8 => (0, 2),
            9 => (0, 9),
            10 => (0, 7),
            11 => (0, 25),
            12 => (0, 16),
            13 => (0, 17),
            14 => (0, 6),
            15 => (0, 3),
            16 => (0, 3),
            17 => (0, 3),
            18 => (0, 3),
            19 => (0, 3),
            20 => (0, 3),
            21 => (0, 3),
            22 => (0, 1),
            23 => (0, 3),
            24 => (0, 3),
            25 => (0, 1),
            26 => (0, 3),
            27 => (0, 3),
            28 => (0, 3),
            29 => (0, 3),
            30 => (0, 1),
            31 => (0, 2),
            32 => (0, 0),
            33 => (0, 0),
            34 => (0, 3),
            35 => (0, 3),
            36 => (0, 1),
            37 => (0, 1),
            38 => (0, 1),
            39 => (0, 1),
            40 => (0, 1),
            41 => (0, 1),
            42 => (0,63),
            43 => (0,10),

            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }

    fn attribute_type(&self, index: u8) -> AttributeType {
        match index {

            0 => AttributeType::Numerical,
            1 => AttributeType::Numerical,
            2 => AttributeType::Numerical,
            3 => AttributeType::Numerical,
            4 => AttributeType::Numerical,
            5 => AttributeType::Numerical,
            6 => AttributeType::Numerical,

            7 => AttributeType::Categorical,
            8 => AttributeType::Categorical,
            9 => AttributeType::Categorical,
            10 => AttributeType::Categorical,
            11 => AttributeType::Categorical,
            12 => AttributeType::Categorical,
            13 => AttributeType::Categorical,
            14 => AttributeType::Categorical,
            15 => AttributeType::Categorical,
            16 => AttributeType::Categorical,
            17 => AttributeType::Categorical,
            18 => AttributeType::Categorical,
            19 => AttributeType::Categorical,
            20 => AttributeType::Categorical,
            21 => AttributeType::Categorical,
            22 => AttributeType::Categorical,
            23 => AttributeType::Categorical,
            24 => AttributeType::Categorical,
            25 => AttributeType::Categorical,
            26 => AttributeType::Categorical,
            27 => AttributeType::Categorical,
            28 => AttributeType::Categorical,
            29 => AttributeType::Categorical,
            30 => AttributeType::Categorical,
            31 => AttributeType::Categorical,
            32 => AttributeType::Categorical,
            33 => AttributeType::Categorical,
            34 => AttributeType::Categorical,
            35 => AttributeType::Categorical,
            36 => AttributeType::Categorical,
            37 => AttributeType::Categorical,
            38 => AttributeType::Categorical,
            39 => AttributeType::Categorical,
            40 => AttributeType::Categorical,
            41 => AttributeType::Categorical,
            42 => AttributeType::Categorical,
            43 => AttributeType::Categorical,

            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }
}

impl Sample for DiabetesSample {

    fn attribute_value(&self, attribute_index: u8) -> u8 {

        match attribute_index {
            0 => self.time_in_hospital,
            1 => self.num_lab_procedures,
            2 => self.num_medications,
            3 => self.number_outpatient,
            4 => self.number_emergency,
            5 => self.number_inpatient,
            6 => self.number_diagnoses,
            7 => self.race,
            8 => self.gender,
            9 => self.age,
            10 => self.admission_type_id,
            11 => self.discharge_disposition_id,
            12 => self.admission_source_id,
            13 => self.payer_code,

            14 => self.num_procedures,
            15 => self.max_glu_serum,
            16 => self.a1_cresult,
            17 => self.metformin,
            18 => self.repaglinide,
            19 => self.nateglinide,
            20 => self.chlorpropamide,
            21 => self.glimepiride,
            22 => self.acetohexamide,
            23 => self.glipizide,
            24 => self.glyburide,
            25 => self.tolbutamide,
            26 => self.pioglitazone,
            27 => self.rosiglitazone,
            28 => self.acarbose,
            29 => self.miglitol,
            30 => self.troglitazone,
            31 => self.tolazamide,
            32 => self.examide,
            33 => self.citoglipton,
            34 => self.insulin,
            35 => self.glyburide_metformin,
            36 => self.glipizide_metformin,
            37 => self.glimepiride_pioglitazone,
            38 => self.metformin_rosiglitazone,
            39 => self.metformin_pioglitazone,
            40 => self.change,
            41 => self.diabetes_med,
            42 => self.p1,
            43 => self.p2,

            //不能有label

            _ => panic!("Requested non-existing attribute {}!", attribute_index)
        }
    }

    fn true_label(&self) -> bool {
        self.label
    }
}

// ===================credit========================================
pub struct CreditDataset {
    pub num_records: u32,
    pub num_plus: u32,
}
#[derive(Eq,PartialEq,Debug,Clone)]
pub struct CreditSample {

    pub p1: u8,
    pub p2: u8,
    pub p3: u8,
    pub p4: u8,
    pub p5: u8,
    pub p6: u8,
    pub p7: u8,
    pub p8: u8,
    pub p9: u8,
    pub p10: u8,
    pub p11: u8,
    pub p12: u8,
    pub p13: u8,
    pub p14: u8,
    pub p15: u8,
    pub p16: u8,
    pub p17: u8,
    pub p18: u8,
    pub p19: u8,
    pub p20: u8,
    pub p21: u8,
    pub p22: u8,
    pub p23: u8,
    pub p24: u8,
    pub p25: u8,
    pub p26: u8,
    pub p27: u8,
    pub p28: u8,
    pub p29: u8,

    pub label: bool,
}

impl CreditDataset {
    pub fn from_samples(samples: &Vec<CreditSample>) -> CreditDataset {
        let num_plus = samples.iter().filter(|sample| sample.true_label()).count();

        CreditDataset {
            num_records: samples.len() as u32,
            num_plus: num_plus as u32,
        }
    }

    pub fn samples_from_csv(file: &str) -> Vec<CreditSample> {
        let mut samples: Vec<CreditSample> = Vec::new();

        let mut reader = csv::ReaderBuilder::new()
            .has_headers(true)
            .delimiter(b'\t')
            .from_path(file)
            .unwrap();

        for result in reader.records() {
            let record = result.unwrap();

            let p1 = u8::from_str(record.get(1).unwrap()).unwrap();
            let p2 = u8::from_str(record.get(2).unwrap()).unwrap();
            let p3 = u8::from_str(record.get(3).unwrap()).unwrap();
            let p4 = u8::from_str(record.get(4).unwrap()).unwrap();
            let p5 = u8::from_str(record.get(5).unwrap()).unwrap();
            let p6 = u8::from_str(record.get(6).unwrap()).unwrap();
            let p7 = u8::from_str(record.get(7).unwrap()).unwrap();
            let p8 = u8::from_str(record.get(8).unwrap()).unwrap();
            let p9 = u8::from_str(record.get(9).unwrap()).unwrap();
            let p10 = u8::from_str(record.get(10).unwrap()).unwrap();
            let p11 = u8::from_str(record.get(11).unwrap()).unwrap();
            let p12 = u8::from_str(record.get(12).unwrap()).unwrap();
            let p13 = u8::from_str(record.get(13).unwrap()).unwrap();
            let p14 = u8::from_str(record.get(14).unwrap()).unwrap();
            let p15 = u8::from_str(record.get(15).unwrap()).unwrap();
            let p16 = u8::from_str(record.get(16).unwrap()).unwrap();
            let p17 = u8::from_str(record.get(17).unwrap()).unwrap();
            let p18 = u8::from_str(record.get(18).unwrap()).unwrap();
            let p19 = u8::from_str(record.get(19).unwrap()).unwrap();
            let p20 = u8::from_str(record.get(20).unwrap()).unwrap();
            let p21 = u8::from_str(record.get(21).unwrap()).unwrap();
            let p22 = u8::from_str(record.get(22).unwrap()).unwrap();
            let p23 = u8::from_str(record.get(23).unwrap()).unwrap();
            let p24 = u8::from_str(record.get(24).unwrap()).unwrap();
            let p25 = u8::from_str(record.get(25).unwrap()).unwrap();
            let p26 = u8::from_str(record.get(26).unwrap()).unwrap();
            let p27 = u8::from_str(record.get(27).unwrap()).unwrap();
            let p28 = u8::from_str(record.get(28).unwrap()).unwrap();
            let p29 = u8::from_str(record.get(29).unwrap()).unwrap();

            let label = u8::from_str(record.get(30).unwrap()).unwrap() == 1;

            let sample = CreditSample {
                p1,
                p2,
                p3,
                p4,
                p5,
                p6,
                p7,
                p8,
                p9,
                p10,
                p11,
                p12,
                p13,
                p14,
                p15,
                p16,
                p17,
                p18,
                p19,
                p20,
                p21,
                p22,
                p23,
                p24,
                p25,
                p26,
                p27,
                p28,
                p29,

                label
            };

            samples.push(sample);
        }

        samples
    }
}


impl Dataset for CreditDataset {
    fn num_records(&self) -> u32 { self.num_records }

    fn num_plus(&self) -> u32 { self.num_plus }

    fn num_attributes(&self) -> u8 { 29 }

    fn attribute_range(&self, index: u8) -> (u8, u8) {
        match index {
            0 => (0, 15),
            1 => (0, 15),
            2 => (0, 15),
            3 => (0, 15),
            4 => (0, 15),
            5 => (0, 15),
            6 => (0, 15),
            7 => (0, 15),
            8 => (0, 15),
            9 => (0, 15),
            10 => (0, 15),
            11 => (0, 15),
            12 => (0, 15),
            13 => (0, 15),
            14 => (0, 15),
            15 => (0, 15),
            16 => (0, 15),
            17 => (0, 15),
            18 => (0, 15),
            19 => (0, 15),
            20 => (0, 15),
            21 => (0, 15),
            22 => (0, 15),
            23 => (0, 15),
            24 => (0, 15),
            25 => (0, 15),
            26 => (0, 15),
            27 => (0, 15),
            28 => (0, 15),

            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }

    fn attribute_type(&self, index: u8) -> AttributeType {
        match index {

            0 => AttributeType::Numerical,
            1 => AttributeType::Numerical,
            2 => AttributeType::Numerical,
            3 => AttributeType::Numerical,
            4 => AttributeType::Numerical,
            5 => AttributeType::Numerical,
            6 => AttributeType::Numerical,
            7 => AttributeType::Numerical,
            8 => AttributeType::Numerical,
            9 => AttributeType::Numerical,
            10 => AttributeType::Numerical,
            11 => AttributeType::Numerical,
            12 => AttributeType::Numerical,
            13 => AttributeType::Numerical,
            14 => AttributeType::Numerical,
            15 => AttributeType::Numerical,
            16 => AttributeType::Numerical,
            17 => AttributeType::Numerical,
            18 => AttributeType::Numerical,
            19 => AttributeType::Numerical,
            20 => AttributeType::Numerical,
            21 => AttributeType::Numerical,
            22 => AttributeType::Numerical,
            23 => AttributeType::Numerical,
            24 => AttributeType::Numerical,
            25 => AttributeType::Numerical,
            26 => AttributeType::Numerical,
            27 => AttributeType::Numerical,
            28 => AttributeType::Numerical,

            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }
}

impl Sample for CreditSample {

    fn attribute_value(&self, attribute_index: u8) -> u8 {

        match attribute_index {
            0 => self.p1,
            1 => self.p2,
            2 => self.p3,
            3 => self.p4,
            4 => self.p5,
            5 => self.p6,
            6 => self.p7,
            7 => self.p8,
            8 => self.p9,
            9 => self.p10,
            10 => self.p11,
            11 => self.p12,
            12 => self.p13,
            13 => self.p14,
            14 => self.p15,
            15 => self.p16,
            16 => self.p17,
            17 => self.p18,
            18 => self.p19,
            19 => self.p20,
            20 => self.p21,
            21 => self.p22,
            22 => self.p23,
            23 => self.p24,
            24 => self.p25,
            25 => self.p26,
            26 => self.p27,
            27 => self.p28,
            28 => self.p29,
            _ => panic!("Requested non-existing attribute {}!", attribute_index)
        }
    }

    fn true_label(&self) -> bool {
        self.label
    }
}

// =====================ctr=========================================
pub struct CtrDataset {
    pub num_records: u32,
    pub num_plus: u32,
}
#[derive(Eq,PartialEq,Debug,Clone)]
pub struct CtrSample {

    pub p1: u8,
    pub p2: u8,
    pub p3: u8,
    pub p4: u8,
    pub p5: u8,
    pub p6: u8,
    pub p7: u8,
    pub p8: u8,
    pub p9: u8,
    pub p10: u8,
    pub p11: u8,
    pub p12: u8,
    pub p13: u8,

    pub label: bool,
}

impl CtrDataset {
    pub fn from_samples(samples: &Vec<CtrSample>) -> CtrDataset {
        let num_plus = samples.iter().filter(|sample| sample.true_label()).count();

        CtrDataset {
            num_records: samples.len() as u32,
            num_plus: num_plus as u32,
        }
    }

    pub fn samples_from_csv(file: &str) -> Vec<CtrSample> {
        let mut samples: Vec<CtrSample> = Vec::new();

        let mut reader = csv::ReaderBuilder::new()
            .has_headers(true)
            .delimiter(b'\t')
            .from_path(file)
            .unwrap();

        for result in reader.records() {
            let record = result.unwrap();

            let p1 = u8::from_str(record.get(1).unwrap()).unwrap();
            let p2 = u8::from_str(record.get(2).unwrap()).unwrap();
            let p3 = u8::from_str(record.get(3).unwrap()).unwrap();
            let p4 = u8::from_str(record.get(4).unwrap()).unwrap();
            let p5 = u8::from_str(record.get(5).unwrap()).unwrap();
            let p6 = u8::from_str(record.get(6).unwrap()).unwrap();
            let p7 = u8::from_str(record.get(7).unwrap()).unwrap();
            let p8 = u8::from_str(record.get(8).unwrap()).unwrap();
            let p9 = u8::from_str(record.get(9).unwrap()).unwrap();
            let p10 = u8::from_str(record.get(10).unwrap()).unwrap();
            let p11 = u8::from_str(record.get(11).unwrap()).unwrap();
            let p12 = u8::from_str(record.get(12).unwrap()).unwrap();
            let p13 = u8::from_str(record.get(13).unwrap()).unwrap();

            let label = u8::from_str(record.get(14).unwrap()).unwrap() == 1;

            let sample = CtrSample {
                p1,
                p2,
                p3,
                p4,
                p5,
                p6,
                p7,
                p8,
                p9,
                p10,
                p11,
                p12,
                p13,

                label
            };

            samples.push(sample);
        }

        samples
    }
}


impl Dataset for CtrDataset {
    fn num_records(&self) -> u32 { self.num_records }

    fn num_plus(&self) -> u32 { self.num_plus }

    fn num_attributes(&self) -> u8 { 13 }

    fn attribute_range(&self, index: u8) -> (u8, u8) {
        match index {
            0 => (0, 10),
            1 => (0, 15),
            2 => (0, 10),
            3 => (0, 9),
            4 => (0, 8),
            5 => (0, 3),
            6 => (0, 1),
            7 => (0, 12),
            8 => (0, 11),
            9 => (0, 2),
            10 => (0, 6),
            11 => (0, 15),
            12 => (0, 10),


            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }

    fn attribute_type(&self, index: u8) -> AttributeType {
        match index {

            0 => AttributeType::Numerical,
            1 => AttributeType::Numerical,
            2 => AttributeType::Numerical,
            3 => AttributeType::Numerical,
            4 => AttributeType::Numerical,
            5 => AttributeType::Numerical,
            6 => AttributeType::Numerical,
            7 => AttributeType::Numerical,
            8 => AttributeType::Numerical,
            9 => AttributeType::Numerical,
            10 => AttributeType::Numerical,
            11 => AttributeType::Numerical,
            12 => AttributeType::Numerical,

            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }
}

impl Sample for CtrSample {

    fn attribute_value(&self, attribute_index: u8) -> u8 {

        match attribute_index {
            0 => self.p1,
            1 => self.p2,
            2 => self.p3,
            3 => self.p4,
            4 => self.p5,
            5 => self.p6,
            6 => self.p7,
            7 => self.p8,
            8 => self.p9,
            9 => self.p10,
            10 => self.p11,
            11 => self.p12,
            12 => self.p13,
            _ => panic!("Requested non-existing attribute {}!", attribute_index)
        }
    }

    fn true_label(&self) -> bool {
        self.label
    }
}

// ====================synthetic========================================
pub struct SyntheticDataset {
    pub num_records: u32,
    pub num_plus: u32,
}
#[derive(Eq,PartialEq,Debug,Clone)]
pub struct SyntheticSample {

    pub p1: u8,
    pub p2: u8,
    pub p3: u8,
    pub p4: u8,
    pub p5: u8,
    pub p6: u8,
    pub p7: u8,
    pub p8: u8,
    pub p9: u8,
    pub p10: u8,
    pub p11: u8,
    pub p12: u8,
    pub p13: u8,
    pub p14: u8,
    pub p15: u8,
    pub p16: u8,
    pub p17: u8,
    pub p18: u8,
    pub p19: u8,
    pub p20: u8,
    pub p21: u8,
    pub p22: u8,
    pub p23: u8,
    pub p24: u8,
    pub p25: u8,
    pub p26: u8,
    pub p27: u8,
    pub p28: u8,
    pub p29: u8,
    pub p30: u8,
    pub p31: u8,
    pub p32: u8,
    pub p33: u8,
    pub p34: u8,
    pub p35: u8,
    pub p36: u8,
    pub p37: u8,
    pub p38: u8,
    pub p39: u8,
    pub p40: u8,

    pub label: bool,
}

impl SyntheticDataset {
    pub fn from_samples(samples: &Vec<SyntheticSample>) -> SyntheticDataset {
        let num_plus = samples.iter().filter(|sample| sample.true_label()).count();

        SyntheticDataset {
            num_records: samples.len() as u32,
            num_plus: num_plus as u32,
        }
    }

    pub fn samples_from_csv(file: &str) -> Vec<SyntheticSample> {
        let mut samples: Vec<SyntheticSample> = Vec::new();

        let mut reader = csv::ReaderBuilder::new()
            .has_headers(true)
            .delimiter(b'\t')
            .from_path(file)
            .unwrap();

        for result in reader.records() {
            let record = result.unwrap();

            let p1 = u8::from_str(record.get(1).unwrap()).unwrap();
            let p2 = u8::from_str(record.get(2).unwrap()).unwrap();
            let p3 = u8::from_str(record.get(3).unwrap()).unwrap();
            let p4 = u8::from_str(record.get(4).unwrap()).unwrap();
            let p5 = u8::from_str(record.get(5).unwrap()).unwrap();
            let p6 = u8::from_str(record.get(6).unwrap()).unwrap();
            let p7 = u8::from_str(record.get(7).unwrap()).unwrap();
            let p8 = u8::from_str(record.get(8).unwrap()).unwrap();
            let p9 = u8::from_str(record.get(9).unwrap()).unwrap();
            let p10 = u8::from_str(record.get(10).unwrap()).unwrap();
            let p11 = u8::from_str(record.get(11).unwrap()).unwrap();
            let p12 = u8::from_str(record.get(12).unwrap()).unwrap();
            let p13 = u8::from_str(record.get(13).unwrap()).unwrap();
            let p14 = u8::from_str(record.get(14).unwrap()).unwrap();
            let p15 = u8::from_str(record.get(15).unwrap()).unwrap();
            let p16 = u8::from_str(record.get(16).unwrap()).unwrap();
            let p17 = u8::from_str(record.get(17).unwrap()).unwrap();
            let p18 = u8::from_str(record.get(18).unwrap()).unwrap();
            let p19 = u8::from_str(record.get(19).unwrap()).unwrap();
            let p20 = u8::from_str(record.get(20).unwrap()).unwrap();
            let p21 = u8::from_str(record.get(21).unwrap()).unwrap();
            let p22 = u8::from_str(record.get(22).unwrap()).unwrap();
            let p23 = u8::from_str(record.get(23).unwrap()).unwrap();
            let p24 = u8::from_str(record.get(24).unwrap()).unwrap();
            let p25 = u8::from_str(record.get(25).unwrap()).unwrap();
            let p26 = u8::from_str(record.get(26).unwrap()).unwrap();
            let p27 = u8::from_str(record.get(27).unwrap()).unwrap();
            let p28 = u8::from_str(record.get(28).unwrap()).unwrap();
            let p29 = u8::from_str(record.get(29).unwrap()).unwrap();
            let p30 = u8::from_str(record.get(30).unwrap()).unwrap();
            let p31 = u8::from_str(record.get(31).unwrap()).unwrap();
            let p32 = u8::from_str(record.get(32).unwrap()).unwrap();
            let p33 = u8::from_str(record.get(33).unwrap()).unwrap();
            let p34 = u8::from_str(record.get(34).unwrap()).unwrap();
            let p35 = u8::from_str(record.get(35).unwrap()).unwrap();
            let p36 = u8::from_str(record.get(36).unwrap()).unwrap();
            let p37 = u8::from_str(record.get(37).unwrap()).unwrap();
            let p38 = u8::from_str(record.get(38).unwrap()).unwrap();
            let p39 = u8::from_str(record.get(39).unwrap()).unwrap();
            let p40 = u8::from_str(record.get(40).unwrap()).unwrap();


            let label = u8::from_str(record.get(41).unwrap()).unwrap() == 1;

            let sample = SyntheticSample {
                p1,
                p2,
                p3,
                p4,
                p5,
                p6,
                p7,
                p8,
                p9,
                p10,
                p11,
                p12,
                p13,
                p14,
                p15,
                p16,
                p17,
                p18,
                p19,
                p20,
                p21,
                p22,
                p23,
                p24,
                p25,
                p26,
                p27,
                p28,
                p29,

                p30,
                p31,
                p32,
                p33,
                p34,
                p35,
                p36,
                p37,
                p38,
                p39,
                p40,
                label
            };

            samples.push(sample);
        }

        samples
    }
}


impl Dataset for SyntheticDataset {
    fn num_records(&self) -> u32 { self.num_records }

    fn num_plus(&self) -> u32 { self.num_plus }

    fn num_attributes(&self) -> u8 { 40 }

    fn attribute_range(&self, index: u8) -> (u8, u8) {
        match index {
            0 => (0, 15),
            1 => (0, 15),
            2 => (0, 15),
            3 => (0, 15),
            4 => (0, 15),
            5 => (0, 15),
            6 => (0, 15),
            7 => (0, 15),
            8 => (0, 15),
            9 => (0, 15),
            10 => (0, 15),
            11 => (0, 15),
            12 => (0, 15),
            13 => (0, 15),
            14 => (0, 15),
            15 => (0, 15),
            16 => (0, 15),
            17 => (0, 15),
            18 => (0, 15),
            19 => (0, 15),
            20 => (0, 15),
            21 => (0, 15),
            22 => (0, 15),
            23 => (0, 15),
            24 => (0, 15),
            25 => (0, 15),
            26 => (0, 15),
            27 => (0, 15),
            28 => (0, 15),
            29 => (0, 15),
            30 => (0, 15),
            31 => (0, 15),
            32 => (0, 15),
            33 => (0, 15),
            34 => (0, 15),
            35 => (0, 15),
            36 => (0, 15),
            37 => (0, 15),
            38 => (0, 15),
            39 => (0, 15),

            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }

    fn attribute_type(&self, index: u8) -> AttributeType {
        match index {

            0 => AttributeType::Numerical,
            1 => AttributeType::Numerical,
            2 => AttributeType::Numerical,
            3 => AttributeType::Numerical,
            4 => AttributeType::Numerical,
            5 => AttributeType::Numerical,
            6 => AttributeType::Numerical,
            7 => AttributeType::Numerical,
            8 => AttributeType::Numerical,
            9 => AttributeType::Numerical,
            10 => AttributeType::Numerical,
            11 => AttributeType::Numerical,
            12 => AttributeType::Numerical,
            13 => AttributeType::Numerical,
            14 => AttributeType::Numerical,
            15 => AttributeType::Numerical,
            16 => AttributeType::Numerical,
            17 => AttributeType::Numerical,
            18 => AttributeType::Numerical,
            19 => AttributeType::Numerical,
            20 => AttributeType::Numerical,
            21 => AttributeType::Numerical,
            22 => AttributeType::Numerical,
            23 => AttributeType::Numerical,
            24 => AttributeType::Numerical,
            25 => AttributeType::Numerical,
            26 => AttributeType::Numerical,
            27 => AttributeType::Numerical,
            28 => AttributeType::Numerical,
            29 => AttributeType::Numerical,
            30 => AttributeType::Numerical,
            31 => AttributeType::Numerical,
            32 => AttributeType::Numerical,
            33 => AttributeType::Numerical,
            34 => AttributeType::Numerical,
            35 => AttributeType::Numerical,
            36 => AttributeType::Numerical,
            37 => AttributeType::Numerical,
            38 => AttributeType::Numerical,
            39 => AttributeType::Numerical,
            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }
}

impl Sample for SyntheticSample {

    fn attribute_value(&self, attribute_index: u8) -> u8 {

        match attribute_index {
            0 => self.p1,
            1 => self.p2,
            2 => self.p3,
            3 => self.p4,
            4 => self.p5,
            5 => self.p6,
            6 => self.p7,
            7 => self.p8,
            8 => self.p9,
            9 => self.p10,
            10 => self.p11,
            11 => self.p12,
            12 => self.p13,
            13 => self.p14,
            14 => self.p15,
            15 => self.p16,
            16 => self.p17,
            17 => self.p18,
            18 => self.p19,
            19 => self.p20,
            20 => self.p21,
            21 => self.p22,
            22 => self.p23,
            23 => self.p24,
            24 => self.p25,
            25 => self.p26,
            26 => self.p27,
            27 => self.p28,
            28 => self.p29,
            29 => self.p30,
            30 => self.p31,
            31 => self.p32,
            32 => self.p33,
            33 => self.p34,
            34 => self.p35,
            35 => self.p36,
            36 => self.p37,
            37 => self.p38,
            38 => self.p39,
            39 => self.p40,
            _ => panic!("Requested non-existing attribute {}!", attribute_index)
        }
    }

    fn true_label(&self) -> bool {
        self.label
    }
}

// =================Census=====================================
pub struct CensusDataset {
    pub num_records: u32,
    pub num_plus: u32,
}
#[derive(Eq,PartialEq,Debug,Clone)]
pub struct CensusSample {

    pub p1: u8,
    pub p2: u8,
    pub p3: u8,
    pub p4: u8,
    pub p5: u8,
    pub p6: u8,

    pub p7: u8,
    pub p8: u8,
    pub p9: u8,
    pub p10: u8,
    pub p11: u8,
    pub p12: u8,
    pub p13: u8,
    pub p14: u8,
    pub p15: u8,
    pub p16: u8,
    pub p17: u8,
    pub p18: u8,
    pub p19: u8,
    pub p20: u8,
    pub p21: u8,
    pub p22: u8,
    pub p23: u8,
    pub p24: u8,
    pub p25: u8,
    pub p26: u8,
    pub p27: u8,
    pub p28: u8,
    pub p29: u8,
    pub p30: u8,
    pub p31: u8,
    pub p32: u8,
    pub p33: u8,
    pub p34: u8,
    pub p35: u8,
    pub p36: u8,

    pub label: bool,
}

impl CensusDataset {
    pub fn from_samples(samples: &Vec<CensusSample>) -> CensusDataset {
        let num_plus = samples.iter().filter(|sample| sample.true_label()).count();

        CensusDataset {
            num_records: samples.len() as u32,
            num_plus: num_plus as u32,
        }
    }

    pub fn samples_from_csv(file: &str) -> Vec<CensusSample> {
        let mut samples: Vec<CensusSample> = Vec::new();

        let mut reader = csv::ReaderBuilder::new()
            .has_headers(true)
            .delimiter(b'\t')
            .from_path(file)
            .unwrap();

        for result in reader.records() {
            let record = result.unwrap();

            let p1 = u8::from_str(record.get(1).unwrap()).unwrap();
            let p2 = u8::from_str(record.get(2).unwrap()).unwrap();
            let p3 = u8::from_str(record.get(3).unwrap()).unwrap();
            let p4 = u8::from_str(record.get(4).unwrap()).unwrap();
            let p5 = u8::from_str(record.get(5).unwrap()).unwrap();
            let p6 = u8::from_str(record.get(6).unwrap()).unwrap();
            let p7 = u8::from_str(record.get(7).unwrap()).unwrap();
            let p8 = u8::from_str(record.get(8).unwrap()).unwrap();
            let p9 = u8::from_str(record.get(9).unwrap()).unwrap();
            let p10 = u8::from_str(record.get(10).unwrap()).unwrap();
            let p11 = u8::from_str(record.get(11).unwrap()).unwrap();
            let p12 = u8::from_str(record.get(12).unwrap()).unwrap();
            let p13 = u8::from_str(record.get(13).unwrap()).unwrap();
            let p14 = u8::from_str(record.get(14).unwrap()).unwrap();
            let p15 = u8::from_str(record.get(15).unwrap()).unwrap();
            let p16 = u8::from_str(record.get(16).unwrap()).unwrap();
            let p17 = u8::from_str(record.get(17).unwrap()).unwrap();
            let p18 = u8::from_str(record.get(18).unwrap()).unwrap();
            let p19 = u8::from_str(record.get(19).unwrap()).unwrap();
            let p20 = u8::from_str(record.get(20).unwrap()).unwrap();
            let p21 = u8::from_str(record.get(21).unwrap()).unwrap();
            let p22 = u8::from_str(record.get(22).unwrap()).unwrap();
            let p23 = u8::from_str(record.get(23).unwrap()).unwrap();
            let p24 = u8::from_str(record.get(24).unwrap()).unwrap();
            let p25 = u8::from_str(record.get(25).unwrap()).unwrap();
            let p26 = u8::from_str(record.get(26).unwrap()).unwrap();
            let p27 = u8::from_str(record.get(27).unwrap()).unwrap();
            let p28 = u8::from_str(record.get(28).unwrap()).unwrap();
            let p29 = u8::from_str(record.get(29).unwrap()).unwrap();
            let p30 = u8::from_str(record.get(30).unwrap()).unwrap();
            let p31 = u8::from_str(record.get(31).unwrap()).unwrap();
            let p32 = u8::from_str(record.get(32).unwrap()).unwrap();
            let p33 = u8::from_str(record.get(33).unwrap()).unwrap();
            let p34 = u8::from_str(record.get(34).unwrap()).unwrap();
            let p35 = u8::from_str(record.get(35).unwrap()).unwrap();
            let p36 = u8::from_str(record.get(36).unwrap()).unwrap();

            let label = u8::from_str(record.get(37).unwrap()).unwrap() == 1;

            let sample = CensusSample {
                p1,
                p2,
                p3,
                p4,
                p5,
                p6,
                p7,
                p8,
                p9,
                p10,
                p11,
                p12,
                p13,
                p14,
                p15,
                p16,
                p17,
                p18,
                p19,
                p20,
                p21,
                p22,
                p23,
                p24,
                p25,
                p26,
                p27,
                p28,
                p29,
                p30,
                p31,
                p32,
                p33,
                p34,
                p35,
                p36,
                label
            };

            samples.push(sample);
        }

        samples
    }
}


impl Dataset for CensusDataset {
    fn num_records(&self) -> u32 { self.num_records }

    fn num_plus(&self) -> u32 { self.num_plus }

    fn num_attributes(&self) -> u8 { 36 }

    fn attribute_range(&self, index: u8) -> (u8, u8) {
        match index {
            0 => (0, 15),
            1 => (0, 0),
            2 => (0, 0),
            3 => (0, 0),
            4 => (0, 1),
            5 => (0, 15),

            6 => (0, 8),
            7 => (0, 16),
            8 => (0, 2),
            9 => (0, 6),
            10 => (0, 23),
            11 => (0, 14),
            12 => (0, 4),
            13 => (0, 9),
            14 => (0, 1),
            15 => (0, 2),
            16 => (0, 5),
            17 => (0, 7),
            18 => (0, 5),
            19 => (0, 5),
            20 => (0, 50),
            21 => (0, 37),
            22 => (0, 7),
            23 => (0, 9),
            24 => (0, 8),
            25 => (0, 9),
            26 => (0, 2),
            27 => (0, 3),
            28 => (0, 4),
            29 => (0, 42),
            30 => (0, 42),
            31 => (0, 42),
            32 => (0, 4),
            33 => (0, 2),
            34 => (0, 2),
            35 => (0, 2),

            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }

    fn attribute_type(&self, index: u8) -> AttributeType {
        match index {

            0 => AttributeType::Numerical,
            1 => AttributeType::Numerical,
            2 => AttributeType::Numerical,
            3 => AttributeType::Numerical,
            4 => AttributeType::Numerical,
            5 => AttributeType::Numerical,

            6 => AttributeType::Categorical,
            7 => AttributeType::Categorical,
            8 => AttributeType::Categorical,
            9 => AttributeType::Categorical,
            10 => AttributeType::Categorical,
            11 => AttributeType::Categorical,
            12 => AttributeType::Categorical,
            13 => AttributeType::Categorical,
            14 => AttributeType::Categorical,
            15 => AttributeType::Categorical,
            16 => AttributeType::Categorical,
            17 => AttributeType::Categorical,
            18 => AttributeType::Categorical,
            19 => AttributeType::Categorical,
            20 => AttributeType::Categorical,
            21 => AttributeType::Categorical,
            22 => AttributeType::Categorical,
            23 => AttributeType::Categorical,
            24 => AttributeType::Categorical,
            25 => AttributeType::Categorical,
            26 => AttributeType::Categorical,
            27 => AttributeType::Categorical,
            28 => AttributeType::Categorical,
            29 => AttributeType::Categorical,
            30 => AttributeType::Categorical,
            31 => AttributeType::Categorical,
            32 => AttributeType::Categorical,
            33 => AttributeType::Categorical,
            34 => AttributeType::Categorical,
            35 => AttributeType::Categorical,

            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }
}

impl Sample for CensusSample {

    fn attribute_value(&self, attribute_index: u8) -> u8 {

        match attribute_index {
            0 => self.p1,
            1 => self.p2,
            2 => self.p3,
            3 => self.p4,
            4 => self.p5,
            5 => self.p6,
            6 => self.p7,
            7 => self.p8,
            8 => self.p9,
            9 => self.p10,
            10 => self.p11,
            11 => self.p12,
            12 => self.p13,
            13 => self.p14,
            14 => self.p15,
            15 => self.p16,
            16 => self.p17,
            17 => self.p18,
            18 => self.p19,
            19 => self.p20,
            20 => self.p21,
            21 => self.p22,
            22 => self.p23,
            23 => self.p24,
            24 => self.p25,
            25 => self.p26,
            26 => self.p27,
            27 => self.p28,
            28 => self.p29,
            29 => self.p30,
            30 => self.p31,
            31 => self.p32,
            32 => self.p33,
            33 => self.p34,
            34 => self.p35,
            35 => self.p36,
            _ => panic!("Requested non-existing attribute {}!", attribute_index)
        }
    }
    fn true_label(&self) -> bool {
        self.label
    }
}
