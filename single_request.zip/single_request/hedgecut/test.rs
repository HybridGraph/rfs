// =================Census=====================================
pub struct CensusDataset {
    pub num_records: u32,
    pub num_plus: u32,
}
#[derive(Eq,PartialEq,Debug,Clone)]
pub struct CensusSample {

    pub p1: u8,
    pub p2: u8,
    pub p3: u8,
    pub p4: u8,
    pub p5: u8,
    pub p6: u8,

    pub p7: u8,
    pub p8: u8,
    pub p9: u8,
    pub p10: u8,
    pub p11: u8,
    pub p12: u8,
    pub p13: u8,
    pub p14: u8,
    pub p15: u8,
    pub p16: u8,
    pub p17: u8,
    pub p18: u8,
    pub p19: u8,
    pub p20: u8,
    pub p21: u8,
    pub p22: u8,
    pub p23: u8,
    pub p24: u8,
    pub p25: u8,
    pub p26: u8,
    pub p27: u8,
    pub p28: u8,
    pub p29: u8,
    pub p30: u8,
    pub p31: u8,
    pub p32: u8,
    pub p33: u8,
    pub p34: u8,
    pub p35: u8,
    pub p36: u8,

    pub label: bool,
}

impl CensusDataset {
    pub fn from_samples(samples: &Vec<CensusSample>) -> CensusDataset {
        let num_plus = samples.iter().filter(|sample| sample.true_label()).count();

        CensusDataset {
            num_records: samples.len() as u32,
            num_plus: num_plus as u32,
        }
    }

    pub fn samples_from_csv(file: &str) -> Vec<CensusSample> {
        let mut samples: Vec<CensusSample> = Vec::new();

        let mut reader = csv::ReaderBuilder::new()
            .has_headers(true)
            .delimiter(b'\t')
            .from_path(file)
            .unwrap();

        for result in reader.records() {
            let record = result.unwrap();

            let p1 = u8::from_str(record.get(1).unwrap()).unwrap();
            let p2 = u8::from_str(record.get(2).unwrap()).unwrap();
            let p3 = u8::from_str(record.get(3).unwrap()).unwrap();
            let p4 = u8::from_str(record.get(4).unwrap()).unwrap();
            let p5 = u8::from_str(record.get(5).unwrap()).unwrap();
            let p6 = u8::from_str(record.get(6).unwrap()).unwrap();
            let p7 = u8::from_str(record.get(7).unwrap()).unwrap();
            let p8 = u8::from_str(record.get(8).unwrap()).unwrap();
            let p9 = u8::from_str(record.get(9).unwrap()).unwrap();
            let p10 = u8::from_str(record.get(10).unwrap()).unwrap();
            let p11 = u8::from_str(record.get(11).unwrap()).unwrap();
            let p12 = u8::from_str(record.get(12).unwrap()).unwrap();
            let p13 = u8::from_str(record.get(13).unwrap()).unwrap();
            let p14 = u8::from_str(record.get(14).unwrap()).unwrap();
            let p15 = u8::from_str(record.get(15).unwrap()).unwrap();
            let p16 = u8::from_str(record.get(16).unwrap()).unwrap();
            let p17 = u8::from_str(record.get(17).unwrap()).unwrap();
            let p18 = u8::from_str(record.get(18).unwrap()).unwrap();
            let p19 = u8::from_str(record.get(19).unwrap()).unwrap();
            let p20 = u8::from_str(record.get(20).unwrap()).unwrap();
            let p21 = u8::from_str(record.get(21).unwrap()).unwrap();
            let p22 = u8::from_str(record.get(22).unwrap()).unwrap();
            let p23 = u8::from_str(record.get(23).unwrap()).unwrap();
            let p24 = u8::from_str(record.get(24).unwrap()).unwrap();
            let p25 = u8::from_str(record.get(25).unwrap()).unwrap();
            let p26 = u8::from_str(record.get(26).unwrap()).unwrap();
            let p27 = u8::from_str(record.get(27).unwrap()).unwrap();
            let p28 = u8::from_str(record.get(28).unwrap()).unwrap();
            let p29 = u8::from_str(record.get(29).unwrap()).unwrap();
            let p30 = u8::from_str(record.get(30).unwrap()).unwrap();
            let p31 = u8::from_str(record.get(31).unwrap()).unwrap();
            let p32 = u8::from_str(record.get(32).unwrap()).unwrap();
            let p33 = u8::from_str(record.get(33).unwrap()).unwrap();
            let p34 = u8::from_str(record.get(34).unwrap()).unwrap();
            let p35 = u8::from_str(record.get(35).unwrap()).unwrap();
            let p36 = u8::from_str(record.get(36).unwrap()).unwrap();

            let label = u8::from_str(record.get(37).unwrap()).unwrap() == 1;

            let sample = CensusSample {
                p1,
                p2,
                p3,
                p4,
                p5,
                p6,
                p7,
                p8,
                p9,
                p10,
                p11,
                p12,
                p13,
                p14,
                p15,
                p16,
                p17,
                p18,
                p19,
                p20,
                p21,
                p22,
                p23,
                p24,
                p25,
                p26,
                p27,
                p28,
                p29,
                p30,
                p31,
                p32,
                p33,
                p34,
                p35,
                p36,
                label
            };

            samples.push(sample);
        }

        samples
    }
}


impl Dataset for CensusDataset {
    fn num_records(&self) -> u32 { self.num_records }

    fn num_plus(&self) -> u32 { self.num_plus }

    fn num_attributes(&self) -> u8 { 36 }

    fn attribute_range(&self, index: u8) -> (u8, u8) {
        match index {
            0 => (0, 15),
            1 => (0, 0),
            2 => (0, 0),
            3 => (0, 0),
            4 => (0, 1),
            5 => (0, 15),

            6 => (0, 8),
            7 => (0, 16),
            8 => (0, 2),
            9 => (0, 6),
            10 => (0, 23),
            11 => (0, 14),
            12 => (0, 4),
            13 => (0, 9),
            14 => (0, 1),
            15 => (0, 2),
            16 => (0, 5),
            17 => (0, 7),
            18 => (0, 5),
            19 => (0, 5),
            20 => (0, 50),
            21 => (0, 37),
            22 => (0, 7),
            23 => (0, 9),
            24 => (0, 8),
            25 => (0, 9),
            26 => (0, 2),
            27 => (0, 3),
            28 => (0, 4),
            29 => (0, 42),
            30 => (0, 42),
            31 => (0, 42),
            32 => (0, 4),
            33 => (0, 2),
            34 => (0, 2),
            35 => (0, 2),

            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }

    fn attribute_type(&self, index: u8) -> AttributeType {
        match index {

            0 => AttributeType::Numerical,
            1 => AttributeType::Numerical,
            2 => AttributeType::Numerical,
            3 => AttributeType::Numerical,
            4 => AttributeType::Numerical,
            5 => AttributeType::Numerical,

            6 => AttributeType::Categorical,
            7 => AttributeType::Categorical,
            8 => AttributeType::Categorical,
            9 => AttributeType::Categorical,
            10 => AttributeType::Categorical,
            11 => AttributeType::Categorical,
            12 => AttributeType::Categorical,
            13 => AttributeType::Categorical,
            14 => AttributeType::Categorical,
            15 => AttributeType::Categorical,
            16 => AttributeType::Categorical,
            17 => AttributeType::Categorical,
            18 => AttributeType::Categorical,
            19 => AttributeType::Categorical,
            20 => AttributeType::Categorical,
            21 => AttributeType::Categorical,
            22 => AttributeType::Categorical,
            23 => AttributeType::Categorical,
            24 => AttributeType::Categorical,
            25 => AttributeType::Categorical,
            26 => AttributeType::Categorical,
            27 => AttributeType::Categorical,
            28 => AttributeType::Categorical,
            29 => AttributeType::Categorical,
            30 => AttributeType::Categorical,
            31 => AttributeType::Categorical,
            32 => AttributeType::Categorical,
            33 => AttributeType::Categorical,
            34 => AttributeType::Categorical,
            35 => AttributeType::Categorical,

            _ => panic!("Requested range for non-existing attribute {}!", index),
        }
    }
}

impl Sample for CensusSample {

    fn attribute_value(&self, attribute_index: u8) -> u8 {

        match attribute_index {
            0 => self.p1,
            1 => self.p2,
            2 => self.p3,
            3 => self.p4,
            4 => self.p5,
            5 => self.p6,
            6 => self.p7,
            7 => self.p8,
            8 => self.p9,
            9 => self.p10,
            10 => self.p11,
            11 => self.p12,
            12 => self.p13,
            13 => self.p14,
            14 => self.p15,
            15 => self.p16,
            16 => self.p17,
            17 => self.p18,
            18 => self.p19,
            19 => self.p20,
            20 => self.p21,
            21 => self.p22,
            22 => self.p23,
            23 => self.p24,
            24 => self.p25,
            25 => self.p26,
            26 => self.p27,
            27 => self.p28,
            28 => self.p29,
            29 => self.p30,
            30 => self.p31,
            31 => self.p32,
            32 => self.p33,
            33 => self.p34,
            34 => self.p35,
            35 => self.p36,

            //不能有label

            _ => panic!("Requested non-existing attribute {}!", attribute_index)
        }
    }

    fn true_label(&self) -> bool {
        self.label
    }
}
