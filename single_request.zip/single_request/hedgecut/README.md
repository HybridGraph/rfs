# Hedgecut

Source code for our SIGMOD'21 paper on "HedgeCut: Maintaining Randomised Trees for Low-Latency Machine Unlearning" https://ssc.io/pdf/rdm235.pdf
