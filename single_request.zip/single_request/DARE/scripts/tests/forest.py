import gc
import os
import random
import sys
import time
import argparse

import numpy as np
from sklearn.datasets import load_iris
from sklearn.datasets import load_boston
from sklearn.metrics import accuracy_score, average_precision_score
from sklearn.metrics import roc_auc_score
from sklearn.ensemble import RandomForestClassifier

here = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, here + '/../../')
sys.path.insert(0, here + '/../')
import dare
from utility import data_util


def load_data(dataset, data_dir):
    if dataset == 'iris':
        data = load_iris()
        X = data['data']
        y = data['target']

        # make into binary classification dataset
        indices = np.where(y != 2)[0]
        X = X[indices]
        y = y[indices]

        X_train, X_test, y_train, y_test = X, X, y, y

    elif dataset == 'boston':
        data = load_boston()
        X = data['data']
        y = data['target']

        # make into binary classification dataset
        y = np.where(y < np.mean(y), 0, 1)

        X_train, X_test, y_train, y_test = X, X, y, y

    else:
        X_train, X_test, y_train, y_test = data_util.get_data(dataset, data_dir)
        X_train = X_train[:, :]
        X_test = X_test[:, :]

    return X_train, X_test, y_train, y_test


def experiment(args, X_train, X_test, y_train, y_test, seed):
    # 参数设置♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥♥
    n_delete = 1000  # 随机删除1000samples取平均delete time

    # f = open('C:/Users/admin/desktop/fsdownload/' + args.dataset
    # + '/' + args.dataset + '2.txt', 'r')

    # print(seed)
    max_depth = 20

    if args.dataset == 'adult':
        k = 5
        n_estimators = 50
        score = 'acc'
        topd = 16
    elif args.dataset == 'census':
        k = 25
        n_estimators = 100
        score = 'auc'
        topd = 16
    elif args.dataset == 'credit_card':
        k = 5
        n_estimators = 250
        score = 'ap'
        topd = 17
    elif args.dataset == 'bank_marketing':
        k = 25
        n_estimators = 100
        score = 'auc'
        topd = 14
    elif args.dataset == 'diabetes':
        k = 5
        n_estimators = 250
        score = 'acc'
        topd = 15
    elif args.dataset == 'flight_delays':
        k = 25
        n_estimators = 250
        score = 'auc'
        topd = 10
    elif args.dataset == 'no_show':
        k = 10
        n_estimators = 250
        score = 'auc'
        topd = 10
    elif args.dataset == 'olympics':
        k = 5
        n_estimators = 250
        score = 'auc'
        topd = 7  # 3
    elif args.dataset == 'surgical':
        k = 25
        n_estimators = 100
        score = 'acc'
        topd = 4
    elif args.dataset == 'synthetic':
        k = 10
        n_estimators = 50
        score = 'acc'
        topd = 5
    elif args.dataset == 'ctr':
        k = 50
        n_estimators = 100
        score = 'auc'
        topd = 6
        max_depth = 10
    else:
        k = 0
        n_estimators = 0
        score = 'auc'
        topd = 0
        be_used = 0
        topk = 0

    print('dataset:', args.dataset, '  n_estimators:', n_estimators,
          '  max_depth:', max_depth, '  k:', k, )
    start = time.time()
    model = dare.Forest(topd=topd, k=k, n_estimators=n_estimators,
                        max_depth=max_depth, random_state=seed, criterion='gini')
    model = model.fit(X_train, y_train)
    train_time = time.time() - start
    print('train time: {:.3f}s'.format(train_time))
    print(model.get_node_statistics())
    # structure_memory, decision_stats_memory, leaf_stats_memory = model.get_memory_usage()
    # print(structure_memory, decision_stats_memory, leaf_stats_memory)

    # predict
    y_proba = model.predict_proba(X_test)
    y_pred = np.argmax(y_proba, axis=1)

    acc = accuracy_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_proba[:, 1])
    ap = average_precision_score(y_test, y_proba[:, 1])
    print('ACC: {:.3f}, AUC: {:.3f},AP: {:.3f}'.format(acc, auc, ap))

    # delete training data
    cum_delete_time = 0
    cum_accuracy = 0
    if args.delete:
        delete_indices = np.random.default_rng(seed=seed).choice(X_train.shape[0], size=n_delete, replace=False)
        # print('instances to delete: {}'.format(delete_indices))
        #
        # for i in range(n_delete):
        #     line = f.readline()
        #     delete_indices[i] = int(line)
        # y_pos = np.zeros(n_delete, dtype=np.float32)

        # delete each sample
        s = 0
        max_time = 0
        for delete_ndx in delete_indices:
            start = time.time()
            model.delete(delete_ndx)
            delete_time = time.time() - start
            if delete_time > max_time:
                max_time = delete_time
            cum_delete_time += delete_time

            # y_pos[s] = model.predict2(X_ttest, s)

            # print(s)
            s += 1
            # print('\ndeleted instance, {}: {:.3f}s'.format(delete_ndx, delete_time))

        avg_delete_time = cum_delete_time / len(delete_indices)
        print('avg. delete time: {:.6f}s'.format(avg_delete_time))

        print('retrain samples:', model.manager_.retrain_samples)
        #print('retrain times:', model.manager_.count)

        # 交替进行的预测
        # y_pos = y_pos.reshape(-1, 1)
        # y_proba = np.hstack([1 - y_pos, y_pos])
        # y_pred = np.argmax(y_proba, axis=1)
        #
        # acc = accuracy_score(y_ttest, y_pred)
        # auc = roc_auc_score(y_ttest, y_proba[:, 1])
        # ap = average_precision_score(y_ttest, y_proba[:, 1])
        # print('♥交替：ACC: {:.3f}, AUC: {:.3f},AP: {:.3f}'.format(acc, auc, ap))
        # print('♥交替：ACC: {:.3f}'.format(acc))

        # # 最后一起predict
        # y_proba = model.predict_proba(X_ttest)
        # y_pred = np.argmax(y_proba, axis=1)
        #
        # # evaluate
        # acc = accuracy_score(y_ttest, y_pred)
        # auc = roc_auc_score(y_ttest, y_proba[:, 1])
        # ap = average_precision_score(y_ttest, y_proba[:, 1])
        # print('ACC: {:.3f}, AUC: {:.3f},AP: {:.3f}'.format(acc, auc, ap))

        #print(max_time)


if __name__ == '__main__':
    dataset = 'bank_marketing'  # input()
    data_dir = 'C:/Users/admin/PycharmProjects/DARE_new/data'
    # get data
    X_train, X_test, y_train, y_test = load_data(dataset, data_dir)
    print(X_train.shape)

    # I/O settings
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_dir', type=str, default=data_dir, help='data directory.')
    parser.add_argument('--dataset', type=str, default=dataset, help='dataset to use for the experiment.')
    parser.add_argument('--model', type=str, default='dare', help='dare or sklearn')
    parser.add_argument('--delete', default=1, action='store_true', help='whether to deletion or not.')
    # parser.add_argument('--simulate', default=1, action='store_true', help='whether to simulate deletions or not.')
    parser.add_argument('--test_idempotency', action='store_true', help='simulate deletion multiple times.')
    args = parser.parse_args()
    seed = 1  # int(time.time())
    experiment(args, X_train, X_test, y_train, y_test, seed)
    del args
