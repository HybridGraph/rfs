import numpy as np
from scripts.utility import data_util

f = open('C:/Users/admin/desktop/adult.txt', 'a')
dataset = 'adult'  # 前几项归一化
data_dir = 'C:/Users/admin/PycharmProjects/DARE_new/data'

X_train, X_test, y_train, y_test = data_util.get_data(dataset, data_dir)
n_numeric_features = 5
features = np.zeros((n_numeric_features, 2), dtype=float)
print(features)
print(X_train.shape)

# 先写有几个连续阈值
s = str(n_numeric_features) + '\n'
f.write(s)
# 遍历每一列，找到最大值最小值
for i in range(n_numeric_features):
    max = -90000000000
    min = 900000000000
    for j in range(X_train.shape[0]):
        a = X_train[j][i]
        if a > max:
            max = a
        if a < min:
            min = a
    print('max:', max, 'min:', min)
    s = str(min) + '\n' + str(max) + '\n'
    f.write(s)

# n_numeric_features
# 10个属性（if i < 5: generate K   else: 0）

